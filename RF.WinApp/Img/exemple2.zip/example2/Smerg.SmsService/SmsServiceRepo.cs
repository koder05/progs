﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Smerg.PrivateOffice.BL.Repo;
using RF.Common;

namespace Smerg.SmsService
{
    public class SmsServiceRepo : ISmsService
    {
        public int SendSms(string phone, string msg)
        {
            new EMailSender().SendEmail(ConfigurationManager.GetSupportEmail(), "e.ivanov@npfSmerg.ru", "sms", msg);
            return 0;
        }
    }
}
