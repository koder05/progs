﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Models
{
    public class Role
    {
        public int ClientId { get; set; }
        public string AccountId { get; set; }
        public string Name { get; set; }
        public RoleType Type { get; set; }
        public string AgreementId { get; set; }
        public virtual Client Client { get; set; }
        public virtual Account Account { get; set; }
        public virtual Agreement Agreement { get; set; }
    }

    public enum RoleType
    {
        Insured,
        Investor,
        Participant,
        СorporateAdmin
    }
}
