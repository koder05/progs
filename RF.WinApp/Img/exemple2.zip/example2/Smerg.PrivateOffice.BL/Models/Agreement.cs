﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Models
{
    public class Agreement
    {
        public string AgreementId { get; set; }
        public DateTime OpenDate { get; set; }
        public string Type { get; set; }
        public string Rule { get; set; }
        public ICollection<Role> Roles { get; set; }
    }
}
