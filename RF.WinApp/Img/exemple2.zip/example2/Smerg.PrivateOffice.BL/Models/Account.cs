﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Models
{
    public class Account
    {
        public string AccountId { get; set; }
        public string Number { get; set; }
        public int TypeId { get; set; }
        public AccountType AccountType { get; set; }
        public DateTime OpenDate { get; set; }
        public DateTime? CloseDate { get; set; }
        public ICollection<Role> Roles { get; set; }
        public ICollection<Operation> Operations { get; set; }
    }

    public class AccountType
    {
        public int AccountTypeId { get; set; }
        public string Name { get; set; }
    }
}
