﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Models
{
    public class Client
    {
        public int ClientId { get; set; }
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string Ipa { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string GenderRaw { get; set; }
        public User User { get; set; }

        public ICollection<Role> Roles { get; set; }

        public Gender Gender
        {
            get
            {
                var i = 0;
                Int32.TryParse(this.GenderRaw, out i);
                return (Gender)i;
            }
        }
    }

    public enum Gender
    {
        Famale = 0,
        Male = 1
    }
}
