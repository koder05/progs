﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Models.Mib
{
    public class OperationRequestOrder
    {
        public string Merchant { get; set; }
        public decimal Amount { get; set; }
        public int Currency { get; set; }
        public string Description { get; set; }
        public string OrderType { get; set; }
        public string ApproveURL { get; set; }
        public string CancelURL { get; set; }
        public string DeclineURL { get; set; }
        public OrderRequestParams AddParams { get; set; }
    }

    public class OperationRequest
    {
        public string Operation { get; set; }
        public string Language { get; set; }
        public OperationRequestOrder Order { get; set; }
    }

    public class OrderRequestParams
    {
        public string Recurfrequency { get; set; }
        public string RecurendRecur { get; set; }
    }

    public class OrderRequest
    {
        public OperationRequest Request { get; set; }
    }

    public class OrderResponse
    {
        public OrderResponseOperation Response { get; set; }

        public Uri PurchaseUrl { get; set; }
    }

    public class OrderResponseOperationOrder
    {
        public int OrderID { get; set; }
        public string SessionID { get; set; }
        public string URL { get; set; }
    }

    public class OrderResponseOperation
    {
        public OrderResponseOperationOrder Order { get; set; }
        public string Operation { get; set; }
        public string Status { get; set; }
    }

    public class PurchaseResult
    {
        public int OrderId { get; set; }
        public PurchaseStatus Status { get; set; }
        public Exception Exception { get; set; }
    }

    public class PaymentDetails
    {
        public int OrderId { get; set; }

        /// <summary>
        /// redirection url after vendor postback
        /// </summary>
        public string ReturnUrl { get; set; }

        /// <summary>
        /// payment vendor url
        /// </summary>
        public string PurchaseUrl { get; set; }
        public decimal Amount { get; set; }
        public string AgreementId { get; set; }
        public string SessionId { get; set; }
        public int Periodicity { get; set; }
    }

    public enum PurchaseStatus
    {
        ERROR,
        CANCELED,
        APPROVED,
        DECLINED
    }
}
