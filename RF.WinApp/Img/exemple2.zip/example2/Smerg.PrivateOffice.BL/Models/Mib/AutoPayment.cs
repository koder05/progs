﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Smerg.PrivateOffice.BL.Models.Mib
{
    public class AutoPaymentRequest
    {
        public string AgreementNumber { get; set; }
    }

    public class AutoPaymentResponse
    {
        public int AgreementId { get; set; }
        public int Periodicity { get; set; }
        public decimal Amount { get; set; }
        public DateTime? DateFrom { get; set; }
        public string PaymentOrderId { get; set; }
        public string PaymentSessionId { get; set; }
        public string Description { get; set; }
        public string DescriptionFull { get; set; }
    }

    public enum AutoPaymentPeriodicity
    {
        [Description("единоразово")]
        Ones = 0,
        [Description("ежемесячно")]
        Monthly = 1,
        [Description("ежеквартально")]
        Quarterly = 2,
        [Description("раз в пол года")]
        Halfyearly = 3,
        [Description("ежегодно")]
        Yearly = 4
    }
}
