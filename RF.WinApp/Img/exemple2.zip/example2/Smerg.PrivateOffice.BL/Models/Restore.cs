﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Models
{
    public class Restore
    {
        public string RestoreId { get; set; }
        public DateTime StartTime { get; set; }
        public int ClientId { get; set; }
        public Guid RequestId { get; set; }

        public bool OrderUsed { get; set; }

        public string EmailMessage
        {
            get
            {
                return string.Format(EmailMessageTemplate, this.RequestId.ToString().Replace("-", "").ToUpper());
            }
        }

        private string EmailMessageTemplate = @"
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<title>Восстановление пароля в личном кабинете НПФ «smerg».</title>
<style type = 'text/css' >
body {{font: 15px arial;}}
.d{{ border-top: 2px Dashed #9F9F9F; border-bottom: 2px Dashed #9F9F9F;}}
</style>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
</head>
<body>
<p>Уважаемый Клиент!</p>
<p/>
<p>
Мы получили запрос на восстановление пароля к вашему личному кабинету. Для восстановления пароля пройдите, пожалуйста, по  <a href='https://client.npfSmerg.ru/#restore/{0}'>ссылке</a>
</p>
<p/>
<p>
Ссылка будет действовать в течение 48 часов. 
</p>
<p/>
<p>
С уважением,
</p>
<p/>
<p>
АО НПФ «smerg» 
</p>
<p/>
<p>
*** 
</p><p/>
<p>
Напоминаем о важности своевременного обновления ваших данных для быстрого и удобного обмена информацией. Пожалуйста, сообщайте нам об изменениях, чтобы мы всегда оставались на связи! Подробнее об этом - на нашем <a href='http://www.npfSmerg.ru/about/news/index.php?id28=30630'>сайте</a>.
</p>
<p/>
<p class='d'>
This message and any attachment are confidential and may be privileged or otherwise protected from disclosure.If you are not the intended recipient any use, distribution, copying or disclosure is strictly prohibited. If you have received this message in error, please notify the sender immediately either by telephone or by e-mail and delete this message and any attachment from your system.Correspondence via e-mail is for information purposes only.AO NPF Smerg neither makes nor accepts legally binding statements by e-mail unless otherwise agreed.
</p>
</body></html>
";
    }
}
