﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string PasswordHash { get; set; }
        public int PasswordHashMethod { get; set; }
        public int? PasswordHashMethodSql
        {
            get { return PasswordHashMethod; }
            set { PasswordHashMethod = value ?? 0; }
        }

        public string PasswordHashSalt { get; set; }
        public virtual Client Client { get; set; }
    }
}
