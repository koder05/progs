﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RF.Common;

namespace Smerg.PrivateOffice.BL.Models
{
    public class Registration
    {
        public Guid RegistrationId { get; set; }
        public int ClientId { get; set; }
        public string RequestId { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int SmsCode { get; set; }
        public int SmsStatus { get; set; }
        public DateTime StartTime { get; set; }

        public string EmailMessage
        {
            get
            {
                return string.Format(EmailMessageTemplate, this.RequestId, ConfigurationManager.GetSupportEmail());
            }
        }

        private string EmailMessageTemplate = @"
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<title>Запрос на смену пароля в личном кабинете НПФ «smerg».</title>
<style type = 'text/css' >
body {{font: 15px arial;}}
.d{{ border-top: 2px Dashed #9F9F9F; border-bottom: 2px Dashed #9F9F9F;}}
</style>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
</head>
<body>
<p>Уважаемый Клиент!</p>
<p/>
<p>
Вы получили это письмо, потому что ваш адрес электронной почты был указан при регистрации Личного кабинета на сайте АО НПФ «smerg». Для подтверждения регистрации необходимо:
</p>
<p/>
<p>
1. Подтвердить адрес электронной почты.Для этого пройдите, пожалуйста, по <a href='https://client.npfSmerg.ru/#register/{0}'>ссылке</a><br/>
Если ссылка не открывается, скопируйте ее и вставьте в адресную строку браузера. Ссылка будет действовать в течение 48 часов.
</p>
<p/>
<p>
2. Подтвердить номер мобильного телефона. После перехода по ссылке на подтверждение электронной почты вам будет отправлен код по смс, следуйте дальнейшим инструкциям на странице.
</p>
<p/>
<p>
Будем рады предоставить вам консультацию, а также ответить на любые интересующие Вас вопросы по телефону 8 (800) 700-80-20 (звонок по России бесплатный) или по электронной почте <a href='mailto:{1}'>npf@npfSmerg.ru</a>
</p><p/>
<p>
Напоминаем о важности своевременного обновления ваших данных для быстрого и удобного обмена информацией.Пожалуйста, сообщайте нам об изменениях, чтобы мы всегда оставались на связи! Подробнее об этом - на нашем сайте <a href='http://www.npfSmerg.ru'>http://www.npfSmerg.ru</a>
</p>
<p/>
<p>
С уважением,
</p>
<p/>
<p>
АО НПФ «smerg» 
</p>
<p/>
<p>
*** 
</p><p/>
<p>
Если вы не вводили ваш адрес для регистрации Личного кабинета АО НПФ «smerg» и это письмо попало к вам по ошибке, проигнорируйте его.
</p>
<p/>
<p class='d'>
This message and any attachment are confidential and may be privileged or otherwise protected from disclosure.If you are not the intended recipient any use, distribution, copying or disclosure is strictly prohibited. If you have received this message in error, please notify the sender immediately either by telephone or by e-mail and delete this message and any attachment from your system.Correspondence via e-mail is for information purposes only.AO NPF Smerg neither makes nor accepts legally binding statements by e-mail unless otherwise agreed.
</p>
</body></html>
";
    }
}
