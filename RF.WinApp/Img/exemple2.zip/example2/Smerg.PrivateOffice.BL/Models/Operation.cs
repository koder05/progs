﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Models
{
    public class Operation
    {
        public long Rn { get; set; }
        public string AccountId { get; set; }
        public DateTime Date { get; set; }
        public decimal Income { get; set; }
        public decimal Payment { get; set; }
        public string Description{ get; set; }
        public string Type { get; set; }

        //public Account Account { get; set; }
    }
}
