﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Smerg.PrivateOffice.BL.Models;

namespace Smerg.PrivateOffice.BL.Repo
{
    public interface IRegistrationRepo
    {
        Registration BeginRegistration(int clientId, string email, string phone);

        Registration GetRegistration(string regCode);

        void Update();
    }
}
