﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Smerg.PrivateOffice.BL.Models;

namespace Smerg.PrivateOffice.BL.Repo
{
    public interface IUserRepo
    {
        User NewUser(Registration reg);
        User NewUser(int id, string login, string psw);
        User GetUserByName(string login);
        User GetUserById(int id);
        string ComputePswHash(User user, string psw);
        bool CheckUser(User user, string psw);
        bool ChangeCredentials(User user, string oldPsw, string newLogin, string newPsw);
        string ResetPassword(User user);
    }
}
