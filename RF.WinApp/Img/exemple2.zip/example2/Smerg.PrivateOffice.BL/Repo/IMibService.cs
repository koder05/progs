﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Smerg.PrivateOffice.BL.Models.Mib;

namespace Smerg.PrivateOffice.BL.Repo
{
    public interface IMibService
    {
        AutoPaymentResponse GetAutoPayment(AutoPaymentRequest req);
        OrderResponse CreateOrder(OrderRequest req);
        PurchaseResult CheckPurchaseResult(string xmlmsg);
        object ConfirmPurchase(PaymentDetails pmnt);
        object AutoPaymentCancel(int agreeId);
    }
}
