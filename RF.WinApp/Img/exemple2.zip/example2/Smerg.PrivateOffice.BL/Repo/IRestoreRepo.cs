﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Smerg.PrivateOffice.BL.Models;

namespace Smerg.PrivateOffice.BL.Repo
{
    public interface IRestoreRepo
    {
        Restore BeginRestore(int clientId);

        Restore GetRestore(string resCode);

        void Update();
    }
}
