﻿using System;
using System.Collections.Generic;
using System.Linq;
using Smerg.PrivateOffice.BL.Models;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Repo
{
    public interface IClientRepo
    {
        Client TryFind(string ipa, string email, string phone);
        Client GetByEmail(string email);
        IEnumerable<Role> GetAccountRoles(int clientId);
        IEnumerable<Invest> GetInvestInfo(int clientId);
    }
}
