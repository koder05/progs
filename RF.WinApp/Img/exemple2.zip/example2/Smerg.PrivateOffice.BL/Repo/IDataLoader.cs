﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Smerg.PrivateOffice.BL.Models;

namespace Smerg.PrivateOffice.BL.Repo
{
    public interface IDataLoader
    {
        IEnumerable<Agreement> LoadAgreements(int clientId);
        IEnumerable<Account> LoadAccounts(int clientId);
        IEnumerable<Role> LoadRoles(int clientId);
        IEnumerable<Operation> LoadMoney(int clientId);
    }
}
