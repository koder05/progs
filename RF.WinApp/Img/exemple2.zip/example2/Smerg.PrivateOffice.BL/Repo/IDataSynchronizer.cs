﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Smerg.PrivateOffice.BL.Models;

namespace Smerg.PrivateOffice.BL.Repo
{
    public interface IDataSynchronizer
    {
        bool BossSynchronize(User user);
    }
}
