﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.PrivateOffice.BL.Logging
{
    public class SentEmail
    {
        public string MailFrom { get; set; }
        public string MailReplyTo { get; set; }
        public string MailTo { get; set; }
        public string MailSubject { get; set; }
        public string MailTextBody { get; set; }
    }
}
