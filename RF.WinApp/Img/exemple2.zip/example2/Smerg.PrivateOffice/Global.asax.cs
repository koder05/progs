﻿using System;
using System.Web.Http;
using System.Web.Routing;
using RF.Common.DI;
using RF.Common.Transactions;
using RF.Common.Logging;
using Ms.Unity._2;

namespace Smerg.PrivateOffice
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
        }

        public override void Init()
        {
            base.Init();
            IContainerWrapper ioc = new UnityContainerWrapper();
            GlobalConfiguration.Configuration.DependencyResolver = new DependencyResolver(ioc);
            IoC.InitializeWith(ioc);
            Transactions.Service = IoC.Resolve<TransactionService>();
            Logs.Service = IoC.Resolve<LogService>();
            Logs.LogApp.Log(null, "Start", "Start");
        }
    }
}
