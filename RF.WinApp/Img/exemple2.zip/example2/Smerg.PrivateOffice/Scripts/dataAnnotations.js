﻿define([], function () {

    return function () {
        var self = this;
        this.meta = [];

        this.executeValidator = function (validatorName, val /*, args */) {
            var args = Array.prototype.slice.call(arguments, 2);
            args.splice(0, 0, val);
            return self.validator[validatorName].apply(self.validator, args);
        };

        this.validator = {
            Required: function (val) {
                return val || val === 0;
            },
            Range: function (val, args) {
                var ret = false;
                if (val || val === 0) {
                    ret = true;
                    if (args[0]) {
                        ret &= val >= args[1];
                    }
                    if (args[1]) {
                        ret &= val <= args[2];
                    }
                }
                return ret;
            },
            EnumDataType: function (val, args) {
                if (val || val === 0) {
                    for (var i = 0; i < args.length; i++) {
                        if (val === args[i])
                            return true;
                    }
                }
                return false;
            }
        };

        this.validate = function (apiPath, httpMethod, model, onSuccess, onError) {
            if (self.meta[apiPath]) {
                //annoMeta = [{ name : "num", annotations : [{foo : "required",  message : "message", args : []}, ... ]} , ...]
                var annoMeta = self.meta[apiPath];
                var error = {
                    ClassName: DataAnnotationErrorKey,
                    Errors: []
                };
                if (annoMeta && annoMeta instanceof Array) {
                    for (var i = 0; i < annoMeta.length; i++) {
                        if (annoMeta[i].name && annoMeta[i].annotations && annoMeta[i].annotations instanceof Array) {
                            var val = model[annoMeta[i].name];
                            var e = {};
                            e.fieldName = annoMeta[i].name;
                            e.errors = [];

                            for (var j = 0; j < annoMeta[i].annotations.length; j++) {
                                if (self.executeValidator(annoMeta[i].annotations[j].foo, val, annoMeta[i].annotations[j].args) === false) {
                                    e.errors.push(annoMeta[i].annotations[j].message);
                                }
                            }

                            if (e.errors.length > 0)
                                error.Errors.push(e);
                        }
                    }
                }

                if (error.Errors.length > 0) {
                    onError(error);
                }
                else {
                    onSuccess();
                }
            }
            else {
                $.apiPost("api/auth/annotate"
                    , { path: apiPath, method: "POST" }
                    , function (data) {
                        self.meta[apiPath] = data;
                    }
                    , function () { }
                    , function () {
                        self.meta[apiPath] = self.meta[apiPath] || {};
                        self.validate(apiPath, httpMethod, model, onSuccess, onError);
                    }
                );
            }
        };
    };
});