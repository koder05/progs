﻿var DataAnnotationErrorKey = "Smerg.PrivateOffice.Controllers.ValidationResponse";

requirejs.config({
    baseUrl: 'scripts/prod',
    paths: {
        root: '../',
        react: '../react',
        'react-dom': '../react-dom',
        chartist : '../chartist.min'
    }
            ,
    map: {
        '*': { 'React': 'react' }
    },
    urlArgs: "bust=v0.17",
    config: {
        'app': {
            ver: ''
        },
        'app.min': {
            ver: '.min'
        }
    }
});

require(['app'], function (app) {
    app();
});

