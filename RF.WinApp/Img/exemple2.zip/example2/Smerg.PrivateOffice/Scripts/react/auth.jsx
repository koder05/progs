﻿define(['validationError.min', 'react'], function (ValidationErrorView, React) {
    class AuthFormView extends React.Component {
        render() {
            return (
                <div className="login">
                    <h1 className="h-hr">Авторизация</h1>
                    <div className="lk-text">
                        <p>Добро пожаловать в Личный кабинет Клиента АО НПФ «smerg»!</p>
                        <p>Для входа в Личный кабинет используйте логин и пароль, выданный ранее, в том числе для личных кабинетов присоединенных фондов НПФ «Европейский пенсионный фонд» (АО) и НПФ «РЕГИОНФОНД» (АО).</p>
                        <p>
                            Если ранее вы не получали доступ в Личный кабинет, пройдите <a className="green" href="register.asp">регистрацию</a>.
                            Обращаем внимание, что в настоящий момент доступна регистрация только для клиентов по обязательному пенсионному страхованию.
                            Регистрация для клиентов по негосударственному пенсионному обеспечению, которые ранее не получали логин и пароль, будет реализована позднее.
                            Для получения информации о состоянии пенсионного счета просим направить письменный запрос по адресу 125009, г. Москва, ул. Тверская, д. 22, АО НПФ «smerg».
                        </p>
                        <p>Все вопросы по работе Личного кабинета можно задать по телефонам <a className="green" href="tel:+74957779989">+7&nbsp;(495)&nbsp;777-99-89</a>, <a className="green" href="tel:88007008020">8&nbsp;(800)&nbsp;700-80-20</a> или электронной почте <a className="green" href="mailto:npf@npfSmerg.ru">npf@npfSmerg.ru</a>.</p>
                    </div>
                    <div className="lk-inputs lk-custom-2">
                        <h2 className="h-hr lk-header-inputs">Авторизация</h2>
                        <form id="logon" action="" method="post" onSubmit={this.props.onSubmit}>
                            <ValidationErrorView error={this.props.error} className="form-group lab-5" validatedField="error" />
                            <ValidationErrorView error={this.props.error} className="form-group lab-2" validatedField="login">
                                <span className="lk-ph">Введите ваш логин:<span className="green-to-red">*</span></span>
                                <input name="CLIENT_LOGINNAME" className="lk-inp inp-2" id="login" type="text" value={this.props.login} onChange={this.props.onLoginInput} />
                            </ValidationErrorView>
                            <ValidationErrorView error={this.props.error} className="form-group lab-2" validatedField="psw">
                                <span className="lk-ph">Введите ваш пароль:<span className="green-to-red">*</span></span>
                                <input name="CLIENT_PASSWORD" className="lk-inp inp-2" id="password" type="password" maxLength="255" value={this.props.psw} onChange={this.props.onPswInput} />
                            </ValidationErrorView>
                            <ValidationErrorView error={this.props.error} className="form-group lab-2" validatedField="captcha">
                                <span className="lk-ph">Введите символы с картинки:<span className="green-to-red">*</span></span>
                                <input name="txtCaptcha" className="lk-inp inp-2" type="text" value={this.props.captcha.text} onChange={this.props.onCaptchaInput} />
                            </ValidationErrorView>
                            <div>
                                &nbsp;
                                <img id="imgCaptcha" src={"captcha.axd?guid=" + this.props.captcha.id} title="Кликните, чтобы обновить" alt="CAPTCHA" style={{cursor: "pointer"}} 
                                        onClick={this.props.onCaptchaRenew} width={this.props.captcha.width} height={this.props.captcha.height} />
                                <div className="wrapper-btn">
                                    <input type="submit" className="btn btn-green" value="Отправить" />
                                    <div className="for-forgot-registr">
                                        <a className="regist_forgot" href="#restore">Забыли пароль?</a>
                                        <a className="regist_forgot" href="#register">Регистрация</a>
                                    </div>
                                </div>
                            </div>
                                
</form>
                    </div>
                </div>
            );
        }
    }

    return function authForm(doView, model) {
        this.renderFoo = doView;
        this.state = {};
        let self = this;

        this.loginInput = function(e) {
            self.state.login = e.target.value;
            self.doInput();
        }

        this.pswInput = function (e) {
            self.state.psw = e.target.value;
            self.doInput();
        }

        this.pswInput = function (e) {
            self.state.psw = e.target.value;
            self.doInput();
        }

        this.captchaInput = function (e) {
            self.state.captcha.text = e.target.value;
            self.doInput();
        }

        this.captchaRenew = function () {
            model.getApi({
                url: "api/log/captcha",
                callback: function (data) {
                    self.state.captcha = Object.assign(data, {text : ""});
                    self.renderFoo(React.createElement(AuthFormView, self.state));
                }
            });
        }

        this.submit = function (e) {
            e.preventDefault();
            model.postApi({
                url: "api/log/login",
                data: {
                    login: self.state.login,
                    psw: self.state.psw,
                    captcha: self.state.captcha
                },
                callback: function (data) {
                    model.redirectFromLogin(data.token);
                },
                validationError: function (e) {
                    self.state.error = e;
                    self.captchaRenew();
                }
            });
        }

        this.doControl = function () {
            this.captchaRenew();
        }

        this.doInput = function () {
            self.state.error = {};
            self.renderFoo(React.createElement(AuthFormView, self.state));
        }

        Object.assign(this.state, model, {
            onLoginInput: this.loginInput,
            onPswInput: this.pswInput,
            onCaptchaInput: this.captchaInput,
            onSubmit: this.submit,
            login: "",
            psw: "",
            error: {},
            onCaptchaRenew : this.captchaRenew
        });
    }
});