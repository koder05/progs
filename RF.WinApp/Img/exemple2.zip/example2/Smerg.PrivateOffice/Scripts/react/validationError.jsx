﻿define(['react'], function (React) {
    class ValidationErrorView extends React.Component {

        //{
        //    ClassName : "Smerg.PrivateOffice.Controllers.ValidationResponse",
        //    Errors : [
        //        {
        //            fieldName : "num",
        //            errors : [ "error1", .. ]
        //        }, ....
        //    ]
        //}

        render() {
            var validationInfo = [];
            var self = this;
            if (typeof (this.props.error) !== 'undefined') {
                var eachFoo = function () { };
                if (this.props.validatedField !== '' && typeof(this.props.validatedField) !== 'undefined') {
                    eachFoo = function (i, e) {
                        if (e.fieldName == self.props.validatedField) {
                            validationInfo.push(<li key={i}>{e.errors[0]}</li>);
                            return false;
                        }
                    };
                }
                else {
                    eachFoo = function (i, e) {
                        validationInfo.push(<li key={i}>{e.errors[0]}</li>);
                    };
                }

                $(this.props.error.Errors).each(eachFoo);

            }

            return (
                <label className={this.props.className + (validationInfo.length > 0 ? " error" : "")}>
                    { this.props.children }
                    <span className="help-block text-danger">
                        {validationInfo.length > 0 && <ul>{validationInfo}</ul>}
                    </span>
                </label>
            );
        }
    }

    return ValidationErrorView;
});