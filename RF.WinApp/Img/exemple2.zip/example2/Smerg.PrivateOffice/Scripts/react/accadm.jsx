﻿define(['griddleExt.min', 'react', 'root/Griddle.min', 'chartist', 'root/chartist-plugin-legend.min'], function (MutableField, React, Griddle, Chartist, ChartistLegend) {

    class AccountAdmView extends React.Component {
        render() {

            const meta1 = [
                {
                    columnName: "type",
                    displayName: "Тип",
                    customComponent: MutableField,
                    title: "Тип"
                },
                {
                    columnName: "agree",
                    displayName: "Номер договора",
                    customComponent: MutableField,
                    title: "Номер договора"
                },
                {
                    columnName: "acc",
                    displayName: "Номер счета",
                    customComponent: MutableField,
                    title: "Номер счета"
                },
                {
                    columnName: "db",
                    displayName: "Дата открытия",
                    customComponent: MutableField,
                    format: "date",
                    title: "Дата открытия"
                },
                {
                    columnName: "de",
                    displayName: "Дата закрытия",
                    customComponent: MutableField,
                    format: "date",
                    title: "Дата закрытия"
                },
                {
                    columnName: "saldo",
                    displayName: "Баланс, руб.",
                    customComponent: MutableField,
                    format: "number",
                    title: "Баланс, руб."
                }
            ];

            var self = this;

            const meta2 = [
                {
                    columnName: "num",
                    displayName: "№"
                },
                {
                    columnName: "date",
                    displayName: "Дата",
                    customComponent: MutableField,
                    format: "date"
                },
                {
                    columnName: "operation",
                    displayName: "Название операции"
                },
                {
                    columnName: "saldo",
                    displayName: "Сумма, руб.",
                    customComponent: MutableField,
                    format : "number"
                }
            ];

            return (
                    <div className="login">
						<h1>Информация по счету</h1>
                    <Griddle results={this.props.acc} columnMetadata={meta1} useGriddleStyles={false} showPager={false}
                        columns={["type", "agree", "acc", "db", "de", "saldo"]} 
                        tableClassName="adm-table"
                         />
                    {this.props.spec &&
                    <div className="ct-chart">
                        <table cellPadding="0" cellSpacing="0">
                            <tbody>
                                <tr>
                                    <td id="ct-chart"></td>
                                    <td id="ct-chart-legend"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    }
                    {this.props.spec &&
                    <div className="lk-table">
						<table className="rwd-table1">						
                            <tbody>
							<tr>
								<td>Инвестиционный доход за предыдущий год, руб*</td>
								<td className="cntr">
								    {$.moneyFormatRu(this.props.spec.yearInvest)}
								</td>
							</tr>
							<tr>
								<td>Инвестиционный доход за весь период накопления, руб*</td>
								<td className="cntr">{$.moneyFormatRu(this.props.spec.wholeInvest)}</td>
							</tr>
							<tr>
								<td>
								    Дата последнего взноса
									<div style={{ textDecoration: "underline" }}>{$.dateFormatRu(this.props.spec.lastPaymentDate)}</div>
								</td>
								<td className="cntr">
									<a href={"#accounts/" + this.props.acc[0].id + "/accadm/pmntadd"} className="btn-fixed">Внести</a>
								</td>
							</tr>
							<tr>
								<td>
								    Автоплатеж
                                    {(this.props.spec && this.props.spec.autopmnt && this.props.spec.autopmnt.PaymentOrderId) ?
                                    "(" + $.moneyFormatRu(this.props.spec.autopmnt.Amount) + " рублей/" + (this.props.spec.periodicityEnum.find(function (e) { return e.value == self.props.spec.autopmnt.Periodicity }) || {desc : ""}).desc + ")"
                                    : ""}
								</td>
								<td>
								    {(this.props.spec && this.props.spec.autopmnt && this.props.spec.autopmnt.PaymentOrderId) ?
                                    <a href={"#accounts/" + this.props.acc[0].id + "/accadm/pmntauto"} className="btn-fixed">Изменить</a> :
                                    <a href={"#accounts/" + this.props.acc[0].id + "/accadm/pmntauto"} className="btn-fixed">Подключить</a>
								    }
								</td>
							</tr>
							<tr>
								<td>
								    Выслать договор на почту
									<div style={{textDecoration:"underline"}}>{this.props.spec.email}</div>
								</td>
								<td>
									<a href="#" id="sendbtn" className="btn-fixed">Выслать</a>
								</td>
							</tr>
						</tbody>
                        </table>
                    </div>
                    }
                    
                    <h2>Реестр операций счета № {this.props.acc[0].acc}</h2>
                    <Griddle results={this.props.acc[0].data} columnMetadata={meta2} useGriddleStyles={false}
                         nextText={"Вперед"} previousText={"Назад"}
                         columns={["num", "date", "operation", "saldo"]}
                         tableClassName="det-table"
                         resultsPerPage={20} noDataMessage="" />
                    </div>
                );
        }
    }

    return function accAdm(doView, model) {
        this.renderFoo = doView;
        let self = this;

        this.render = function () {
            self.renderFoo(React.createElement(AccountAdmView, { acc: [model.accountData.common], spec: model.accountData.spec }));
            if (model.accountData.spec) {
                self.renderChart();
            }
        }

        this.renderChart = function () {
            var pieContainer = document.getElementById('ct-chart');
            var legContainer = document.getElementById('ct-chart-legend');
            if (pieContainer && legContainer) {
                var invest = model.accountData.spec.wholeInvest || 0.0;
                var sum = model.accountData.common.saldo - invest;
                var seriesStyles = ['pie-series-1', 'pie-series-2']
                var data = {
                    labels: [$.moneyFormatRu(sum) + '\u20bd', $.moneyFormatRu(invest) + '\u20bd', ' '],
                    series: [
                    {
                        //value: (sum || 100) * 0.7,
                        value: sum || 100,
                        className: seriesStyles[0]
                    },
                    {
                        value: invest,
                        className: seriesStyles[1]
                    }//, {value: (sum || 100) * 0.3, className: seriesStyles[0]}
                    ]
                };
                var options = {
                    chartPadding: 10,
                    width: '300px',
                    height: '300px',
                    donut: true,
                    //total: (sum + invest) * 1.5,
                    total: sum + invest,
                    //startAngle: 240,
                    startAngle: 0,
                    plugins: [
                        Chartist.plugins.legend({
                            position: legContainer,
                            legendNames: ['Расходы', 'Зарплата'],
                            classNames: seriesStyles
                        })
                    ]
                };
                new Chartist.Pie('#ct-chart', data, options);
            }
        }

        this.doControl = function () {
            if (model.location[1]) {
                if (model.location[3]) {
                    if (model.location[3].toLowerCase() === "pmntres" && model.location[4] && /^[0-9a-f]{32}$/gi.test(model.location[4])) {
                        model.getApi({
                            url: "api/auth/pmntRes/" + model.location[4],
                            callback: function (data) {
                                self.render();
                                if (data && data.status) {
                                    require(['root/jquery-confirm'], function () {
                                        $.confirm({
                                            title: false,
                                            content: data.message + '<br/>Статус: ' + data.status,
                                            buttons: {
                                                YesKey: {
                                                    text: 'ОK',
                                                    action: function () { model.redirect(model.location.slice(0, 3).join('/')) }
                                                }
                                            }
                                        });
                                    });
                                }
                            }
                        });
                    }
                    else {
                        model.route(3, function () { model.redirect(model.location.slice(0, 3).join('/')) }, model);
                    }
                }
                else {
                    self.render();
                }
            }
            else {
                model.redirect('accounts');
            }
        }
    }
});