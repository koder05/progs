﻿define(['react'], function (React) {
    class MutableField extends React.Component {
        render() {
            var data = this.props.data;
            var className = this.props.metadata.cssId || '';

            if (this.props.metadata.format) {
                if (this.props.metadata.format === "date") {
                    data = $.dateFormatRu(data);
                }
                if (this.props.metadata.format === "number") {
                    data = $.moneyFormatRu(data);
                    if (data > '') data = data.replace(' ', '\u00A0');
                }
            }

            if (this.props.metadata.link) {
                //link = { url : "#page/{0}", params : [ "num" ]}
                var ref = this.props.metadata.link.url;
                for (var i = 0; i < this.props.metadata.link.params.length; i++) {
                    var val = this.props.rowData[this.props.metadata.link.params[i]] || this.props.metadata.link.params[i];
                    ref = ref.replace('{' + i + '}', val);
                }

                data = <a className={className} href={ref}>{this.props.metadata.constData || data}</a>;
            }
            else {
                data = <span className={className}>{this.props.metadata.constData || data}</span>;
            }

            if (this.props.metadata.title) {
                data = <span><span className="tdTitle">{this.props.metadata.title}</span>{data}</span>;
            }

            return data;
        }
    }

    return MutableField;
});