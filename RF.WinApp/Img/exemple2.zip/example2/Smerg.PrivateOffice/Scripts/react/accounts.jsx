﻿define(['griddleExt.min', 'react', 'root/Griddle.min'], function (MutableField, React, Griddle) {

    class AccountsView extends React.Component {
        render() {

            const meta = [
                {
                    columnName: "num",
                    displayName: "№",
                    customComponent: MutableField,
                    title: "№"
                },
                {
                    columnName: "role",
                    displayName: "Роль клиента",
                    customComponent: MutableField,
                    title: "Роль клиента"
                },
                {
                    columnName: "type",
                    displayName: "Тип",
                    customComponent: MutableField,
                    title: "Тип"
                },
                {
                    columnName: "acc",
                    displayName: "Номер счета",
                    customComponent: MutableField,
                    title: "Номер счета",
                    cssId: "regist_forgot",
                    link: { url: "#accounts/{0}", params: ["id"] }
                },
                {
                    columnName: "db",
                    displayName: "Дата открытия",
                    customComponent: MutableField,
                    format: "date",
                    title: "Дата открытия"
                },
                {
                    columnName: "de",
                    displayName: "Дата закрытия",
                    customComponent: MutableField,
                    format: "date",
                    title: "Дата закрытия"
                },
                {
                    columnName: "saldo",
                    displayName: "Баланс, руб.",
                    customComponent: MutableField,
                    format: "number",
                    title: "Баланс, руб."
                },
                {
                    columnName: "adm",
                    displayName: " ",
                    customComponent: MutableField,
                    cssId: "btn1",
                    link: { url: "#accounts/{0}/accadm", params: ["id"] }
                }
            ];

            var opsAccounts = [];
            var npoAccounts = [];

            if (this.props.rows.length) {
                opsAccounts = this.props.rows.filter(function (r) { return r.isOps === true });
                npoAccounts = this.props.rows.filter(function (r) { return r.isOps === false })
                this.props.rows.map(function (r) { r.adm = r.isAdm === true ? 'Управление счетом' : 'Детально'; return r; });
            }
            
            var investMsg = <span>Сообщаем, что перевод пенсионных накоплений в другой фонд в 2017 г.* не приведет к потере инвестиционного дохода (<a className="green" href="https://www.npfSmerg.ru/chastnym-klientam/kak-izbezhat-poteri-dokhoda/?utm_source=lk&amp;utm_medium=13&amp;utm_campaign=13" target="_blank">Узнать&nbsp;подробнее</a>)</span>;
            opsAccounts.forEach(function (r) {
                if (r.ivestInfo && r.ivestInfo.length > 0) {
                    if (r.ivestInfo[0].Year <= 2011 || r.ivestInfo[0].Year == 2016) {
                        investMsg = <span>Напоминаем, что досрочный перевод пенсионных накоплений в другой фонд в 2017 г.* приведет к потере инвестиционного дохода <b>за 2016 г.</b> в размере <b>{$.moneyFormatRu(r.ivestInfo[0].Amount)} рублей</b>, а также инвестиционного дохода <b>за 2017 г.</b> (информация об инвестиционном доходе за 2017 г. будет известна только после окончания текущего года). <a href='https://www.npfSmerg.ru/chastnym-klientam/kak-izbezhat-poteri-dokhoda/?utm_source=lk&utm_medium=11-16&utm_campaign=11-16' className='green' target='_blank'>Узнайте,&nbsp;как&nbsp;избежать&nbsp;потерь</a></span>;
                    }
                    else if (r.ivestInfo[0].Year == 2014 || r.ivestInfo[0].Year == 2015) {
                        investMsg = <span>Напоминаем, что досрочный перевод пенсионных накоплений в другой фонд в 2017 г.* приведет к потере инвестиционного дохода <b>{$.moneyFormatRu(r.ivestInfo[0].Amount)} рублей</b>, а также инвестиционного дохода <b>за 2017 г.</b> (информация об инвестиционном доходе за 2017 г. будет известна только после окончания текущего года). <a href='https://www.npfSmerg.ru/chastnym-klientam/kak-izbezhat-poteri-dokhoda/?utm_source=lk&utm_medium=14-15&utm_campaign=14-15' className='green' target='_blank'>Узнайте,&nbsp;как&nbsp;избежать&nbsp;потерь</a></span>;
                    }
                    else if (r.ivestInfo[0].Year == 2012 || r.ivestInfo[0].Year == 2017) {
                        investMsg = <span>Напоминаем, что досрочный перевод пенсионных накоплений в другой фонд в 2017 г.* приведет к потере инвестиционного дохода <b>за 2017 г.</b>. Информация об инвестиционном доходе <b>за 2017 г.</b> будет известна только после окончания текущего года). <a href='https://www.npfSmerg.ru/chastnym-klientam/kak-izbezhat-poteri-dokhoda/?utm_source=lk&utm_medium=12-17&utm_campaign=12-17' className='green' target='_blank'>Узнайте,&nbsp;как&nbsp;избежать&nbsp;потерь</a></span>;
                    }
                }
            });

            return (
                    <div className="login">
						<h1>Пенсионные счета</h1>
                        {opsAccounts.length > 0 &&
                        <div>
						    <h2 className="hr-3">Обязательное пенсионное страхование</h2>
						    <div className="infoID">
							    Уважаемый клиент! {investMsg}
							    <div className="infoID1">
								    * Год подачи заявления и договора – 2017, год поступления накоплений к новому страховщику – 2018.
							    </div>
						    </div>
                            <Griddle results={opsAccounts} columnMetadata={meta} useGriddleStyles={false} showPager={false}
                                 columns={["num", "role", "type", "acc", "db", "de", "saldo", "adm"]}
                                 noDataMessage="" />
                        </div>
                        }
                        {npoAccounts.length > 0 &&
                        <div>
						    <h2 className="hr-3">Негосударственное пенсионное обеспечение</h2>
                            <Griddle results={npoAccounts} columnMetadata={meta} useGriddleStyles={false} showPager={false}
                                     columns={["num", "role", "type", "acc", "db", "de", "saldo", "adm"]}
                                     noDataMessage="" />
                        </div>
                        }
                    </div>
                );
        }
    }

    class AccountDetailsView extends React.Component {
        render() {

            const meta = [
                {
                    columnName: "num",
                    displayName: "№"
                },
                {
                    columnName: "date",
                    displayName: "Дата",
                    customComponent: MutableField,
                    format: "date"
                },
                {
                    columnName: "operation",
                    displayName: "Название операции"
                },
                {
                    columnName: "saldo",
                    displayName: "Сумма, руб.",
                    customComponent: MutableField,
                    format : "number"
                }
            ];

            return (
            <div className="login">
                <h1>Детализация счета №  {this.props.details.acc}</h1>
                <div className="lk-table">
                    <h2>Баланс счета: {$.moneyFormatRu(this.props.details.saldo)} руб.</h2>
                    <Griddle results={this.props.details.data} columnMetadata={meta} useGriddleStyles={false}
                        nextText={"Вперед"} previousText={"Назад"}
                        columns={["num", "operation", "date", "saldo"]}
                        tableClassName="det-table"
                        resultsPerPage={20} />
                </div>
            </div>
            );
        }
    }

    return function accounts(doView, model) {
        this.renderFoo = doView;
        let self = this;

        this.rowClick = function (r, e) {
            model.redirect(model.location[0] + "/" + r.props.data.id);
        }

        this.doControl = function () {
            if (model.location[1]) {

                model.getApi({
                    url: "api/auth/accounts/" + model.location[1],
                    callback: function (data) {
                        if (model.location[2]) {
                            model.route(2, function () { model.redirect(model.location.slice(0, 2).join('/')) }, Object.assign({}, model, { accountData: data }));
                        }
                        else {
                            self.renderFoo(React.createElement(AccountDetailsView, { details: data.common }));
                        }
                    }
                });
            }
            else {
                model.getApi({
                    url: "api/auth/accounts",
                    callback: function (data) {
                        self.renderFoo(React.createElement(AccountsView, { rows: data, onRowClick: self.rowClick }));
                    }
                });
          }
        }
    }
});