﻿define(['validationError.min','root/react-input-mask.min', 'react'], function (ValidationErrorView, ReactInputMask, React) {
    class RegisterView extends React.Component {
        render() {
            return (
<div className="login">	                
    <h1 className="h-hr">Регистрация</h1>
	<form onSubmit={this.props.onSubmit} noValidate method="post">
        {this.props.registerState == 0 &&
        <div className="lk-inputs lk-custom-2">
            <ValidationErrorView error={this.props.error} className="form-group lab-21" validatedField="ipa">
                <span className="lk-ph">Введите СНИЛС<span className="green-to-red">*</span></span>
                <ReactInputMask mask="999-999-999 99" onChange={this.props.onIpaInput} value={this.props.ipa} className="lk-inp inp-1" />
            </ValidationErrorView>
            <ValidationErrorView error={this.props.error} className="form-group lab-21" validatedField="phone">
                <span className="lk-ph">Введите номер мобильного телефона<span className="green-to-red">*</span></span>
                <ReactInputMask mask="+7 (999) 999-99-99" onChange={this.props.onPhoneInput} value={this.props.phone} className="lk-inp inp-1" />
            </ValidationErrorView>
            <ValidationErrorView error={this.props.error} className="form-group lab-21" validatedField="email">
                <span className="lk-ph">Введите адрес email<span className="green-to-red">*</span></span>
                <input name="CLIENT_EMAIL" className="lk-inp inp-1" type="text" value={this.props.email} onChange={this.props.onEmailInput} maxLength="255" />
            </ValidationErrorView>
            <div className="wrapper-btn">
                <input className="btn btn-green" type="submit" value="Регистрация" />
            </div>
        </div>
        }
        {this.props.registerState == 1 &&
        <span className="comeback-pass-descr-sf">
            Клиенту с указанным СНИЛС доступ уже предоставлен.
            <br />
            Вы можете войти в Личный кабинет под своими ранее полученными учетными данными, либо воспользоваться формой восстановления доступа
            <br /><a href="#restore">Восстановление доступа</a>
        </span>
        }
        {this.props.registerState == 2 &&
        <span className="comeback-pass-descr-sf">
            На указанный Вами адрес электронной почты отправлено письмо.<br />
            Для получения доступа к Личному кабинету необходимо подтвердить адрес e-mail, перейдя по ссылке в письме.
        </span>
        }
        {this.props.registerState == 3 &&
        <div className="lk-inputs lk-custom-2">
            Спасибо, Ваш адрес электронной почты  успешно подтвержден. Для продолжения регистрации необходимо подтвердить номер мобильного телефона.<br/>
            На указанный при регистрации номер отправлен код подтверждения.<br />
            <ValidationErrorView error={this.props.error} className="form-group lab-3" validatedField="code">
                <span className="lk-ph">Введите код<span className="green-to-red">*</span></span>
                <input name="SMSCode" className="lk-inp inp-1" type="text" value={this.props.smsCode} onChange={this.props.onSmsCodeInput} />
            </ValidationErrorView>
            <ValidationErrorView error={this.props.error} className="form-group lab-5" validatedField="rulesAgree">
                <input name="Agr" id="Agr" type="checkbox" value={this.props.agree} onChange={this.props.onAgreeInput} />Настоящим подтверждаю, что с
                <a className="green" href="privacy.asp" target="_blank">Правилами</a> обслуживания в портале удаленного доступа «Client NPF Smerg» ознакомлен и согласен.
                <br />Также подтверждаю корректность предоставленных при регистрации данных.<br />
            </ValidationErrorView>
            <input className="btn btn-green" type="submit" value="Подтвердить" />
        </div>
        }
    </form>
</div>
            );
        }
    }

    return function registerForm(doView, model) {
        this.renderFoo = doView;
        this.state = {};
        let self = this;

        this.ipaInput = function(e) {
            self.state.ipa = e.target.value;
            self.doInput();
        }

        this.phoneInput = function (e) {
            self.state.phone = e.target.value;
            self.doInput();
        }

        this.emailInput = function (e) {
            self.state.email = e.target.value;
            self.doInput();
        }

        this.smsCodeInput = function (e) {
            self.state.smsCode = e.target.value;
            self.doInput();
        }

        this.agreeInput = function (e) {
            self.state.agree = (self.state.agree || false) == false;
            self.doInput();
        }

        this.doControl = function () {
            if (model.location[1] && self.state.registerState != 3) {
                model.getApi({
                    url: "api/log/register/" + model.location[1],
                    callback: function (data) {
                        if (data.smsSend === true) {
                            self.state.registerState = 3;
                            self.renderFoo(React.createElement(RegisterView, self.state));
                        }
                        else
                        {
                            model.redirect("register");
                        }
                    }
                });
            }
            else {
                self.renderFoo(React.createElement(RegisterView, self.state));
            }
        }

        this.submit = function (e) {
            e.preventDefault();
            if (self.state.registerState == 3) {
                self.postSmsCode();
            }
            else {
                self.postRegisterRequest();
            }
        }

        this.postRegisterRequest = function () {
            model.postApi({
                url: "api/log/register",
                data: {
                    ipa: self.state.ipa,
                    phone: self.state.phone,
                    email: self.state.email
                },
                callback: function (data) {
                    self.state.registerState = (data.emailSend === true ? 2 : 1);
                    self.doControl();
                },
                validationError: function (e) {
                    self.state.error = e;
                    self.doControl();
                }
            });
        }

        this.postSmsCode = function () {
            model.postApi({
                url: "api/log/postSms",
                data: {
                    code: self.state.smsCode,
                    rulesAgree: self.state.agree,
                    requestId: model.location[1]
                },
                callback: function (data) {
                    model.prevLocation = "settings";
                    model.FirstLogonId = data.id;
                    model.redirectFromLogin(data.token);
                },
                validationError: function (e) {
                    self.state.error = e;
                    self.doControl();
                }
            });
        }

        this.doInput = function () {
            self.state.error = {};
            this.doControl();
        }

        Object.assign(this.state, model, {
            onIpaInput: this.ipaInput,
            onPhoneInput: this.phoneInput,
            onEmailInput: this.emailInput,
            onSmsCodeInput: this.smsCodeInput,
            onAgreeInput: this.agreeInput,
            onSubmit: this.submit,
            ipa: "",
            phone: "",
            email: "",
            smsCode: "",
            agree: false,
            error: {},
            registerState: 0
        });
    }
});