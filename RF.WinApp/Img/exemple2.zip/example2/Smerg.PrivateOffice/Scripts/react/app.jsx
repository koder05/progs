﻿define(['react', 'react-dom', 'module'], function(React, ReactDOM, module) {


class LeftMenuView extends React.Component {
    render() {
        var token = $.getToken();
        const isLoggedIn = token && token !== "" && token !== "undefined" && typeof (token) !== 'undefined';
        return (
            <ul>
                <li><a href="#accounts">Пенсионные счета</a></li>
                <li>
                    {isLoggedIn ? 
                    <a href="#settings">Учетные данные</a> : 
                    <a href="#register">Регистрация</a>
                    }
                </li>
                <li><a href="https://www.npfSmerg.ru/kontakty/" target="_blank">Обратная связь</a></li>
                {!isLoggedIn && 
                <li><a href="#repair">Восстановить доступ</a></li>
                }
                <li><a href="#privacy">Безопасность</a></li>
                {isLoggedIn && 
                <li><a href="#logout">Завершение сеанса</a></li>
                }
            </ul>
        );
    }
}

class NotFoundView extends React.Component {
    render() {
        return <div><h1>Not Found</h1><a href="#index">Contacts</a></div>;
    }
}

function route(locationIndex, notFoundFoo, obj) {
    switch (app.location[locationIndex]) {
        case 'logout':
            app.deleteApi({ url: "api/auth/login" });
            $.removeToken();
            redirect('');
            break;
        default:
            require([app.location[locationIndex] + module.config().ver], 
                function(controller) {
                    try{new controller(doView, obj || app).doControl()}
                    catch (e) {
                        notFoundFoo()
                    }
                }
                , function (err) { notFoundFoo() }
                );
    }
}

function auth() {
    Object.assign(app, {
        prevLocation: window.location.hash.replace('#', ''),
    });
    $.removeToken();
    redirect('auth');
}

function login(token) {
    var hash = app.prevLocation || '';
    Object.assign(app, {
        prevLocation: "",
    });
    $.setToken(token);
    redirect(hash);
}

function redirect(hash) {
    window.location.replace(
      window.location.pathname + window.location.search + '#' + hash
    );
}

function navigated(e) {
    var re = new RegExp('^#/?|/$', 'g');
    var normalizedHash = window.location.hash.replace(re, '');
    if (normalizedHash === '') {
        redirect('index');
    }
    else {
        app.location = normalizedHash.split('/');
        route(0, function() {doView(<NotFoundView />)});
    }
}

function getXHRArgs(args) {
    var ret = Object.assign({}, jqXHRArgsDefaults, args);
    ret.error  = function (jqXHR, textStatus, e, next) {
            if(jqXHR.status == 401) {
                return auth();
            }
            if (jqXHR.status == 500 && jqXHR.responseJSON.ClassName == DataAnnotationErrorKey) {
                return ret.validationError(jqXHR.responseJSON);
            }
            next();
        };
    return ret;
}

function callApiWithValidation(args, callApiFoo, httpMethod) {
    var e = getXHRArgs(args); 
    if (validator) {
        var successFoo = function () {
            if (e.validationSuccess && jQuery.isFunction(e.validationSuccess)) {
                e.validationSuccess(function () { callApiFoo(e.url, e.data, e.callback, e.error, e.done) });
            }
            else {
                callApiFoo(e.url, e.data, e.callback, e.error, e.done);
            };
        }

        if(jQuery.isFunction(validator.validate)) {
            validator.validate(args.url, httpMethod, args.data, successFoo, args.validationError)
        }
        else {
            successFoo();
        }
    }
    else {
        require(['root/dataAnnotations'], function(v) {
            validator = new v();
            callApiWithValidation(args, callApiFoo, httpMethod);
        }, 
        function (err) {
            validator = {};
            callApiWithValidation(args, callApiFoo, httpMethod);
        });
    }
}

function doView(view) {
    ReactDOM.render(
      view,
      document.getElementById('react-app')
    );
    ReactDOM.render(<LeftMenuView {...app} />, document.getElementById('lk-menu'));
}

const app = {
        location : window.location.hash,
        prevLocation : "",
        getApi: function (args) { var e = getXHRArgs(args); return $.apiGet(e.url, e.callback, e.error, e.done); },
        deleteApi: function (args) { var e = getXHRArgs(args); return $.apiDelete(e.url, e.callback, e.error, e.done); },
        postApi : function(args) { var e = getXHRArgs(args); return $.apiPost(e.url, e.data, e.callback, e.error, e.done); },
        putApi : function(args) { var e = getXHRArgs(args); return $.apiPut(e.url, e.data, e.callback, e.error, e.done); },
        postApiValidated : function(args) { callApiWithValidation(args, $.apiPost, "POST") },
        putApiValidated : function(args) { callApiWithValidation(args, $.apiPut, "PUT") },
        redirectFromLogin : function(token) { return login(token); },
        redirect : redirect,
        route: route,
        moduleVer : module.config().ver
};

const jqXHRArgsDefaults = {
        self : this,
        url : "",
        data : {},
        callback : function() {},
        done : function() {},
        validationError: function (validationErrrorArgs) { },
        validationSuccess: function (next) { }
};

var validator = null;

window.addEventListener('hashchange', navigated, false);

return navigated;

});