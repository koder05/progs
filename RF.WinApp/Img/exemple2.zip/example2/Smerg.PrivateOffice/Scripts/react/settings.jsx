﻿define(['validationError.min', 'react'], function (ValidationErrorView, React) {
    class SettingsView extends React.Component {
        render() {
            return (
<div className="login">
	<h1 className="h-hr">Настройка учетных данных</h1>
    <div className="lk-inputs lk-custom-2">
		<span className="comeback-pass-descr-sf">
			{this.props.RestoreLogonId && "Пожалуйста, смените Ваш пароль."}
            {this.props.FirstLogonId && "Пожалуйста, установите логин и пароль."}
			{this.props.IsSuccess && "" + this.props.IsSuccess}
		</span>
        {!this.props.IsSuccess && 
	    <form onSubmit={this.props.onSubmit} noValidate method="post">
            <ValidationErrorView error={this.props.error} className="form-group lab-5" validatedField="error" />
            {!this.props.FirstLogonId &&
            <label className="form-group lab-22">
				<span className="lk-ph">Текущий логин</span>
				<input className="lk-inp inp-1" id="currentlogin" disabled type="text" value={this.props.user.login} />
			</label>
            }
			<ValidationErrorView error={this.props.error} className="form-group lab-22" validatedField="login">
				<span className="lk-ph">Введите новый логин<span className="green-to-red">*</span></span>
				<input name="USER_LOGINNAME_NEW" className="lk-inp inp-1" type="text" maxLength="255" value={this.props.login} onChange={this.props.onLoginInput} />
			</ValidationErrorView>
			<ValidationErrorView error={this.props.error} className="form-group lab-22" validatedField="pswNew">
				<span className="lk-ph">Введите новый пароль<span className="green-to-red">*</span></span>
				<input name="CLIENT_PASSWORD_NEW" className="lk-inp inp-1" type="password" maxLength="255" id="password" value={this.props.pswNew} onChange={this.props.onPswNewInput} />
			</ValidationErrorView>
			<ValidationErrorView error={this.props.error} className="form-group lab-22" validatedField="pswNewRep">
				<span className="lk-ph">Повторите новый пароль<span className="green-to-red">*</span></span>
				<input name="CLIENT_PASSWORD_NEW_CONFIRM" className="lk-inp inp-1" type="password" maxLength="255" id="password1" value={this.props.pswNewRep} onChange={this.props.onPswNewRepInput} />
			</ValidationErrorView>
	        {!(this.props.FirstLogonId) && !(this.props.RestoreLogonId) &&
            <ValidationErrorView error={this.props.error} className="form-group lab-22" validatedField="psw">
				<span className="lk-ph">Введите текущий пароль<span className="green-to-red">*</span></span>
				<input name="CLIENT_PASSWORD" className="lk-inp inp-1" type="password" maxLength="255" id="password2" value={this.props.psw} onChange={this.props.onPswInput} />
            </ValidationErrorView>
	        }
			<div className="wrapper-btn">
                <input className="btn btn-green" id="submitbtn" type="submit" value="Сменить" />
			</div>
            <span className="comeback-pass-descr-sf">
                В целях безопасности ваш пароль должен содержать не менее 8 символов, содержать цифры, буквы (используются только буквы латинского алфавита) и не менее одной заглавной буквы. Первым символом пароля должна быть буква. В числе символов пароля рекомендуется использовать буквы верхнего и нижнего регистров, цифры и специальные символы (@ # $ % & * и др.).
            </span>
	    </form>
        }
    </div>
</div>
            );
        }
    }

return function settingsForm(doView, model) {
    this.renderFoo = doView;
    this.state = {};
    let self = this;

    this.loginInput = function(e) {
        self.state.login = e.target.value;
        self.doInput();
    }

    this.pswInput = function (e) {
        self.state.psw = e.target.value;
        self.doInput();
    }

    this.pswNewInput = function (e) {
        self.state.pswNew = e.target.value;
        self.doInput();
    }

    this.pswNewRepInput = function (e) {
        self.state.pswNewRep = e.target.value;
        self.doInput();
    }

    this.doControl = function () {
        model.getApi({
            url: "api/auth/user",
            callback: function (data) {
                self.state.user = data;
                self.renderFoo(React.createElement(SettingsView, self.state));
            }
        });
    }

    this.submit = function (e) {
        e.preventDefault();
        var apiParams = {
            url: "api/auth/user",
            data: {
                login: self.state.login,
                psw: self.state.psw,
                pswNew: self.state.pswNew,
                pswNewRep: self.state.pswNewRep
            },
            callback: function (data) {
                var isSuccess = (model.FirstLogonId && "Учетные данные внесены!") || (model.RestoreLogonId && "Ваш пароль успешно изменен!") || "Учетные данные успешно изменены!";
                model.FirstLogonId = undefined;
                model.RestoreLogonId = undefined;
                $.setToken(data.token);
                self.renderFoo(React.createElement(SettingsView, {IsSuccess : isSuccess}));
            },
            validationError: function (e) {
                self.state.error = e;
                self.renderFoo(React.createElement(SettingsView, self.state));
            }
        }
        if (model.FirstLogonId) {
            apiParams.data.psw = model.FirstLogonId;
            model.postApi(apiParams);
        }
        else {

            if (model.RestoreLogonId) {
                apiParams.data.url = "api/auth/userRestore";
                apiParams.data.psw = model.RestoreLogonId;
            }

            model.putApi(apiParams);
        }
    }

    this.doInput = function () {
        self.state.error = {};
        self.renderFoo(React.createElement(SettingsView, self.state));
    }

    Object.assign(this.state, model, {
        onLoginInput: this.loginInput,
        onPswInput: this.pswInput,
        onPswNewInput: this.pswNewInput,
        onPswNewRepInput: this.pswNewRepInput,
        onSubmit: this.submit,
        login: "",
        psw: "",
        pswNew: "",
        pswNewRep: "",
        error: {}
    });
}
});