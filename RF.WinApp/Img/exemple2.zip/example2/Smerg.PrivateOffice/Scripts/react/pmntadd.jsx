﻿define(function () {
    return function (doView, model) {
        this.doControl = function () {
            require(['pmntauto' + model.moduleVer], function (pmntauto) {

                var c = new pmntauto(doView, model);
                c.state.periodicity = 0;
                c.doControl();

            });
        }
    }
});