﻿define(['react'], function (React) {
    class IntroView extends React.Component {
        render() {
            var genderSuffix = this.props.gender == 'Famale' ? "ая" : "ый";
            return <h2>Уважаем{genderSuffix} {this.props.surname}! Добро пожаловать в личный кабинет НПФ «smerg».</h2>;
        }
    }

    return function intro(doView, model) {
        this.renderFoo = doView;
        this.state = {};
        let self = this;


        this.doControl = function () {
            model.getApi({
                url: "api/auth/user",
                callback: function (data) {
                    self.renderFoo(React.createElement(IntroView, data));
                }
            });
        }
    }
});
