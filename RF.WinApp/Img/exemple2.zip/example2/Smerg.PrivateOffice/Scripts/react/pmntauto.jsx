﻿define(['validationError.min', 'react'], function (ValidationErrorView, React) {

    class AutoPaymentAddView extends React.Component {
        render() {

            var periodicityOptions = [];
            if (this.props.accountData.spec) {
                $(this.props.accountData.spec.periodicityEnum).each(function (i, e) {
                    periodicityOptions.push(<option key={i} value={e.value}>{e.desc}</option>);
                });
            }


            return (
<div className="login">	
    <div className="lk-inputs lk-custom-2">
        <h2 className="h-hr">{this.props.periodicity === 0 ? "Единоразовый" : "Регулярный"} платеж по договору №{this.props.accountData.common.agree}</h2>
        <form action="" method="post" onSubmit={this.props.onSubmit}>
            <ValidationErrorView error={this.props.error} className="form-group lab-5" validatedField="error" />
            {this.props.pmntRefuse === false && this.props.periodicity !== 0 &&
            <ValidationErrorView error={this.props.error} className="form-group lab-23" validatedField="periodicity">
                <span className="lk-ph">Периодичность:<span className="green-to-red">*</span></span>
                <select className="lk-inp-sel inp-2-sel" value={this.props.periodicity} onChange={this.props.onPeriodicitySelect}>
				    <option value="-1">не выбрано</option>
                    {periodicityOptions}
                </select>
            </ValidationErrorView>
            }
            {this.props.pmntRefuse === false &&
            <ValidationErrorView error={this.props.error} className="form-group lab-23" validatedField="amount">
                <span className="lk-ph">Сумма:<span className="green-to-red">*</span></span>
                <input name="Amount" className="lk-inp inp-2" type="text" id="Amount" maxLength="255" value={this.props.amount}
                       onChange={this.props.onAmountInput} onBlur={this.props.onAmountBlur} />
            </ValidationErrorView>
            }
            {this.props.hasAutoPnmt && this.props.periodicity !== 0 &&
            <ValidationErrorView error={this.props.error} className="form-group lab-5" validatedField="pmntRefuse">
                <input type="checkbox" value={this.props.pmntRefuse} onChange={this.props.onPmntRefuseInput} />Отменить регулярный платеж
            </ValidationErrorView>
            }
             <div className="wrapper-btn">
                 <input type="submit" className="btn btn-green" 
                    value={this.props.periodicity === 0 ? "Внести" : (this.props.hasAutoPnmt ? (this.props.pmntRefuse === false ? "Изменить" : "Отменить") : "Подключить")} />
             </div>
        </form>
    </div>					
</div>
        );}
    }

    return function(doView, model) {
        this.renderFoo = doView;
        let self = this;
        this.state = {};

        this.amountInput = function (e) {
            self.state.amount = e.target.value;
            self.doInput();
        }

        this.amountBlur = function (e) {
            self.state.amount = $.moneyFormatRu(e.target.value);
            self.doInput();
        }

        this.periodicitySelect = function (e) {
            self.state.periodicity = parseInt(e.target.value);
            self.doInput();
        }

        this.pmntRefuseInput = function (e) {
            self.state.pmntRefuse = (self.state.pmntRefuse || false) == false;
            self.doInput();
        }

        this.getPmntOperationParams = function () {
            var postModel = {
                acc: model.location[1],
                agree: model.accountData.common.agree,
                amount: $.str2num(self.state.amount),
                periodicity: self.state.periodicity,
                returnUrl: window.location.href.replace(model.location[3], "pmntres")
            }
            return {
                url: "api/auth/pmnt",
                data: postModel,
                callback: function (data) {
                    if (data.PurchaseUrl > "") {
                        window.location.assign(data.PurchaseUrl);
                    }
                    else {
                        require(['root/jquery-confirm'], function () {
                            $.alert({
                                title: false,
                                content: 'Не удалось отправить запрос оплату! Статус: ERROR'
                            });
                        });
                    }
                },
                validationSuccess: function (next) {
                    var periodicityText = '';
                    if (model.accountData.spec && model.accountData.spec.periodicityEnum) {
                        var e = $.grep(model.accountData.spec.periodicityEnum, function (e) { return e.value === postModel.periodicity });
                        if (e && e.length > 0) {
                            periodicityText = e.desc;
                        }
                    }
                    require(['root/jquery-confirm'], function () {
                        $.confirm({
                            title: false,
                            content: "Подтверждаете платеж по договору №" + model.accountData.common.agree + " в размере " + $.moneyFormatRu(postModel.amount) + " руб. " + periodicityText + "?",
                            buttons: {
                                YesKey: {
                                    text: 'Да',
                                    action: next
                                },
                                NoKey: {
                                    text: 'Нет',
                                    action: function () { }
                                }
                            }
                        });
                    });
                },
                validationError: function (e) {
                    self.state.error = e;
                    self.renderFoo(React.createElement(AutoPaymentAddView, self.state));
                }
            };
        }

        this.pmntAdd = function () {
            model.postApiValidated(self.getPmntOperationParams());
        }

        this.pmntUpdate = function () {
            var args = self.getPmntOperationParams();
            args.callback = function (data) {
                model.location.splice(3, 0, "pmntres");
                model.location.splice(4, 0, data);
                model.redirect(model.location.slice(0, 5).join('/'));
            }
            model.putApiValidated(args);
        }

        this.pmntRefuse = function () {

            require(['root/jquery-confirm'], function () {
                $.confirm({
                    title: false,
                    content: "Подтверждаете отмену автоплатежей по договору  №" + model.accountData.common.agree + "?",
                    buttons: {
                        YesKey: {
                            text: 'Да',
                            action: function () {
                                model.deleteApi({
                                    url: "api/auth/pmnt/" + model.accountData.common.agree,
                                    callback: function (data) {
                                        model.location.splice(3, 0, "pmntres");
                                        model.location.splice(4, 0, data);
                                        model.redirect(model.location.slice(0, 5).join('/'));
                                    }
                                });
                            }
                        },
                        NoKey: {
                            text: 'Нет',
                            action: function () { }
                        }
                    }
                });
            });
        }

        this.submit = function (e) {
            e.preventDefault();
            if (self.state.hasAutoPnmt) {
                if (self.state.pmntRefuse) {
                    self.pmntRefuse();
                }
                else {
                    self.pmntUpdate();
                }
            }
            else {
                self.pmntAdd();
            }
        }

        this.doInput = function () {
            self.state.error = {};
            self.renderFoo(React.createElement(AutoPaymentAddView, self.state));
        }

        this.doControl = function () {
            if (model.location[1]) {
                self.renderFoo(React.createElement(AutoPaymentAddView, self.state));
            }
            else {
                model.redirect('accounts');
            }
        }

        Object.assign(this.state, model, {
            onAmountInput: this.amountInput,
            onAmountBlur: this.amountBlur,
            onPeriodicitySelect: this.periodicitySelect,
            onPmntRefuseInput: this.pmntRefuseInput,
            onSubmit: this.submit,
            hasAutoPnmt: model.accountData.spec && model.accountData.spec.autopmnt && model.accountData.spec.autopmnt.PaymentOrderId,
            amount: "",
            periodicity: -1,
            pmntRefuse: false,
            error: {}
        });
    }
});