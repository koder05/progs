﻿define(['validationError.min', 'react'], function (ValidationErrorView, React) {
    class RestoreView extends React.Component {
        render() {
            return (
<div className="login">	                
    <h1 className="h-hr">Восстановление пароля</h1>				
    <form onSubmit={this.props.onSubmit} noValidate method="post">
        {(this.props.restoreState == 0 || this.props.restoreState == 3) &&
        <div className="lk-inputs lk-custom-2">
            {this.props.restoreState == 0 &&
            <ValidationErrorView error={this.props.error} className="form-group lab-21" validatedField="email">
                <span className="lk-ph">Введите адрес электронной почты<span className="green-to-red">*</span></span>
                <input name="restore_email" className="lk-inp inp-1" type="text" id="restore_email" value={this.props.email} onChange={this.props.onEmailInput} />
            </ValidationErrorView>
            }
            <ValidationErrorView error={this.props.error} className="form-group lab-21" validatedField="captcha">
                <span className="lk-ph">Введите символы с картинки<span className="green-to-red">*</span></span>
                <input name="txtCaptcha" className="lk-inp inp-1" type="text" id="txtCaptcha" value={this.props.captcha.text} onChange={this.props.onCaptchaInput} />
            </ValidationErrorView>
            <div>
                &nbsp;
                <img id="imgCaptcha" src={"captcha.axd?guid=" + this.props.captcha.id} title="Кликните, чтобы обновить" alt="CAPTCHA" style={{cursor: "pointer"}}
                        onClick={this.props.onCaptchaRenew} width={this.props.captcha.width} height={this.props.captcha.height} />
                <div className="wrapper-btn">
                    <input className="btn btn-green" type="submit" value="Восстановить" />
                </div>
            </div>
        </div>
        }
        {this.props.restoreState == 1 &&
        <span className="comeback-pass-descr-sf">На указанный Вами адрес электронной почты отправлено письмо, для инициализации восстановления пароля.</span>
        }
        {this.props.restoreState == 2 &&
        <span className="comeback-pass-descr-sf">Вам уже отправлено электронное письмо на Ваш адрес электронной почты. Если Вы не получили письмо, проверьте работу Вашего спам фильтра или папку Спам.</span>
        }
    </form>
</div>    );
    }
}

return function restoreForm(doView, model) {
    this.renderFoo = doView;
    this.state = {};
    let self = this;

    this.emailInput = function (e) {
        self.state.email = e.target.value;
        self.doInput();
    }

    this.captchaInput = function (e) {
        self.state.captcha.text = e.target.value;
        self.doInput();
    }

    this.captchaRenew = function () {
        model.getApi({
            url: "api/log/captcha",
            callback: function (data) {
                self.state.captcha = Object.assign(data, { text: "" });
                self.renderFoo(React.createElement(RestoreView, self.state));
            }
        });
    }

    this.doControl = function () {
        if (model.location[1] && self.state.restoreState != 3) {
            model.getApi({
                url: "api/log/restore/" + model.location[1],
                callback: function (data) {
                    if (data.smsSend === true) {
                        self.state.restoreState = 3;
                        self.captchaRenew();
                    }
                    else
                    {
                        model.redirect("restore");
                    }
                }
            });
        }
        else {
            this.captchaRenew();
        }
    }

    this.submit = function (e) {
        e.preventDefault();
        if (model.location[1] && self.state.restoreState == 3) {
            self.confirmRestoreRequest();
        }
        else {
            self.postRestoreRequest();
        }
    }

    this.postRestoreRequest = function () {
        model.postApi({
            url: "api/log/restore",
            data: {
                email: self.state.email,
                captcha: self.state.captcha
            },
            callback: function (data) {
                self.state.restoreState = (data.emailSend === true ? 1 : 2);
                self.doInput();
            },
            validationError: function (e) {
                self.state.error = e;
                self.captchaRenew();
            }
        });
    }

    this.confirmRestoreRequest = function () {
        model.putApi({
            url: "api/log/restore",
            data: {
                id: model.location[1],
                captcha: self.state.captcha
            },
            callback: function (data) {
                if (data.confirmed === true) {
                    model.prevLocation = "settings";
                    model.RestoreLogonId = data.newPsw;
                    model.redirectFromLogin(data.token);
                }
                else {
                    model.redirect("restore");
                }
            },
            validationError: function (e) {
                self.state.error = e;
                self.captchaRenew();
            }
        });
    }

    this.doInput = function () {
        self.state.error = {};
        self.renderFoo(React.createElement(RestoreView, self.state));
    }

    Object.assign(this.state, model, {
        onIpaInput: this.ipaInput,
        onCaptchaRenew : this.captchaRenew,
        onEmailInput: this.emailInput,
        onCaptchaInput: this.captchaInput,
        onSubmit: this.submit,
        email: "",
        error: {},
        restoreState: 0
    });
}
});