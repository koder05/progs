﻿if (typeof Object.assign != 'function') {
    Object.assign = function (target) {
        'use strict';
        if (target == null) {
            throw new TypeError('Cannot convert undefined or null to object');
        }

        target = Object(target);
        for (var index = 1; index < arguments.length; index++) {
            var source = arguments[index];
            if (source != null) {
                for (var key in source) {
                    if (Object.prototype.hasOwnProperty.call(source, key)) {
                        target[key] = source[key];
                    }
                }
            }
        }
        return target;
    };
}

jQuery.extend({
    setToken: function (token) {
        if (window.localStorage && typeof (window.localStorage) !== 'undefined') {
            window.localStorage.setItem('bearer', token);
        }
        else {
            window.name = token;
        }
    },
    getToken: function () {
        if (window.localStorage && typeof (window.localStorage) !== 'undefined') {
            return window.localStorage.getItem('bearer');
        }
        else {
            return window.name;
        }
    },
    removeToken: function () {
        if (window.localStorage && typeof (window.localStorage) !== 'undefined') {
            window.localStorage.removeItem('bearer');
        }
        else {
            window.name = "";
        }
    },
    str2num : function(n) {
        if (typeof (n) === 'string') {
            var sign = n.indexOf('-') === 0 ? '-' : '';
            n = n.replace(/[^0-9.,]/g, '');
            n = n.replace(/,/g, '.');
            var a = n.split('.');
            if (a.length > 1) {
                n = '';
                for (var i = 0; i < a.length - 1; i++) {
                    n += a[i];
                }
                n += '.' + a[a.length - 1];
            }
            n = sign + n;
            n = parseFloat(n);
        }
        return n;
    },
    dateFormatRu: function (date) {
        if (typeof (date) === 'undefined' || date === null || date === "")
            return date;
        var d = new Date(date);
        return ("0" + d.getDate()).slice(-2) + "." + ("0" + (d.getMonth() + 1)).slice(-2) + "." + d.getFullYear();
    },
    moneyFormatRu: function (num) {
        if (typeof (num) === 'undefined' || num === "")
            return num;
        var n = num;
        if (typeof (n) === 'string') {
            n = $.str2num(n);
        }
        if ($.isNumeric(n)) {
            n = n.toFixed(2).toString();
            var sign = n.indexOf('-') === 0 ? '-' : '';
            return sign + n.replace('-','').replace(/./g, function (c, i, a) {
                return i && c !== "." && ((a.length - i) % 3 === 0) ? ' ' + c : (c === "." ? ',' : c);
            });
        }
        return num;
    }
});

function _ajax_request(url, data, callback, method, errCallback, doneCallback) {
    var door = $("#myModal");
    var doorTimer = window.setTimeout(function () { door.css("display", "block"); }, 150);
    return jQuery.ajax({
        type: method,
        beforeSend: function (request) {
            var token = $.getToken();
            if (token && token !== "" && token !== "undefined" && typeof (token) !== 'undefined')
                request.setRequestHeader("Authorization", 'Bearer ' + token);
        },
        url: url,
        data: data !== null ? JSON.stringify(data) : data,
        success: callback,
        error: function (jqXHR, textStatus, e) {
            var doContinue = false;
            if (jQuery.isFunction(errCallback)) {
                errCallback(jqXHR, textStatus, e, function () { doContinue = true; });
            }
            else {
                doContinue = true;
            }

            if (doContinue) {
                var errorMsg = e;
                if (jqXHR.responseText) {
                    var jsonError = jQuery.parseJSON(jqXHR.responseText);
                    if (jsonError) {
                        var err = jsonError.Message;
                        if (typeof err === 'object') {
                            if (err.error && err.error.message)
                                errorMsg = ((err.error.name || err.error.type || err.error.code) ? (err.error.name || err.error.type || err.error.code) + '\n' : '') + err.error.message;
                            else if (err.message)
                                errorMsg = ((err.name || err.type || err.code) ? (err.name || err.type || err.code) + '\n' : '') + err.message;
                            else
                                errorMsg = jqXHR.responseText;
                        }
                        else if (typeof err === 'string') {
                            errorMsg = err;
                        }
                    }
                }
                alert('Ошибка:\n' + errorMsg);
            }
        },
        complete: function () {
            if (jQuery.isFunction(doneCallback)) {
                doneCallback();
            }
            window.clearTimeout(doorTimer);
            window.setTimeout(function () { door.css("display", "none"); }, 100);
        },
        dataType: 'json',
        contentType: "application/json"
    });
}

jQuery.extend({
    apiGet: function (url, callback, error, done) {
        return _ajax_request(url, null, callback, 'GET', error, done);
    },
    apiPost: function (url, data, callback, error, done) {
        if (jQuery.isFunction(data)) {
            done = error;
            error = callback;
            callback = data;
            data = {};
        }
        return _ajax_request(url, data, callback, 'POST', error, done);
    },
    apiPut: function (url, data, callback, error, done) {
        if (jQuery.isFunction(data)) {
            done = error;
            error = callback;
            callback = data;
            data = {};
        }
        return _ajax_request(url, data, callback, 'PUT', error, done);
    },
    apiDelete: function (url, callback, error, done) {
        return _ajax_request(url, null, callback, 'DELETE', error, done);
    }
});
