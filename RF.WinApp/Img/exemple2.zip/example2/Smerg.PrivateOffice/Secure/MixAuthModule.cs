﻿using System;
using System.Web;
using RF.Sts.Auth;

namespace Smerg.PrivateOffice.Secure
{
    public class MixAuthModule : IHttpModule
    {
        public const string AuthAreaName = "auth";
        private OAuthProtectionModule _oauthModule;

        public void Dispose()
        {
            _oauthModule.Dispose();
        }

        public void Init(HttpApplication context)
        {
            _oauthModule = new OAuthProtectionModule();

            context.AuthenticateRequest += OnAuthenticateRequest;
            context.PostAuthenticateRequest += OnPostAuthenticateRequest;
            context.EndRequest += OnEndRequest;

            HttpApplication fakeApp = new HttpApplication();
            _oauthModule.Init(fakeApp);
        }

        void OnAuthenticateRequest(object sender, EventArgs args)
        {
            if (IsProtectedArea((HttpApplication)sender))
            {
                _oauthModule.OnAuthenticateRequest(sender, args);
            }
        }

        void OnPostAuthenticateRequest(object sender, EventArgs args)
        {
            if (IsProtectedArea((HttpApplication)sender))
            {
                _oauthModule.OnPostAuthenticateRequest(sender, args);
            }
        }

        void OnEndRequest(object sender, EventArgs args)
        {
            if (IsProtectedArea((HttpApplication)sender))
            {
                _oauthModule.OnEndRequest(sender, args);
            }
        }

        private bool IsProtectedArea(HttpApplication app)
        {
            HttpContext context = app.Context;
            var apiPath = context.Request.ApplicationPath == "/" ? context.Request.Path : context.Request.Path.Replace(context.Request.ApplicationPath, "");
            return apiPath.StartsWith(string.Concat("/api/", AuthAreaName, "/"));
        }
    }
}
