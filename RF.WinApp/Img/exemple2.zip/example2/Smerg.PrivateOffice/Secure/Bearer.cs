﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Web;
using Microsoft.IdentityModel.Claims;
using Smerg.PrivateOffice.BL.Models;
using RF.Sts.Auth;
using RF.Sts.Auth.Configuration;

namespace Smerg.PrivateOffice.Secure
{
    public static class Bearer
    {
        public static string IssueBearerToken(this User user)
        {
            string key = OAuthConfiguration.Configuration.StsSettings.SymmetricKey;
            TimeSpan lifeTime = new TimeSpan(0, 0, OAuthConfiguration.Configuration.StsSettings.TokenLifeTimeInSec);

            var claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Name, user.Name));
            var n = Obfuscator.ObfuscateClientName(user.Client);
            if (string.IsNullOrEmpty(n))
                n = user.Name;
            claims.Add(new Claim(ClaimTypes.Surname, n));
            claims.Add(new Claim(ClaimTypes.Email, Obfuscator.ObfuscateEmail(user.Client.Email)));
            claims.Add(new Claim(ClaimTypes.PrimarySid, user.Client.ClientId.ToString()));
            claims.Add(new Claim(ClaimTypes.Gender, user.Client.Gender.ToString()));
            //claims.Add(new Claim(ClaimTypes.Role, "Administrator"));

            SimpleWebToken token = new SimpleWebToken(
                OAuthConfiguration.Configuration.ServiceSettings.Realm
                , OAuthConfiguration.Configuration.StsSettings.IssuerUri.ToString()
                , DateTime.UtcNow + lifeTime, claims, key);

            //var tokenResponse = new TokenResponse() { AccessToken = token.ToString(), TokenType = "bearer", ExpiresIn = 600 };
            //return Request.CreateResponse<TokenResponse>(HttpStatusCode.OK, tokenResponse);

            byte[] bytes = Encoding.UTF8.GetBytes(token.ToString());
            return Convert.ToBase64String(bytes);
        }
    }
}