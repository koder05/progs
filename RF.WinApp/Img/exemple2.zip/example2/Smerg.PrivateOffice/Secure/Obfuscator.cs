﻿using System;
using System.Collections.Generic;
using System.Text;
using Smerg.PrivateOffice.BL.Models;

namespace Smerg.PrivateOffice.Secure
{
    public static class Obfuscator
    {
        public static string ObfuscateEmail(string email)
        {
            if (string.IsNullOrEmpty(email) == false)
            {
                var parts = email.Split('@');
                if (parts.Length == 2)
                {
                    string obfuscated = "{0}*******@" + parts[1];
                    if (parts[0].Length == 0)
                        return string.Format(obfuscated, "");
                    if (parts[0].Length <= 3)
                        return string.Format(obfuscated, parts[0].Substring(0,1));
                    if (parts[0].Length <= 5)
                        return string.Format(obfuscated, parts[0].Substring(0, 2));

                    return string.Format(obfuscated, parts[0].Substring(0, 3));
                }
            }
            return email;
        }

        public static string ObfuscateClientName(Client client)
        {
            StringBuilder sb = new StringBuilder();
            if(!string.IsNullOrEmpty(client.FirstName))
            {
                sb.Append(client.FirstName);
                if (!string.IsNullOrEmpty(client.MiddleName))
                {
                    sb.Append(" ");
                    sb.Append(client.MiddleName);
                }
                if (!string.IsNullOrEmpty(client.LastName))
                {
                    sb.Append(" ");
                    sb.Append(client.LastName.Substring(0,1));
                    sb.Append(".");
                }
            }
            else if(!string.IsNullOrEmpty(client.FullName))
            {
                sb.Append(client.FullName);
            }
            return sb.ToString();
        }
    }
}