﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Smerg.PrivateOffice.Captcha
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class CaptchaValidateAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var m = value as Smerg.PrivateOffice.Models.Captcha;

            if (m != null)
            {
                var image = HttpRuntime.Cache[m.id] as CaptchaImage;
                string err = string.Empty;

                if (image == null)
                    return new ValidationResult("Защита от спама: Таймаут проверочного кода истёк.");

                if (image.Text.Equals(m.text, StringComparison.CurrentCultureIgnoreCase) == false)
                    return new ValidationResult("Защита от спама: Проверочный код введен неправильно.");

                return ValidationResult.Success;
            }

            return new ValidationResult("Защита от спама.");
        }
    }

}