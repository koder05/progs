﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web;

namespace Smerg.PrivateOffice.Models
{
    public class Captcha 
    {
        public string challengeFieldKey { get; set; }
        public string responseFieldKey { get; set; }
        public string id { get; set; }
        public string text { get; set; }
        public int height { get; set; }
        public int width { get; set; }
    }
}