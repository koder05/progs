﻿using System;
using System.Web;
using System.Web.Routing;

namespace Smerg.PrivateOffice
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.Add(new IndexPageRoutesHandler());
        }

        internal class IndexPageRoutesHandler : RouteBase
        {
            public override RouteData GetRouteData(HttpContextBase httpContext)
            {
                if (httpContext.Request.Path == "/")
                {
                    httpContext.Response.ContentType = "text/html";
                    httpContext.Response.TransmitFile("app.html");
                    httpContext.Response.End();
                }
                return null;
            }

            public override VirtualPathData GetVirtualPath(RequestContext requestContext,
                        RouteValueDictionary values)
            {
                return null;
            }
        }
    }
}
