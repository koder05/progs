﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Routing;

namespace Smerg.PrivateOffice
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;

            config.MapHttpAttributeRoutes();
            //RegisterWithPrefix(config.Routes, "log");
            //RegisterWithPrefix(config.Routes, "auth");

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/log/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            config.Routes.MapHttpRoute(
                name: "SecureApi",
                routeTemplate: "api/auth/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //config.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Serialize;
            //config.Formatters.JsonFormatter.SerializerSettings.PreserveReferencesHandling = PreserveReferencesHandling.Objects;
        }
        private static void RegisterWithPrefix(HttpRouteCollection routes, string prefix)
        {
            routes.MapHttpRoute(prefix + "DefaultApiWithId", string.Format("api/{0}/{{controller}}/{{id}}", prefix), new { id = RouteParameter.Optional });
            routes.MapHttpRoute(prefix + "DefaultApiWithAction", string.Format("api/{0}/{{controller}}/{{action}}", prefix));
            routes.MapHttpRoute(prefix + "DefaultApiGet", string.Format("api/{0}/{{controller}}", prefix), new { action = "Get" }, new { httpMethod = new HttpMethodConstraint(HttpMethod.Get) });
            routes.MapHttpRoute(prefix + "DefaultApiPost", string.Format("api/{0}/{{controller}}", prefix), new { action = "Post" }, new { httpMethod = new HttpMethodConstraint(HttpMethod.Post) });
        }
    }
}
