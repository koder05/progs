﻿using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Smerg.PrivateOffice.Models;
using Smerg.PrivateOffice.Secure;
using Smerg.PrivateOffice.BL.Repo;
using Smerg.PrivateOffice.BL.Logging;
using RF.Common;
using RF.Common.Logging;

namespace Smerg.PrivateOffice.Controllers
{
    public class RegisterController : ApiController
    {
        private IClientRepo _clRepo;
        private IRegistrationRepo _regRepo;
        private ISmsService _smsRepo;
        private IUserRepo _userRepo;

        public RegisterController(IClientRepo clRepo, IRegistrationRepo regRepo, ISmsService smsRepo, IUserRepo userRepo) : base()
        {
            _clRepo = clRepo;
            _regRepo = regRepo;
            _smsRepo = smsRepo;
            _userRepo = userRepo;
        }

        public HttpResponseMessage Get(string id)
        {
            try
            {
                var reg = _regRepo.GetRegistration(id);
                if (null != reg)
                {
                    if (reg.SmsStatus == 0)
                    {
                        _smsRepo.SendSms(reg.Phone, reg.SmsCode.ToString());
                        reg.SmsStatus = 1;
                        _regRepo.Update();
                    }

                    return Request.CreateResponse<object>(HttpStatusCode.OK, new { smsSend = true });
                }

                return Request.CreateResponse<object>(HttpStatusCode.OK, new { smsSend = false });

            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        [ValidationActionFilter]
        public HttpResponseMessage Post([FromBody]RegisterRequest value)
        {
            try
            {
                //if (!ModelState.IsValid)                    return this.ResponseOnInvalidate();
                var client = _clRepo.TryFind(value.ipa, value.email, value.phone);
                if (client != null)
                {
                    var user = _userRepo.GetUserById(client.ClientId);
                    if (user == null)
                    {
                        var r = _regRepo.BeginRegistration(client.ClientId, value.email, value.phone);
                        var emailSender = new EMailSender(ConfigurationManager.GetSupportEmail(), r.Email, "Предоставление доступа", r.EmailMessage);
                        emailSender.SendEmail();
                        Logs.LogApp.Log(new SentEmail()
                            {
                                MailFrom = emailSender.MailFrom,
                                MailSubject = emailSender.MailSubject,
                                MailTo = emailSender.MailTo,
                                MailTextBody = emailSender.MailBody,
                                MailReplyTo = emailSender.MailReplyTo
                            }
                            , "Smpt", "Smpt");
                        return Request.CreateResponse<object>(HttpStatusCode.OK, new { emailSend = true });
                    }

                    return Request.CreateResponse<object>(HttpStatusCode.OK, new { emailSend = false });
                }

                return this.ResponseOnInvalidate("", "Ошибка в идентификации клиента.");
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        [AcceptVerbs("POST")]
        [Route("api/log/postSms")]
        [ValidationActionFilter]
        public HttpResponseMessage PostSms([FromBody]RegisterSmsVerify value)
        {
            try
            {
                //if (!ModelState.IsValid)                    return this.ResponseOnInvalidate();
                var reg = _regRepo.GetRegistration(value.requestId);
                if (reg != null)
                {
                    int code = -1;
                    Int32.TryParse(value.code, out code);
                    if (reg.SmsCode == code)
                    {
                        var user = _userRepo.NewUser(reg);
                        return Request.CreateResponse<object>(HttpStatusCode.OK, new { token = user.IssueBearerToken(), id = reg.RegistrationId });
                    }
                }

                return this.ResponseOnInvalidate("code", "Неверный код");
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }
    }
}
