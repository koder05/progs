﻿using System;
using System.Web.Http;
using Smerg.PrivateOffice.Captcha;

namespace Smerg.PrivateOffice.Controllers
{
    public class CaptchaController : ApiController
    {
        public object Get()
        {
            CaptchaImage image = new CaptchaImage
            {
                Height = 50,
                Width = 150,
            };

            return new Smerg.PrivateOffice.Models.Captcha()
            {
                challengeFieldKey = CaptchaImage.ChallengeFieldKey,
                responseFieldKey = CaptchaImage.ResponseFieldKey,
                id = image.UniqueId,
                height = image.Height,
                width = image.Width
            };
        }
    }
}
