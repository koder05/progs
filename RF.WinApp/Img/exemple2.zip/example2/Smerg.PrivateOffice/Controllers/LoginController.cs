﻿using System;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Microsoft.IdentityModel.Claims;
using Smerg.PrivateOffice.Models;
using Smerg.PrivateOffice.BL.Repo;
using Smerg.PrivateOffice.Secure;
using RF.Common.Logging;
using Smerg.PrivateOffice.BL.Logging;

namespace Smerg.PrivateOffice.Controllers
{
    public class LoginController : ApiController
    {
        private IUserRepo _userRepo;

        public LoginController(IUserRepo userRepo) : base()
        {
            _userRepo = userRepo;
        }
        public HttpResponseMessage Post([FromBody]Login value)
        {
            if (!ModelState.IsValid)
                return this.ResponseOnInvalidate();

            try
            {
                var user = _userRepo.GetUserByName(value.login);
                if (user != null)
                {
                    var pswHash = _userRepo.ComputePswHash(user, value.psw);
                    if (_userRepo.CheckUser(user, value.psw))
                    {
                        var token = user.IssueBearerToken();
                        Logs.LogUser.Log(GetLogObject(user.Client.ClientId, value.login, pswHash, token), "Login", "Login");
                        return Request.CreateResponse<object>(HttpStatusCode.OK, new { token = token });
                    }
                    else
                    {
                        Logs.LogUser.Log(GetLogObject(user.Client.ClientId, value.login, pswHash, null), "Login", "Login");
                        return this.ResponseOnInvalidate("error", "Неверный пароль");
                    }
                }

                Logs.LogUser.Log(GetLogObject(null, value.login, null, null), "Login", "Login");
                return this.ResponseOnInvalidate("error", "Неверный логин ");
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        [Authorize]
        public HttpResponseMessage Delete()
        {
            try
            {
                IClaimsPrincipal icp = HttpContext.Current.User as IClaimsPrincipal;
                if (icp != null)
                {
                    IClaimsIdentity claimsIdentity = (IClaimsIdentity)icp.Identity;
                    int clientId = 0;
                    int.TryParse(claimsIdentity.Claims.FirstOrDefault(cl => cl.ClaimType == ClaimTypes.PrimarySid).Value, out clientId);
                        Logs.LogUser.Log(
                            GetLogObject(clientId == 0 ? null : (int?)clientId
                            , null, null
                            , RF.Sts.Auth.OAuthProtectionModule.GetTokenFromAuthorizationHeader(HttpContext.Current.Request))
                        , "Logout", "Logout");
                }
                return Request.CreateResponse<object>(HttpStatusCode.OK, null);
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        private UserActivity GetLogObject(int? clientId, string login, string psw, string token)
        {
            var ret = new UserActivity();
            ret.Ip = GetIPAddress();
            ret.UserAgent = HttpContext.Current.Request.UserAgent;
            ret.UserName = login;
            ret.UserPsw = psw;
            ret.TokenHash = string.IsNullOrWhiteSpace(token) ? (int?)null : token.GetHashCode();
            ret.ClientId = clientId;
            return ret;
        }

        private static String GetIPAddress()
        {
            var ip = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(ip))
                ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            else
                ip = ip.Split(',')[0];
            return ip;
        }
    }
}
