﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Caching;
using System.Xml;
using Microsoft.IdentityModel.Claims;
using Smerg.PrivateOffice.Secure;
using Smerg.PrivateOffice.BL.Repo;
using Smerg.PrivateOffice.Models;
using Smerg.PrivateOffice.BL.Models;
using Smerg.PrivateOffice.BL.Models.Mib;


namespace Smerg.PrivateOffice.Controllers
{
    public class AccountsController : ApiController
    {
        private IClientRepo _accRepo;
        private IMibService _mibRepo;

        public AccountsController(IClientRepo accRepo, IMibService mibRepo) : base()
        {
            _accRepo = accRepo;
            _mibRepo = mibRepo;
        }

        [Authorize]
        public HttpResponseMessage Get()
        {
            try
            {
                var login = Login.GetFromClaimsPrincipal();
                var cl = login.Claims.FirstOrDefault(c => c.ClaimType == ClaimTypes.PrimarySid);
                int clientId = 0;
                if (cl != null)
                {
                    int.TryParse(cl.Value, out clientId);
                }

                int i = 1;
                var ret = _accRepo.GetAccountRoles(clientId).Select(r => new
                {
                    id = r.Account.AccountId,
                    num = i++,
                    role = r.Name,
                    type = r.Account.AccountType.Name,
                    db = r.Account.OpenDate,
                    acc = r.Account.Number,
                    de = r.Account.CloseDate,
                    saldo = r.Account.Operations.Sum(o => o.Income - o.Payment),
                    isOps = r.Type == RoleType.Insured,
                    isAdm = r.Type == RoleType.Investor,
                    ivestInfo = r.Type == RoleType.Insured ? _accRepo.GetInvestInfo(clientId) : null
                });

                return Request.CreateResponse(HttpStatusCode.OK, ret);
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        [Authorize]
        public HttpResponseMessage Get(string id)
        {
            try
            {
                var login = Login.GetFromClaimsPrincipal();
                var cl = login.Claims.FirstOrDefault(c => c.ClaimType == ClaimTypes.PrimarySid);
                int clientId = 0;
                if (cl != null)
                {
                    int.TryParse(cl.Value, out clientId);
                }

                int i = 1;

                object commonPart = new object();
                object specialPart = null;
                var role = _accRepo.GetAccountRoles(clientId).FirstOrDefault(r => r.AccountId == id);
                if (role != null)
                {
                    commonPart = new
                    {
                        id = role.AccountId,
                        acc = role.Account.Number,
                        agree = role.AgreementId,
                        saldo = role.Account.Operations.Sum(o => o.Income - o.Payment),
                        type = role.Account.AccountType.Name,
                        db = role.Account.OpenDate,
                        de = role.Account.CloseDate,
                        data = role.Account.Operations
                        .OrderByDescending(o => o.Date)
                        .Select(o => new
                        {
                            num = i++,
                            operation = o.Description,
                            date = o.Date,
                            saldo = o.Income - o.Payment
                        })
                    };


                    if (role.Type == RoleType.Investor)
                    {
                        var list = new List<object>();
                        foreach (var e in Enum.GetValues(typeof(AutoPaymentPeriodicity)).Cast<AutoPaymentPeriodicity>())
                        {
                            if (e != AutoPaymentPeriodicity.Ones)
                                list.Add(new
                                {
                                    value = (int)e,
                                    desc = RF.Common.Utils.GetEnumDescription(e)
                                });
                        }

                        specialPart = new
                        {
                            wholeInvest = role.Account.Operations.Where(o => o.Type == "НЧ").Sum(o => o.Income - o.Payment),
                            yearInvest = role.Account.Operations.Where(o => o.Type == "НЧ" && o.Date.Year == DateTime.Now.Year - 1).Sum(o => o.Income - o.Payment),
                            lastPaymentDate = role.Account.Operations.Where(o => o.Type == "ВН").OrderByDescending(o => o.Date).FirstOrDefault()?.Date,
                            email = Obfuscator.ObfuscateEmail(role.Client.Email),
                            autopmnt = _mibRepo.GetAutoPayment(new AutoPaymentRequest() { AgreementNumber = role.AgreementId }),
                            periodicityEnum = list.ToArray()
                        };
                    }
                }

                return Request.CreateResponse(HttpStatusCode.OK, new { common = commonPart, spec = specialPart });
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        [Authorize]
        [AcceptVerbs("POST")]
        [Route("api/auth/pmnt")]
        public HttpResponseMessage CreatePayment([FromBody]PaymentInfo value)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.ResponseOnInvalidate();

                var orderUID = Guid.NewGuid().ToString().Replace("-",""); 
                var redirect = string.Format("{0}://{1}{3}/api/log/mibConfirm/{2}"
                    , HttpContext.Current.Request.Url.Scheme
                    , HttpContext.Current.Request.Url.Authority
                    , orderUID
                    , HttpContext.Current.Request.ApplicationPath == "/" ? "" : HttpContext.Current.Request.ApplicationPath);

                var req = new OrderRequest();
                req.Request = new OperationRequest();
                req.Request.Order = new OperationRequestOrder();
                req.Request.Order.Amount = value.amount ?? 0;
                req.Request.Order.Description = "no descript";
                req.Request.Order.ApproveURL = redirect;
                req.Request.Order.CancelURL = redirect;
                req.Request.Order.DeclineURL = redirect;

                var res = _mibRepo.CreateOrder(req);

                if (res != null)
                {
                    var ret = new PaymentDetails()
                    {
                        AgreementId = value.agree,
                        SessionId = res.Response.Order.SessionID,
                        OrderId = res.Response.Order.OrderID,
                        Amount = value.amount ?? 0,
                        Periodicity = value.periodicity,
                        PurchaseUrl = res.PurchaseUrl.ToString(),
                        ReturnUrl = value.returnUrl,
                    };
                    HttpRuntime.Cache.Remove(orderUID);
                    HttpRuntime.Cache.Add(orderUID, ret, null, DateTime.Now.AddSeconds(600), Cache.NoSlidingExpiration, CacheItemPriority.NotRemovable, null);
                    return Request.CreateResponse(HttpStatusCode.OK, ret);
                }

                return this.ResponseOnInvalidate("error", "Сервис платежей не доступен.");
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        [Authorize]
        [AcceptVerbs("PUT")]
        [Route("api/auth/pmnt")]
        public HttpResponseMessage UpdatePayment([FromBody]PaymentInfo value)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.ResponseOnInvalidate();

                var pmntReq = new AutoPaymentRequest() { AgreementNumber = value.agree };
                var autopmnt = _mibRepo.GetAutoPayment(pmntReq);

                if (autopmnt != null && string.IsNullOrEmpty(autopmnt.PaymentOrderId) == false)
                {
                    int orderId = 0;
                    int.TryParse(autopmnt.PaymentOrderId, out orderId);
                    var det = new PaymentDetails()
                    {
                        AgreementId = value.agree,
                        SessionId = autopmnt.PaymentSessionId,
                        OrderId = orderId,
                        Amount = value.amount ?? 0,
                        Periodicity = value.periodicity
                    };
                    var op = _mibRepo.ConfirmPurchase(det);
                    var res = new PurchaseResult();
                    res.Status = Convert.ToInt32(op) == 1 ? PurchaseStatus.APPROVED : PurchaseStatus.ERROR;
                    return Request.CreateResponse(HttpStatusCode.OK, SavePaymentOperationResult(res));
                }

                return this.ResponseOnInvalidate("error", "Автоплатеж не найден.");
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        [Authorize]
        [AcceptVerbs("DELETE")]
        [Route("api/auth/pmnt/{agree}")]
        public HttpResponseMessage DeletePayment(string agree)
        {
            try
            {
                var pmntReq = new AutoPaymentRequest() { AgreementNumber = agree };
                var autopmnt = _mibRepo.GetAutoPayment(pmntReq);

                if (autopmnt != null && string.IsNullOrEmpty(autopmnt.PaymentOrderId) == false)
                {
                    var op = _mibRepo.AutoPaymentCancel(autopmnt.AgreementId);
                    var res = new PurchaseResult();
                    res.Status = Convert.ToInt32(op) == 1 ? PurchaseStatus.APPROVED : PurchaseStatus.ERROR;
                    return Request.CreateResponse(HttpStatusCode.OK, SavePaymentOperationResult(res));
                }

                return this.ResponseOnInvalidate("error", "Автоплатеж не найден.");
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        /// <summary>
        /// Возврат из МИБа (междоменный пост). Редирект по ранее указанному урлу <>order.ReturnUrl</>
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        [AcceptVerbs("POST")]
        [Route("api/log/mibConfirm/{uid}")]
        public HttpResponseMessage CreatePaymentReturn(string uid, [FromBody]MibPaymentConfirm value)
        {
            var ret = Request.CreateResponse(HttpStatusCode.Redirect);
            string redirect = string.Format("{0}://{1}", HttpContext.Current.Request.Url.Scheme, HttpContext.Current.Request.Url.Authority);
            PaymentDetails order = null;
            PurchaseResult res = null;
            try
            {
                order = HttpRuntime.Cache.Get(uid) as PaymentDetails;
                if (order != null && value != null)
                {
                    res = _mibRepo.CheckPurchaseResult(value.xmlmsg);
                    if (res.OrderId == order.OrderId)
                    {
                        if (res.Status == PurchaseStatus.APPROVED)
                        {
                            //call api for save payment
                            _mibRepo.ConfirmPurchase(order);
                        };
                    }
                }
            }
            catch (Exception e)
            {
                if (order != null)
                {
                    if (res == null)
                        res = new PurchaseResult();

                    res.Exception = e;
                    res.Status = PurchaseStatus.ERROR;
                }
            }

            if (res != null)
            {
                redirect = order.ReturnUrl + "/" + SavePaymentOperationResult(res);
            }

            ret.Headers.Add("Location", redirect);
            return ret;
        }

        /// <summary>
        /// Узнать результат платежной операции
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        [Authorize]
        [AcceptVerbs("GET")]
        [Route("api/auth/pmntRes/{uid}")]
        public HttpResponseMessage CreatePaymentResult(string uid)
        {
            PurchaseResult res = null;
            try
            {
                res = HttpRuntime.Cache.Get(uid) as PurchaseResult;
                if (res != null)
                {
                    string message = "";
                    switch (res.Status)
                    {
                        case PurchaseStatus.APPROVED: message = "Операция прошла успешно!"; break;
                        case PurchaseStatus.ERROR:
                        case PurchaseStatus.CANCELED:
                        case PurchaseStatus.DECLINED: message = "Не удалось произвести операцию!"; break;
                    }

                    return Request.CreateResponse(HttpStatusCode.OK, new { message = message, status = res.Status.ToString() });
                }

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        private string SavePaymentOperationResult(PurchaseResult res)
        {
            var uid = Guid.NewGuid().ToString().Replace("-", "");
            HttpRuntime.Cache.Remove(uid);
            HttpRuntime.Cache.Add(uid, res, null, DateTime.Now.AddSeconds(60), Cache.NoSlidingExpiration, CacheItemPriority.NotRemovable, null);
            return uid;
        }
    }
}
