﻿using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Smerg.PrivateOffice.Models;
using Smerg.PrivateOffice.Secure;
using Smerg.PrivateOffice.BL.Repo;
using Smerg.PrivateOffice.BL.Logging;
using RF.Common;
using RF.Common.Logging;

namespace Smerg.PrivateOffice.Controllers
{
    public class RestoreController : ApiController
    {
        private IClientRepo _clRepo;
        private IUserRepo _userRepo;
        private IRestoreRepo _resRepo;

        public RestoreController(IClientRepo clRepo, IUserRepo userRepo, IRestoreRepo resRepo) : base()
        {
            _clRepo = clRepo;
            _userRepo = userRepo;
            _resRepo = resRepo;
        }
        public HttpResponseMessage Post([FromBody]RestoreRequest value)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.ResponseOnInvalidate();

                var client = _clRepo.GetByEmail(value.email);
                if(client == null)
                    return this.ResponseOnInvalidate("", "Проверьте, пожалуйста, адрес электронной почты и повторите ввод.");

                var r = _resRepo.BeginRestore(client.ClientId);

                if (r.OrderUsed == false)
                {
                    var emailSender = new EMailSender(ConfigurationManager.GetSupportEmail(), client.Email, "Восстановление пароля", r.EmailMessage);
                    emailSender.SendEmail();
                    Logs.LogApp.Log(new SentEmail()
                    {
                        MailFrom = emailSender.MailFrom,
                        MailSubject = emailSender.MailSubject,
                        MailTo = emailSender.MailTo,
                        MailTextBody = emailSender.MailBody,
                        MailReplyTo = emailSender.MailReplyTo
                    }
                        , "Smpt", "Smpt");
                    r.OrderUsed = true;
                    _resRepo.Update();
                    return Request.CreateResponse<object>(HttpStatusCode.OK, new { emailSend = true });
                }

                return Request.CreateResponse<object>(HttpStatusCode.OK, new { emailSend = false });

            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        public HttpResponseMessage Get(string id)
        {
            try
            {
                var res = _resRepo.GetRestore(id);
                if (null != res)
                {
                    return Request.CreateResponse<object>(HttpStatusCode.OK, new { smsSend = true });
                }

                return Request.CreateResponse<object>(HttpStatusCode.OK, new { smsSend = false });

            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        public HttpResponseMessage Put([FromBody]ConfirmRestoreRequest value)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.ResponseOnInvalidate();

                var res = _resRepo.GetRestore(value.id);
                if (null != res)
                {
                    var user = _userRepo.GetUserById(res.ClientId);
                    if (user != null)
                    {
                        string defPsw =_userRepo.ResetPassword(user);
                        return Request.CreateResponse<object>(HttpStatusCode.OK, new { confirmed = true, newPsw = defPsw, token = user.IssueBearerToken() });
                    }
                }

                return Request.CreateResponse<object>(HttpStatusCode.OK, new { confirmed = false });

            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }
    }
}
