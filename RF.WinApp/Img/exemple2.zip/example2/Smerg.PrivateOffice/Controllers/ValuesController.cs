﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using Microsoft.IdentityModel.Claims;
using System.Web;
using System.Web.Http;

namespace Smerg.PrivateOffice.Controllers
{
    [Authorize]
    public class ValuesController : ApiController
    {
        // GET api/values
        public object Get()
        {
            string surname = "пользователь";
            IClaimsPrincipal icp = HttpContext.Current.User as IClaimsPrincipal;
            if (icp != null)
            {
                IClaimsIdentity claimsIdentity = (IClaimsIdentity)icp.Identity;
                surname = claimsIdentity.Claims.FirstOrDefault(cl => cl.ClaimType == ClaimTypes.Surname).Value;
            }

            return new { FIO = surname };
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
