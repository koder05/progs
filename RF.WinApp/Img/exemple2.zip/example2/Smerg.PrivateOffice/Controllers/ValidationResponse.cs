﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Net;
using System.Net.Http;

namespace Smerg.PrivateOffice.Controllers
{
    public static class ValidationResponse
    {
        public static HttpResponseMessage ResponseOnInvalidate(this ApiController c)
        {
            if (!c.ModelState.IsValid)
            {
                var errors = new List<object>();
                for (var i = 0; i < c.ModelState.Keys.Count; i++)
                {
                    var m = c.ModelState.Keys.ElementAt(i).Split('.');
                    errors.Add(new
                    {
                        fieldName = m[m.Length - 1],
                        errors = c.ModelState.Values.ElementAt(i).Errors.Select(e => string.IsNullOrEmpty(e.ErrorMessage) ? e.Exception?.Message : e.ErrorMessage)
                    });
                }

                return c.Request.CreateResponse(HttpStatusCode.InternalServerError,
                    new { ClassName = typeof(ValidationResponse).FullName, Errors = errors }
                    );
            }

            return c.Request.CreateResponse<object>(HttpStatusCode.OK);
        }

        public static HttpResponseMessage ResponseOnInvalidate(this ApiController c, string prop, string err)
        {
            return c.Request.CreateResponse(HttpStatusCode.InternalServerError,
                    new
                    {
                        ClassName = typeof(ValidationResponse).FullName,
                        Errors = new object[] {
                             new{ fieldName = prop, errors = new string[] { err }}
                        }
                    });
        }
    }
}