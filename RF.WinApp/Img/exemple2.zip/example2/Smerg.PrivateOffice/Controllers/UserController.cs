﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using Microsoft.IdentityModel.Claims;
using System.Web;
using System.Web.Http;

using Smerg.PrivateOffice.Models;
using Smerg.PrivateOffice.BL.Repo;
using Smerg.PrivateOffice.Secure;

namespace Smerg.PrivateOffice.Controllers
{
    [Authorize]
    public class UserController : ApiController
    {
        private IUserRepo _userRepo;

        public UserController(IUserRepo userRepo) : base()
        {
            _userRepo = userRepo;
        }

        public object Get()
        {
            var login = Login.GetFromClaimsPrincipal();
            if (login != null)
            {
                return new
                {
                    surname = login.Claims.FirstOrDefault(cl => cl.ClaimType == ClaimTypes.Surname).Value,
                    login = login.login,
                    mail = login.Claims.FirstOrDefault(cl => cl.ClaimType == ClaimTypes.Email).Value,
                    gender = login.Claims.FirstOrDefault(cl => cl.ClaimType == ClaimTypes.Gender).Value
                };
            }

            return null;
        }

        /// <summary>
        /// Правка пользователем дефолтной учетки сразу после регистрации
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public HttpResponseMessage Post([FromBody]UserInitSettings value)
        {
            if (!ModelState.IsValid)
                return this.ResponseOnInvalidate();

            try
            {
                return ChangeCredentials(value.psw, value.login, value.pswNew);
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        public HttpResponseMessage Put([FromBody]UserSettings value)
        {
            if (!ModelState.IsValid)
                return this.ResponseOnInvalidate();

            try
            {
                return ChangeCredentials(value.psw, value.login, value.pswNew);
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        [AcceptVerbs("PUT")]
        [Route("api/auth/userRestore")]
        public HttpResponseMessage RestorePwd([FromBody]UserRestoreSettings value)
        {
            if (!ModelState.IsValid)
                return this.ResponseOnInvalidate();

            try
            {
                return ChangeCredentials(value.psw, value.login, value.pswNew);
            }
            catch (Exception e)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        private HttpResponseMessage ChangeCredentials(string psw, string newLogin, string newPsw)
        {
            var oldLogin = Login.GetFromClaimsPrincipal();
            if (oldLogin != null)
            {
                var user = _userRepo.GetUserByName(oldLogin.login);
                if (user != null)
                {
                    try
                    {
                        if(_userRepo.ChangeCredentials(user, psw, newLogin, newPsw))
                        {
                            return Request.CreateResponse<object>(HttpStatusCode.OK, new { token = user.IssueBearerToken() });
                        }
                    }
                    catch (InvalidOperationException e)
                    {
                        return this.ResponseOnInvalidate("error", e.Message);
                    }
                }
            }

            return this.ResponseOnInvalidate("error", "Ошибка инициализации учетной записи. Пройдите процедуру регистрации.");
        }
    }
}
