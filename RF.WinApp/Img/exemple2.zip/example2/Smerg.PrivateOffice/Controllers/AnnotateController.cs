﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Web;
using System.Net.Http;
using System.Web.Http;
using System.Web.Routing;
using Smerg.PrivateOffice.Models;
using System.Web.Http.Dispatcher;
using System.Linq;
using System.Reflection;

namespace Smerg.PrivateOffice.Controllers
{
    [Authorize]
    public class AnnotateController : ApiController
    {
        public HttpResponseMessage Post([FromBody]AnnotationsRequest value)
        {
            Type annotatedModelType = null;


            string url = "~/" + value.path;
            var httpContext = new HttpContextWrapper(HttpContext.Current);
            string originalPath = httpContext.Request.Path;

            try
            {
                httpContext.RewritePath(url);
                RouteData urlRouteData = RouteTable.Routes.GetRouteData(httpContext);
                if (urlRouteData != null)
                {
                    string controllerName = urlRouteData.Values["controller"].ToString();
                    var controllerTypeName = string.Format("{0}Controller", controllerName);
                    MethodInfo methodInfo = null;
                    foreach (var controllerType in Assembly.GetExecutingAssembly().GetTypes().Where(t => t.BaseType == typeof(ApiController)))
                    {
                        if(controllerType.Name.Equals(controllerTypeName, StringComparison.InvariantCultureIgnoreCase))
                        {
                            methodInfo = controllerType.GetMethods(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault(m =>
                                    m.Name.Equals(value.method, StringComparison.InvariantCultureIgnoreCase) 
                                );
                        }
                        else
                        {
                            methodInfo = controllerType.GetMethods(BindingFlags.Instance | BindingFlags.Public).FirstOrDefault(m =>
                                    m.GetCustomAttributes<RouteAttribute>().Any(attr =>
                                        attr.Template.StartsWith(value.path)
                                    ) 
                                    &&
                                    m.GetCustomAttributes<AcceptVerbsAttribute>().Any(attr =>
                                        attr.HttpMethods.Any(hm => hm.Method.Equals(value.method, StringComparison.InvariantCultureIgnoreCase))
                                    )
                                );
                        }

                        if (methodInfo != null)
                            break;
                    }

                    if (methodInfo != null)
                    {
                        var parInfo = methodInfo.GetParameters().FirstOrDefault(p => p.GetCustomAttribute<FromBodyAttribute>() != null);

                        if (parInfo != null)
                        {
                            annotatedModelType = parInfo.ParameterType;
                        }
                    }
                }
            }
            finally
            {
                httpContext.RewritePath(originalPath);
            }

            //switch (value.path)
            //{
            //    case "api/auth/pmntAdd":
            //        annotatedModelType = typeof(PaymentInfo);
            //        break;
            //}

            if (annotatedModelType != null)
                return Request.CreateResponse(HttpStatusCode.OK, Validation.GetAnnotations(annotatedModelType));

            return Request.CreateResponse<object>(HttpStatusCode.OK, null);
        }
    }
}