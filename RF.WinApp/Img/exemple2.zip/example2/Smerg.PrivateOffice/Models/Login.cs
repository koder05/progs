﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Web;
using Microsoft.IdentityModel.Claims;
using System.ComponentModel.DataAnnotations;
using Smerg.PrivateOffice.Captcha;

namespace Smerg.PrivateOffice.Models
{
    public class Login
    {  
        [Required(ErrorMessage = "Требуется логин")]
        public string login { get; set; }

        [Required(ErrorMessage = "Требуется пароль")]
        public string psw { get; set; }

        [CaptchaValidate]
        public Captcha captcha { get; set; }

        public ClaimCollection Claims { get;  set; }

        internal static Login GetFromClaimsPrincipal()
        {
            IClaimsPrincipal icp = HttpContext.Current.User as IClaimsPrincipal;
            if (icp != null)
            {
                IClaimsIdentity claimsIdentity = (IClaimsIdentity)icp.Identity;
                return new Login
                {
                    login = claimsIdentity.Claims.FirstOrDefault(cl => cl.ClaimType == ClaimTypes.Name).Value,
                    Claims = claimsIdentity.Claims
                };
            }

            return null;
        }
    }
}