﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;

using System.Net.Http;


namespace Smerg.PrivateOffice.Models
{
    public class ValidatedModelAnnotation
    {
        public string foo { get; set; }
        public string message { get; set; }
        public object[] args { get; set; }
    }

    public class ValidatedModel
    {
        //{ name : "num", annotations : [{foo : "required",  message : "message", args : []}, ... ]}
        public string name { get; set; }
        public List<ValidatedModelAnnotation> annotations { get; set; }

        public ValidatedModel()
        {
            annotations = new List<ValidatedModelAnnotation>();
        }
    }


    public static class Validation
    {
        public static void Validate(object model)
        {
            var results = new List<ValidationResult>(1);
            foreach (var prop in model.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
            {
                var value = prop.GetValue(model, null);
                //if (value != null && value.GetType().IsAssignableFrom(typeof(ValidatedModel)))
                //{
                //    ((ValidatedModel)value).Validate();
                //    return;
                //}

                var validCtx = new ValidationContext(model, null, null) { MemberName = prop.Name };
                results.Clear();
                bool result = Validator.TryValidateProperty(value, validCtx, results);
                if (!result)
                {
                    ValidationResult validationResult = results.First();
                    throw new ValidationException(validationResult.ErrorMessage);
                }
            }
        }

        public static List<ValidatedModel> GetAnnotations(Type type)
        {
            var ret = new List<ValidatedModel>();
            foreach (var prop in type.GetProperties(BindingFlags.Instance | BindingFlags.Public))
            {
                var m = new ValidatedModel();
                m.name = prop.Name;
                foreach (var attr in prop.CustomAttributes.Where(a => a.AttributeType.BaseType == typeof(ValidationAttribute) || a.AttributeType == typeof(EnumDataTypeAttribute)))
                {
                    var ann = new ValidatedModelAnnotation(); 
                    ann.foo = attr.AttributeType.Name.Replace("Attribute", "");
                    var msgParam = attr.NamedArguments.FirstOrDefault(a => a.MemberName == "ErrorMessage");
                    if (msgParam != null && msgParam.TypedValue != null && msgParam.TypedValue.Value != null)
                        ann.message = msgParam.TypedValue.Value.ToString();

                    if (attr.AttributeType == typeof(EnumDataTypeAttribute))
                    {
                        ann.args =  Enum.GetValues((Type)attr.ConstructorArguments.First().Value).Cast<int>().ToArray().Cast<object>().ToArray();
                    }
                    else
                    {
                        ann.args = attr.ConstructorArguments.Select(a => Convert.ChangeType(a.Value, a.ArgumentType)).ToArray();
                    }
                    m.annotations.Add(ann);
                }

                if (m.annotations.Count > 0)
                    ret.Add(m);
            };
            return ret;
        }
    }

    public class AnnotationsRequest
    {
        public string path { get; set; }
        public string method { get; set; }
    }

    public class ValidationActionFilter : System.Web.Http.Filters.ActionFilterAttribute
    {
        public override void OnActionExecuting(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            var modelState = actionContext.ModelState;

            var errors = new List<object>();
            for (var i = 0; i < modelState.Keys.Count; i++)
            {
                var m = modelState.Keys.ElementAt(i).Split('.');
                errors.Add(new
                {
                    fieldName = m[m.Length - 1],
                    errors = modelState.Values.ElementAt(i).Errors.Select(e => string.IsNullOrEmpty(e.ErrorMessage) ? e.Exception?.Message : e.ErrorMessage)
                });
            }

            if (!modelState.IsValid)
                actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.InternalServerError,
                    new { ClassName = typeof(Smerg.PrivateOffice.Controllers.ValidationResponse).FullName, Errors = errors }
                    );
        }
    }

}