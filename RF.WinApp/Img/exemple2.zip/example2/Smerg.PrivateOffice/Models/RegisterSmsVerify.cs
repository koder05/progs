﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Smerg.PrivateOffice.Models
{
    public class RegisterSmsVerify
    {
        [Required(ErrorMessage = "Требуется код СМС")]
        public string code { get; set; }

        [IsTrue(ErrorMessage = "Требуется подтверждение правил")]
        public bool rulesAgree { get; set; }

        public string requestId { get; set; }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class IsTrueAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            bool? val = value as bool?;
            if ((val ?? false) == false)
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            return ValidationResult.Success;
        }
    }
}