﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;

namespace Smerg.PrivateOffice.Models
{
    public class PaymentInfo
    {
        [Required]
        public string acc { get; set; }

        [Required]
        public string agree { get; set; }

        [Required(ErrorMessage = "Требуется указать сумму")]
        [Range(0.01, 100000000.00, ErrorMessage = "Неверный размер платежа")]
        public decimal? amount { get; set; }

        public string returnUrl { get; set; }

        [EnumDataType(typeof(Smerg.PrivateOffice.BL.Models.Mib.AutoPaymentPeriodicity), ErrorMessage = "Неверное значение периодичности")]
        public int periodicity { get; set; }
    }

    public class MibPaymentConfirm
    {
        public string xmlmsg { get; set; }
    }
}