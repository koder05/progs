﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using Smerg.PrivateOffice.Secure;

namespace Smerg.PrivateOffice.Models
{
    public class UserSettings
    {
        public string login { get; set; }

        [Required(ErrorMessage = "Требуется текущий пароль")]
        public string psw { get; set; }

        [Required(ErrorMessage = "Требуется новый пароль")]
        [PasswordComplexity(ErrorMessage = "Пароль не соответствует критериям")]
        [PswCond(ErrorMessage = "Новый пароль совпадает со старым паролем, необходимо его изменить")]
        public string pswNew { get; set; }

        [Required(ErrorMessage = "Повторите новый пароль")]
        [PswConfirm(ErrorMessage = "Введенные новые пароли не совпадают")]
        public string pswNewRep { get; set; }
    }

    public class UserInitSettings
    {
        [Required(ErrorMessage = "Требуется задать имя входа")]
        public string login { get; set; }

        [Required(ErrorMessage = "Требуется пароль")]
        [PasswordComplexity(ErrorMessage = "Пароль не соответствует критериям")]
        public string pswNew { get; set; }

        [Required(ErrorMessage = "Повторите пароль")]
        [PswConfirm(ErrorMessage = "Введенные пароли не совпадают")]
        public string pswNewRep { get; set; }

        public string psw { get; set; }

    }

    public class UserRestoreSettings
    {
        public string login { get; set; }

        public string psw { get; set; }

        [Required(ErrorMessage = "Требуется новый пароль")]
        [PasswordComplexity(ErrorMessage = "Пароль не соответствует критериям")]
        public string pswNew { get; set; }

        [Required(ErrorMessage = "Повторите новый пароль")]
        [PswConfirm(ErrorMessage = "Введенные новые пароли не совпадают")]
        public string pswNewRep { get; set; }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class PswConfirmAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var m = validationContext.ObjectInstance as UserSettings;
            if (m != null && m.pswNew != m.pswNewRep)
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            return ValidationResult.Success;
        }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class PswCondAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var m = validationContext.ObjectInstance as UserSettings;
            if (m != null && m.pswNew == m.psw)
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            return ValidationResult.Success;
        }
    }
}