﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Smerg.PrivateOffice.Captcha;

namespace Smerg.PrivateOffice.Models
{
    public class RestoreRequest
    {
        [Required(ErrorMessage = "Требуется адрес электропочты")]
        [EmailAddress(ErrorMessage = "Неверный формат адреса электропочты")]
        public string email { get; set; }

        [CaptchaValidate]
        public Captcha captcha { get; set; }
    }

    public class ConfirmRestoreRequest
    {
        [CaptchaValidate]
        public Captcha captcha { get; set; }

        public string id { get; set; }
    }
}