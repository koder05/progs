﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Smerg.PrivateOffice.Secure;

namespace Smerg.PrivateOffice.Models
{
    public class RegisterRequest 
    {
        [Required(ErrorMessage = "Требуется СНИЛС")]
        [IpaComplexity(ErrorMessage = "Неверный формат СНИЛС")]
        public string ipa { get; set; }

        [Required(ErrorMessage = "Требуется номер мобильного телефона")]
        [RegularExpression(@"^((\+7)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}$", ErrorMessage = "Неверный формат номера мобильного телефона")]
        public string phone { get; set; }

        [Required(ErrorMessage = "Требуется адрес электропочты")]
        [EmailAddress(ErrorMessage = "Неверный формат адреса электропочты")]
        public string email { get; set; }
    }
}