﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

using RF.Common;

namespace Smerg.PrivateOffice.Secure
{
	public class PasswordManagement
	{
		public const string PasswordComplexityIsLow = "Критерии пароля: длина от 6 до 20 символов, только латинские буквы, обязательное наличие цифр, не должен содержать имя пользователя.";

		public bool PasswordMeetsComplexityRequirements(string userName, string password)
		{
			Args.IsNotNull(userName, "userName");

			return 
				!string.IsNullOrEmpty(password) 
				&& 
				ComplexityRegexps.All(re => re.IsMatch(password)) 
				&& 
				password.IndexOf(userName, StringComparison.CurrentCultureIgnoreCase) < 0;
		}

		public void EnsurePasswordComplexity(string userName, string password)
		{
			if (!PasswordMeetsComplexityRequirements(userName, password))
			{
				throw new ApplicationException(PasswordComplexityIsLow);
			}
		}

		public static readonly Regex[] ComplexityRegexps = new[]
			{ 
				new Regex(@".{8,}", RegexOptions.Compiled),
				new Regex(@"^[a-zA-Z].*", RegexOptions.Compiled),
				new Regex(@".*[A-Z].*", RegexOptions.Compiled),
				new Regex(@".*\d.*", RegexOptions.Compiled)
            };
	}
}
