﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Smerg.PrivateOffice.Secure
{
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
	public class PasswordComplexityAttribute : ValidationAttribute
	{
		public PasswordComplexityAttribute()
			: base(PasswordManagement.PasswordComplexityIsLow)
		{
		}
		
		protected override ValidationResult IsValid(object value, ValidationContext validationContext)
		{
			string psw = value != null ? Convert.ToString(value) : string.Empty;

			PasswordManagement pm = new PasswordManagement();
			if (pm.PasswordMeetsComplexityRequirements(HttpContext.Current.User.Identity.Name, psw) == false)
				return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));

			return ValidationResult.Success;
		}
	}
}