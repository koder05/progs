﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using RF.Common;
using RF.Common.Security;

namespace Smerg.PrivateOffice.Security
{
    public static class Utils
    {
        public static byte[] ConvertHexStringToByteArray(string hexString)
        {
            if (hexString.Length % 2 != 0)
            {
                throw new ArgumentException(String.Format("The binary key cannot have an odd number of digits: {0}", hexString));
            }

            byte[] HexAsBytes = new byte[hexString.Length / 2];
            for (int index = 0; index < HexAsBytes.Length; index++)
            {
                string byteValue = hexString.Substring(index * 2, 2);
                HexAsBytes[index] = Convert.ToByte(byteValue, 16);
            }

            return HexAsBytes;
        }

        public static string ConvertByteArrayToHexString(byte[] arr)
        {
            string hex = BitConverter.ToString(arr);
            return hex.Replace("-", "");
        }

        public static byte[] GetHashSha256(string text)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(text);
            SHA256Managed hashstring = new SHA256Managed();
            return hashstring.ComputeHash(bytes);
        }

        public static string GetRFLikeHash(string text, string salt)
        {
            return ConvertByteArrayToHexString(Hash.GenerateHash(text, ConvertHexStringToByteArray(salt)));
        }

        public static string GetRaiffeisenLikeHash(string text)
        {
            return ConvertByteArrayToHexString(GetHashSha256(string.Format("bQg?CYDx88tb{0}&5LUtFNmjYn7GdzRL3u=UEYz", text)));
        }
    }
}
