﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Entity.Core;
using System.Data.Entity.Core.Objects;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using Smerg.PrivateOffice.BL.Models;

namespace Smerg.PrivateOffice.BL.EF
{
    public class EFCtx : DbContext
    {
        public DbSet<Client> Clients { get; set; }
        public DbSet<Registration> Registrations { get; set; }
        public DbSet<Restore> RestoreRequests { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Operation> Operations { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Invest> InvestInfo { get; set; }

        internal int MigrationVer = -1;

        public EFCtx()
			: base(DbVersion.DbKey, DbVersion.GetModel())
		{
            this.Configuration.LazyLoadingEnabled = true;
            this.Configuration.AutoDetectChangesEnabled = true;
            this.MigrationVer = DbVersion.GetVersion();
        }

        public ObjectStateEntry FindEntityById<TPoco>(int id) where TPoco : class, new()
        {
            ObjectStateEntry entry;
            ObjectContext context = ((IObjectContextAdapter)this).ObjectContext;
            context.ObjectStateManager.TryGetObjectStateEntry(GetEntityKey(typeof(TPoco), context, id), out entry);
            return entry;
        }

        public EntityKey GetEntityKey(Type type, ObjectContext context, int id)
        {
            // Thanks to Kevin McNeish for this little gem
            string entityTypeName = type.Name;
            var container = context.MetadataWorkspace.GetEntityContainer(
                context.DefaultContainerName, System.Data.Entity.Core.Metadata.Edm.DataSpace.CSpace);
            string entitySetName = (from meta in container.BaseEntitySets
                                    where meta.ElementType.Name == entityTypeName
                                    select meta.Name).First();
            return new EntityKey(string.Format("{0}.{1}", this.GetType().Name, entitySetName), "Id", id);
        }
    }
}
