﻿using System;
using System.Data.SqlClient;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.ComponentModel.DataAnnotations.Schema;
using Smerg.PrivateOffice.BL.Models;

namespace Smerg.PrivateOffice.BL.EF
{
    internal static class DbVersion
    {
        private static object sync = new object();
        private static int version = -1;
        private static DbCompiledModel model = null;
        private static DateTime expireTime = DateTime.MinValue;

        internal const string DbKey = "MainDb";

        internal static int GetVersion()
        {
            return version;
        }

        internal static DbCompiledModel GetModel()
        {
            lock (sync)
            {
                if (DateTime.Now > expireTime)
                {
                    RebuildModel();
                }

                return model;
            }
        }

        private static void RebuildModel()
        {
            var settings = System.Configuration.ConfigurationManager.ConnectionStrings[DbKey];
            if (settings != null)
            {
                using (var conn = new SqlConnection(settings.ConnectionString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("select [dbo].[privateGetCurrentGroup]()", conn))
                    {
                        version = (int)cmd.ExecuteScalar();
                        var builder = new DbModelBuilder(DbModelBuilderVersion.Latest);
                        ModelCreate(builder);
                        DbModel m = builder.Build(conn);
                        model = m.Compile();
                        expireTime = DateTime.Now.AddMinutes(15);
                    }
                }
            }
        }

        private static void ModelCreate(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Client>().ToTable("Client_Details_" + version);
            modelBuilder.Entity<Client>().HasKey(m => m.ClientId).Property(m => m.ClientId).HasColumnName("CLIENT_ID");
            modelBuilder.Entity<Client>().Property(m => m.FullName).HasColumnName("CLIENT_FULLNAME");
            modelBuilder.Entity<Client>().Property(m => m.Email).HasColumnName("CLIENT_EMAIL");
            modelBuilder.Entity<Client>().Property(m => m.Phone).HasColumnName("CLIENT_PHONE");
            modelBuilder.Entity<Client>().Property(m => m.Ipa).HasColumnName("CLIENT_SPID");
            modelBuilder.Entity<Client>().Property(m => m.GenderRaw).HasColumnName("CLIENT_GENDER");
            modelBuilder.Entity<Client>().Property(m => m.FirstName).HasColumnName("CLIENT_FIRSTNAME");
            modelBuilder.Entity<Client>().Property(m => m.LastName).HasColumnName("CLIENT_LASTNAME");
            modelBuilder.Entity<Client>().Property(m => m.MiddleName).HasColumnName("CLIENT_PATRONYMIC");
            modelBuilder.Entity<Client>().HasOptional(m => m.User).WithRequired(m => m.Client);

            modelBuilder.Entity<Registration>().ToTable("GrantAccessClientData");
            modelBuilder.Entity<Registration>().HasKey(m => m.RegistrationId).Property(m => m.RegistrationId).HasColumnName("ID");
            modelBuilder.Entity<Registration>().Property(m => m.StartTime).HasColumnName("UPDATE_DATE_TIME");
            modelBuilder.Entity<Registration>().Property(m => m.Email).HasColumnName("CLIENT_EMAIL");
            modelBuilder.Entity<Registration>().Property(m => m.Phone).HasColumnName("CLIENT_PHONE");
            modelBuilder.Entity<Registration>().Property(m => m.ClientId).HasColumnName("CLIENT_ID");
            modelBuilder.Entity<Registration>().Property(m => m.RequestId).HasColumnName("RequestPasswordResetID");
            modelBuilder.Entity<Registration>().Property(m => m.SmsCode).HasColumnName("SMSCode");
            modelBuilder.Entity<Registration>().Property(m => m.SmsStatus).HasColumnName("SMSStatus");

            modelBuilder.Entity<Restore>().ToTable("RequestPasswordReset");
            modelBuilder.Entity<Restore>().HasKey(m => m.RestoreId).Property(m => m.RestoreId).HasColumnName("ID");
            modelBuilder.Entity<Restore>().Property(m => m.StartTime).HasColumnName("OrderDateTime");
            modelBuilder.Entity<Restore>().Property(m => m.ClientId).HasColumnName("CLIENT_ID");
            modelBuilder.Entity<Restore>().Property(m => m.RequestId).HasColumnName("ClientLogIdRequest");
            modelBuilder.Entity<Restore>().Property(m => m.OrderUsed).HasColumnName("OrderUsed");

            modelBuilder.Entity<User>().ToTable("Client_Credentials_" + version);
            modelBuilder.Entity<User>().HasKey(m => m.UserId).Property(m => m.UserId).HasColumnName("CLIENT_ID").HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            modelBuilder.Entity<User>().Property(m => m.Name).HasColumnName("USER_LOGINNAME");
            modelBuilder.Entity<User>().Property(m => m.PasswordHash).HasColumnName("USER_PASSWORD");
            modelBuilder.Entity<User>().Property(m => m.PasswordHashMethodSql).HasColumnName("HashMethod");
            modelBuilder.Entity<User>().Ignore(m => m.PasswordHashMethod);
            modelBuilder.Entity<User>().Property(m => m.PasswordHashSalt).HasColumnName("USER_SALT");

            modelBuilder.Entity<AccountType>().ToTable("Client_Account_Types");
            modelBuilder.Entity<AccountType>().HasKey(m => m.AccountTypeId).Property(m => m.AccountTypeId).HasColumnName("ACCOUNT_TYPE_IDX");
            modelBuilder.Entity<AccountType>().Property(m => m.Name).HasColumnName("ACCOUNT_TYPE_DESC");

            modelBuilder.Entity<Account>().ToTable("Client_Accounts_" + version);
            modelBuilder.Entity<Account>().HasKey(m => m.AccountId).Property(m => m.AccountId).HasColumnName("ACCOUNT_NUMBER");
            modelBuilder.Entity<Account>().Property(m => m.Number).HasColumnName("ACCOUNT_NUMBER_DISPLAY");
            modelBuilder.Entity<Account>().Property(m => m.OpenDate).HasColumnName("ACCOUNT_OPEN_DATE");
            modelBuilder.Entity<Account>().Property(m => m.CloseDate).HasColumnName("ACCOUNT_CLOSE_DATE");
            modelBuilder.Entity<Account>().Property(m => m.TypeId).HasColumnName("ACCOUNT_TYPE");
            modelBuilder.Entity<Account>().HasRequired(m => m.AccountType).WithMany().HasForeignKey(m => m.TypeId);

            modelBuilder.Entity<Agreement>().ToTable("Client_Agreements_" + version);
            modelBuilder.Entity<Agreement>().HasKey(m => m.AgreementId).Property(m => m.AgreementId).HasColumnName("AGREEMENT_NUMBER");
            modelBuilder.Entity<Agreement>().Property(m => m.OpenDate).HasColumnName("AGREEMENT_DATE");
            modelBuilder.Entity<Agreement>().Property(m => m.Type).HasColumnName("AGREEMENT_TYPE");
            modelBuilder.Entity<Agreement>().Property(m => m.Rule).HasColumnName("AGREEMENT_RULE");

            modelBuilder.Entity<Role>().ToTable("Client_Roles_" + version);
            modelBuilder.Entity<Role>().HasKey(m => new { m.ClientId, m.AccountId });
            modelBuilder.Entity<Role>().Property(m => m.Name).HasColumnName("CLIENT_ROLE");
            modelBuilder.Entity<Role>().Property(m => m.ClientId).HasColumnName("CLIENT_ID");
            modelBuilder.Entity<Role>().Property(m => m.AccountId).HasColumnName("ACCOUNT_NUMBER");
            modelBuilder.Entity<Role>().Property(m => m.AgreementId).HasColumnName("AGREEMENT_NUMBER");
            modelBuilder.Entity<Role>().HasRequired(m => m.Client).WithMany(m => m.Roles).HasForeignKey(m => m.ClientId);
            modelBuilder.Entity<Role>().HasRequired(m => m.Account).WithMany(m => m.Roles).HasForeignKey(m => m.AccountId);
            modelBuilder.Entity<Role>().HasRequired(m => m.Agreement).WithMany(m => m.Roles).HasForeignKey(m => m.AgreementId);
            modelBuilder.Entity<Role>().Ignore(m => m.Type);

            //modelBuilder.Entity<Operation>().ToTable("Client_Account_Operations_" + version);
            modelBuilder.Entity<Operation>().HasKey(m => new { m.AccountId, m.Rn });
            //modelBuilder.Entity<Operation>().Property(m => m.Rn).HasColumnName("RN");
            //modelBuilder.Entity<Operation>().Property(m => m.AccountId).HasColumnName("ACCOUNT_NUMBER");
            //modelBuilder.Entity<Operation>().Property(m => m.Date).HasColumnName("ACCOUNT_OPERATION_DATE");
            //modelBuilder.Entity<Operation>().Property(m => m.Description).HasColumnName("ACCOUNT_OPERATION_EXPLAINED");
            //modelBuilder.Entity<Operation>().Property(m => m.Income).HasColumnName("ACCOUNT_INCOME_AMOUNT");
            //modelBuilder.Entity<Operation>().Property(m => m.Payment).HasColumnName("ACCOUNT_PAYMENT_AMOUNT");
            //modelBuilder.Entity<Operation>().Property(m => m.Type).HasColumnName("ACCOUNT_OPERATION_TYPE");
            //modelBuilder.Entity<Operation>().HasRequired(m => m.Account).WithMany(m => m.Operations).HasForeignKey(m => m.AccountId);
            modelBuilder.Entity<Invest>().HasKey(m => new { m.ClientId, m.Year });
        }
    }
}
