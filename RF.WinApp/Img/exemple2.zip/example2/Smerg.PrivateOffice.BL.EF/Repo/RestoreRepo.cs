﻿using System;
using System.Collections.Generic;
using System.Linq;
using Smerg.PrivateOffice.BL.Models;
using Smerg.PrivateOffice.BL.Repo;

namespace Smerg.PrivateOffice.BL.EF.Repo
{
    public class RestoreRepo : IRestoreRepo
    {
        private EFCtx _db;

        public RestoreRepo(EFCtx db)
        {
            _db = db;
        }

        public Restore BeginRestore(int clientId)
        {
            var res = _db.RestoreRequests.OrderByDescending(r => r.StartTime).FirstOrDefault(r => r.ClientId == clientId);

            if (res != null && res.StartTime.AddDays(2) >= DateTime.Now)
                return res;

            var ret = new Restore()
            {
                RestoreId = Guid.NewGuid().ToString().Replace("-", "").ToUpper(),
                ClientId = clientId,
                RequestId = Guid.NewGuid(),
                StartTime = DateTime.Now,
                OrderUsed = false
            };

            _db.RestoreRequests.Add(ret);
            _db.SaveChanges();
            return ret;
        }

        public Restore GetRestore(string resCode)
        {
            var ret = _db.RestoreRequests.FirstOrDefault(r => r.RequestId.ToString().Replace("-", "").ToUpper() == resCode);
            if (ret != null && ret.StartTime.AddDays(2) >= DateTime.Now)
                return ret;
            return null;
        }

        public void Update()
        {
            _db.SaveChanges();
        }
    }
}
