﻿using System;
using System.Collections.Generic;
using System.Linq;
using Smerg.PrivateOffice.BL.Models;
using Smerg.PrivateOffice.BL.Repo;

namespace Smerg.PrivateOffice.BL.EF.Repo
{
    public class RegistrationRepo : IRegistrationRepo
    {
        private EFCtx _db;

        public RegistrationRepo(EFCtx db)
        {
            _db = db;
        }

        public Registration BeginRegistration(int clientId, string email, string phone)
        {
            
            var ret = new Registration()
            {
                RegistrationId = Guid.NewGuid(),
                ClientId = clientId,
                RequestId = Guid.NewGuid().ToString().Replace("-", "").ToUpper(),
                SmsCode = Math.Abs(BitConverter.ToInt16(Guid.NewGuid().ToByteArray(), 0)),
                Email = email,
                Phone = phone,
                StartTime = DateTime.Now
            };

            _db.Registrations.Add(ret);
            _db.SaveChanges();
            return ret;
        }

        public Registration GetRegistration(string regCode)
        {
            var ret = _db.Registrations.FirstOrDefault(r => r.RequestId == regCode);
            if (ret != null && ret.StartTime.AddDays(2) >= DateTime.Now)
                return ret;
            return null;
        }

        public void Update()
        {
            _db.SaveChanges();
        }
    }
}
