﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using Smerg.PrivateOffice.BL.Repo;
using Smerg.PrivateOffice.BL.Models;
using Smerg.PrivateOffice.Security;

namespace Smerg.PrivateOffice.BL.EF.Repo
{
    public class UserRepo : IUserRepo
    {
        private EFCtx _db;
        private IDataSynchronizer _boss;
        private IDataLoader _external;

        public UserRepo(EFCtx db, IDataLoader external, IDataSynchronizer boss)
        {
            _db = db;
            _external = external;
            _boss = boss;
        }

        public string ComputePswHash(User user, string psw)
        {
            var hash = "";
            if (user.PasswordHashMethod == 1)
            {
                hash = Utils.GetRFLikeHash(psw, user.PasswordHashSalt);
            }
            else
            {
                hash = Utils.GetRaiffeisenLikeHash(psw);
            }

            return hash;
        }

        public bool CheckUser(User user, string psw)
        {
            return user.PasswordHash.Equals(ComputePswHash(user, psw), StringComparison.InvariantCultureIgnoreCase);
        }

        public User NewUser(Registration reg)
        {
            var ret = NewUser(reg.ClientId, reg.RequestId, reg.RegistrationId.ToString());
            ret.Client.Email = reg.Email;
            ret.Client.Phone = reg.Phone;
            _db.SaveChanges();
            return ret;
        }

        public User NewUser(int clientId, string login, string psw)
        {
            //when add new user must be unique both clientId and login
            var userList = GetUsersByClientId(clientId);
            if (userList.Count == 0)
            {
                var someElseUser = GetUserByName(login);
                if (someElseUser != null)
                    throw new InvalidOperationException("Недопустимое имя пользователя.");

                User ret = _db.Users.Create();
                ret.UserId = clientId;
                ret.Name = login;
                ret.PasswordHash = Utils.GetRaiffeisenLikeHash(psw);
                _db.Users.Add(ret);
                NewUserLoadData(ret);
                _db.SaveChanges();
                return ret;
            }

            userList = userList.Where(u => CheckUser(u, psw)).ToList();
            if (userList.Count == 0)
                throw new InvalidOperationException("Недопустимый пароль пользователя.");

            foreach (var u in userList)
                if (u.Name == login)
                    return u;

            return userList.FirstOrDefault();
        }

        public User GetUserByName(string login)
        {
            var users = GetUsersByName(login);
            if (users.Count == 1)
                return users[0];
            return null;
        }

        public User GetUserById(int id)
        {
            var users = GetUsersByClientId(id);
            if (users.Count > 0)
                return users[0];
            return null;
        }

        private List<User> GetUsersByName(string login)
        {
            return _db.Users.Where(u => u.Name.ToUpper() == login.ToUpper()).ToList();
        }

        private List<User> GetUsersByClientId(int id)
        {
            return _db.Users.Where(u => u.UserId == id).ToList();
        }

        public bool ChangeCredentials(User user, string oldPsw, string newLogin, string newPsw)
        {
            if (user != null)
            {
                if (!CheckUser(user, oldPsw))
                    throw new InvalidOperationException("Неверный пароль.");

                var oldLogin = user.Name;
                if (string.IsNullOrEmpty(newLogin) == false && user.Name != newLogin)
                {
                    var someElseUser = GetUserByName(newLogin);
                    if (someElseUser != null)
                        throw new InvalidOperationException("Недопустимое имя пользователя.");
                    user.Name = newLogin;
                }

                user.PasswordHash = Utils.GetRaiffeisenLikeHash(newPsw);
                _db.SaveChanges();

                //check user who incame from registration. in this case user.name is registration requestid (Guid without '-')
                if (new Regex("^[A-F0-9]{32}$").IsMatch(oldLogin) && _db.Registrations.FirstOrDefault(r => r.RequestId == oldLogin) != null)
                {
                    _boss.BossSynchronize(user);
                }

                return true;
            }

            return false;
        }

        public string ResetPassword(User user)
        {
            var defPsw = Guid.NewGuid().ToString().Replace("-", "");
            user.PasswordHash = Utils.GetRaiffeisenLikeHash(defPsw);
            user.PasswordHashMethod = 0;
            user.PasswordHashSalt = null;
            _db.SaveChanges();
            return defPsw;
        }

        private void NewUserLoadData(User user)
        {
            var agrees = _external.LoadAgreements(user.Client.ClientId).ToArray();
            var accounts = _external.LoadAccounts(user.Client.ClientId).ToArray();
            var roles = _external.LoadRoles(user.Client.ClientId)
                .Join(
                    accounts
                    , r => r.AccountId
                    , a => a.AccountId
                    , (r, a) =>
                    {
                        r.Client = user.Client;
                        r.Account = a;
                        return r;
                    }
                )
                .Join(
                    agrees
                    , r => r.AgreementId
                    , a => a.AgreementId
                    , (r, a) =>
                    {
                        r.Agreement = a;
                        return r;
                    }
                );
            _db.Roles.AddRange(roles);
            _db.SaveChanges();

            var ops = _external.LoadMoney(user.Client.ClientId).ToArray();
            var opSql = string.Format(
                @"insert Client_Account_Operations_{0}
                  (ACCOUNT_NUMBER, ACCOUNT_OPERATION_DATE, ACCOUNT_OPERATION_EXPLAINED, ACCOUNT_INCOME_AMOUNT, ACCOUNT_PAYMENT_AMOUNT, ACCOUNT_OPERATION_TYPE)
                   values(@accId, @date, @desc, @inc, @pay, @type)", _db.MigrationVer);

            foreach (var o in ops)
            {
                _db.Database.ExecuteSqlCommand(opSql
                    , new SqlParameter("accId", o.AccountId)
                    , new SqlParameter("date", o.Date)
                    , new SqlParameter("desc", o.Description)
                    , new SqlParameter("inc", o.Income)
                    , new SqlParameter("pay", o.Payment)
                    , new SqlParameter("type", o.Type)
                );
            }
        }
    }
}
