﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using Smerg.PrivateOffice.BL.Repo;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using Smerg.PrivateOffice.BL.Models;

namespace Smerg.PrivateOffice.BL.EF.Repo
{
    public class ClientRepo : IClientRepo
    {
        private EFCtx _db;

        public ClientRepo(EFCtx db)
        {
            _db = db;
        }

        public Client TryFind(string ipa, string email, string phone)
        {
            Regex rgx = new Regex("[ -]");
            ipa = rgx.Replace(ipa, "");

            var query = _db.Clients.Where(m => m.Ipa == ipa && (m.Email.Equals(email, StringComparison.InvariantCultureIgnoreCase) || m.Phone == phone));
            return query.FirstOrDefault();
        }

        public Client GetByEmail(string email)
        {
            var query = _db.Clients.Where(m => m.Email.Equals(email, StringComparison.InvariantCultureIgnoreCase));
            return query.FirstOrDefault();
        }

        public IEnumerable<Invest> GetInvestInfo(int clientId)
        {
            return _db.InvestInfo.SqlQuery(
                @"select CLIENT_ID as ClientId, IncYear as [Year], IDLoss as Amount from IDLoss where CLIENT_ID=@clientId order by IncYear desc"
                , new SqlParameter("clientId", clientId)
            ).AsNoTracking().ToList();
        }

        public IEnumerable<Role> GetAccountRoles(int clientId)
        {
            var roles = _db.Roles
                .Include(r => r.Account).Include(r => r.Account.AccountType)
                //.Include(r => r.Account.Operations)
                .Where(r => r.ClientId == clientId).ToList();

            var opSql = string.Format(@"select ROW_NUMBER() over (partition by ACCOUNT_NUMBER order by ACCOUNT_OPERATION_DATE desc) as Rn
                                    , ACCOUNT_NUMBER as AccountId
                                    , ACCOUNT_OPERATION_DATE as Date
                                    , ACCOUNT_OPERATION_EXPLAINED as Description
                                    , ACCOUNT_INCOME_AMOUNT as Income
                                    , ACCOUNT_PAYMENT_AMOUNT as Payment
                                    , ACCOUNT_OPERATION_TYPE as Type
                                    from Client_Account_Operations_{0} where ACCOUNT_NUMBER=@accId", _db.MigrationVer);

            foreach(var r in roles)
            {
                r.Account.Operations = _db.Operations.SqlQuery(opSql, new SqlParameter("accId", r.AccountId)).AsNoTracking().ToList();
                r.Type = GetRoleTypeByName(r.Name);
                yield return r;
            }
        }

        private RoleType GetRoleTypeByName(string name)
        {
            switch(name)
            {
                case "Застрахованное лицо": return RoleType.Insured;
                case "Вкладчик": return RoleType.Investor;
                case "Участник": return RoleType.Participant;
                case "Администратор корпоративной программы": return RoleType.СorporateAdmin;
            }

            return RoleType.Insured;
        }
    }
}
