﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace Smerg.Mib.Configuration
{
    public class MibConfiguration : ConfigurationSection
    {
        public static readonly string ConfigurationSectionName = "mib";

        [ConfigurationProperty("service", IsRequired = true)]
        public ServiceElement ServiceSettings
        {
            get
            {
                return (ServiceElement)base["service"];
            }
            set
            {
                base["service"] = value;
            }
        }

        private static object _sync = new object();
        private static MibConfiguration _cnfg = null;
        public static MibConfiguration Configuration
        {
            get
            {
                if (_cnfg == null)
                    lock (_sync)
                        _cnfg = ConfigurationManager.GetSection(ConfigurationSectionName) as MibConfiguration;
                return _cnfg;
            }
        }
    }
}

