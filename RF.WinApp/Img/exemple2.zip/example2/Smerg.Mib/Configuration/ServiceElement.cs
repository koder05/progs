﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace Smerg.Mib.Configuration
{
    public class ServiceElement : ConfigurationElement
    {
        [ConfigurationProperty("realm", IsRequired = true)]
        public Uri Realm
        {
            get
            {
                return (Uri)this["realm"];
            }
            set
            {
                this["realm"] = value;
            }
        }

        [ConfigurationProperty("authorization")]
        public string AuthorizationHeader
        {
            get
            {
                return (string)this["authorization"];
            }
            set
            {
                this["authorization"] = value;
            }
        }

        [ConfigurationProperty("merchant", IsRequired = true)]
        public string Merchant
        {
            get
            {
                return (string)this["merchant"];
            }
            set
            {
                this["merchant"] = value;
            }
        }

        [ConfigurationProperty("ignoreSsl")]
        public bool IgnoreSslValidation
        {
            get
            {
                return this["ignoreSsl"] == null ? false : (bool)this["ignoreSsl"];
            }
            set
            {
                this["ignoreSsl"] = value;
            }
        }
    }
}
