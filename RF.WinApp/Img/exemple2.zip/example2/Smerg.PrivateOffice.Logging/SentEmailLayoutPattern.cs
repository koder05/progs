﻿using System;
using log4net.Layout;
using log4net.Util;

namespace Smerg.PrivateOffice.Logging
{
    public class SentEmailLayoutPattern : PatternLayout
    {
        public SentEmailLayoutPattern()
        {
            AddConverter(new ConverterInfo { Name = "email", Type = typeof(SentEmailConverter) });
        }
    }
}
