﻿using System;
using System.IO;
using log4net.Core;
using log4net.Util;
using log4net.Layout.Pattern;
using Smerg.PrivateOffice.BL.Logging;

namespace Smerg.PrivateOffice.Logging
{
    public class SentEmailConverter : PatternLayoutConverter
    {
        protected override void Convert(TextWriter writer, LoggingEvent loggingEvent)
        {
            if (loggingEvent == null)
            {
                writer.Write(SystemInfo.NullText);
                return;
            }

            var info = loggingEvent.MessageObject as SentEmail;

            if (info == null)
            {
                writer.Write(SystemInfo.NullText);
            }
            else
            {
                switch (this.Option.ToLower())
                {
                    case "from":
                        writer.Write(info.MailFrom);
                        break;
                    case "to":
                        writer.Write(info.MailTo);
                        break;
                    case "title":
                        writer.Write(info.MailSubject);
                        break;
                    case "body":
                        writer.Write(info.MailTextBody);
                        break;
                    case "reply":
                        writer.Write(info.MailReplyTo);
                        break;
                    default:
                        writer.Write(SystemInfo.NullText);
                        break;
                }
            }
        }
    }
}
