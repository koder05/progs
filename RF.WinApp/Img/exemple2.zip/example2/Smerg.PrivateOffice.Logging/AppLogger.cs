﻿using System;
using System.Collections.Generic;
using System.Linq;
using RF.Common.Logging;
using log4net;

namespace Smerg.PrivateOffice.Logging
{
    public class AppLogger : ILogger
    {
        public void Log(object o, string message, string eventType)
        {
            ILog _log = LogManager.GetLogger("Smerg.PrivateOffice.Logging.App." + eventType);
            if (_log != null)
                _log.Info(o);
        }
    }
}
