﻿using System;
using System.IO;
using log4net.Core;
using log4net.Util;
using log4net.Layout.Pattern;
using Smerg.PrivateOffice.BL.Logging;

namespace Smerg.PrivateOffice.Logging
{
    public class UserConverter : PatternLayoutConverter
    {
        protected override void Convert(TextWriter writer, LoggingEvent loggingEvent)
        {
            if (loggingEvent == null)
            {
                writer.Write(SystemInfo.NullText);
                return;
            }

            var info = loggingEvent.MessageObject as UserActivity;

            if (info == null)
            {
                writer.Write(SystemInfo.NullText);
            }
            else
            {
                switch (this.Option.ToLower())
                {
                    case "client":
                        writer.Write(info.ClientId);
                        break;
                    case "ip":
                        writer.Write(info.Ip);
                        break;
                    case "token":
                        writer.Write(info.TokenHash);
                        break;
                    case "agent":
                        writer.Write(info.UserAgent);
                        break;
                    case "login":
                        writer.Write(info.UserName);
                        break;
                    case "psw":
                        writer.Write(info.UserPsw);
                        break;
                    default:
                        writer.Write(SystemInfo.NullText);
                        break;
                }
            }
        }
    }

}
