﻿using System;
using log4net.Layout;
using log4net.Util;

namespace Smerg.PrivateOffice.Logging
{
    public class UserLayoutPattern : PatternLayout
    {
        public UserLayoutPattern()
        {
            AddConverter(new ConverterInfo {Name = "user",  Type = typeof(UserConverter)});
        }
    }
}
