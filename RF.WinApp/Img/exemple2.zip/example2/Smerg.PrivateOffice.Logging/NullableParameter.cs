﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using log4net.Appender;
using log4net.Core;

namespace Smerg.PrivateOffice.Logging
{
    public class NullableParameter : AdoNetAppenderParameter
    {
        public override void FormatValue(IDbCommand command, LoggingEvent loggingEvent)
        {
            base.FormatValue(command, loggingEvent);
            IDbDataParameter param = (IDbDataParameter)command.Parameters[ParameterName];
            if (param.Value == null || (param.Value.GetType() == typeof(string) && string.IsNullOrEmpty((string)param.Value)))
            {
                param.Value = DBNull.Value;
            }
        }
    }
}
