﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RF.Common.Logging;
using log4net;
using log4net.Config;


namespace Smerg.PrivateOffice.Logging
{
    public class LogLauncher : ILogLauncher
    {
        public LogLauncher()
        {
            XmlConfigurator.Configure();
        }

        public ILogger GetLogApp()
        {
            return new AppLogger();
        }

        public ILogger GetLogDb()
        {
            throw new NotImplementedException();
        }

        public ILogger GetLogErr()
        {
            throw new NotImplementedException();
        }

        public ILogger GetLogUser()
        {
            return new UserLogger();
        }
    }
}
