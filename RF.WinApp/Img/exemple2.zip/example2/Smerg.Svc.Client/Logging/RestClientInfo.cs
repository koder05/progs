﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace Smerg.Svc.Client.Logging
{
    public class RestClientInfo
    {
        public string Url { get; set; }
        public RestApiAction Action { get; set; }
        public string Data { get; set; }
        public string User { get; set; }
        public HttpStatusCode Status { get; set; }
    }

    public enum RestApiAction
    {
        Request,
        Response
    }
}
