﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using log4net.Core;
using log4net.Layout;
using log4net.Util;
using log4net.Layout.Pattern;

namespace Smerg.Svc.Client.Logging
{
    public class RestClientConverter : PatternLayoutConverter
    {
        protected override void Convert(System.IO.TextWriter writer, LoggingEvent loggingEvent)
        {
            if (loggingEvent == null)
            {
                writer.Write(SystemInfo.NullText);
                return;
            }

            var actionInfo = loggingEvent.MessageObject as RestClientInfo;

            if (actionInfo == null)
            {
                writer.Write(SystemInfo.NullText);
            }
            else
            {
                switch (this.Option.ToLower())
                {
                    case "url":
                        writer.Write(actionInfo.Url);
                        break;
                    case "action":
                        writer.Write(actionInfo.Action);
                        break;
                    case "json":
                        writer.Write(actionInfo.Data);
                        break;
                    case "user":
                        writer.Write(actionInfo.User);
                        break;
                    case "status":
                        writer.Write(actionInfo.Status);
                        break;
                    default:
                        writer.Write(SystemInfo.NullText);
                        break;
                }
            }
        }
    }

}
