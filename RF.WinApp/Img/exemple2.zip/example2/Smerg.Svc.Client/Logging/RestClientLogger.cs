﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestSharp;
using log4net;

namespace Smerg.Svc.Client.Logging
{
    internal class RestClientLogger
    {
        private RestClientInfo _info = new RestClientInfo();
        private ILog _log = LogManager.GetLogger("Smerg.Svc.Log");
        internal RestClientLogger(RestClient client)
        {
            _info.User = System.Threading.Thread.CurrentPrincipal.Identity.Name;
            _info.Url = client.BaseUrl.OriginalString;
        }

        internal void LogRequest(IRestRequest req)
        {
            foreach (var p in req.Parameters)
            {
                if (p.Name == "method")
                    _info.Url += "/" + p.Value;
                if (p.Name == "application/json")
                    _info.Data = p.Value.ToString();
            }
            _info.Action = RestApiAction.Request;
            _info.Status = System.Net.HttpStatusCode.Created;
            _log.Info(_info);
        }

        internal void LogResponse(IRestResponse res)
        {
            _info.Action = RestApiAction.Response;
            _info.Url = res.ResponseUri.ToString();
            _info.Data = res.Content;
            _info.Status = res.StatusCode;
            _log.Info(_info);
        }
    }
}
