﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Smerg.PrivateOffice.BL.Repo;

namespace Smerg.Svc.Client
{
    public class SmsResponse
    {
        public int MessageID { get; set; }
    }
    public class SmsService : ISmsService
    {
        public int SendSms(string phone, string msg)
        {
            var res = Service.Exec<SmsResponse>("sendSMS", new
            {
                phone_number = phone,
                message_text = msg,
                message_type = 12,
                object_id = ""
            });

            return res?.MessageID ?? 0;
        }
    }
}
