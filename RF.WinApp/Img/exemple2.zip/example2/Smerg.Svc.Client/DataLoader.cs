﻿using System;
using System.Collections.Generic;
using System.Linq;
using Smerg.PrivateOffice.BL.Models;
using Smerg.PrivateOffice.BL.Repo;
using SvcBl = Smerg.Svc.BL.Models;

namespace Smerg.Svc.Client
{
    public class DataLoader : IDataLoader
    {
        public IEnumerable<Agreement> LoadAgreements(int clientId)
        {
            var reqParam = new SvcBl.ClientID() { ClientIdentifier = clientId };
            var list = Service.Exec<IEnumerable<SvcBl.Agreement>>("GetAgreements", reqParam);
            if (list != null)
            {
                return list.Select(a => new Agreement()
                {
                    AgreementId = a.AgreementNumber,
                    OpenDate = a.AgreementDate ?? new DateTime(0),
                    Type = a.AgreementType,
                    Rule = a.AgreementRule
                });
            }
            return null;
        }

        public IEnumerable<Account> LoadAccounts(int clientId)
        {
            var reqParam = new SvcBl.ClientID() { ClientIdentifier = clientId };
            var list = Service.Exec<IEnumerable<SvcBl.Account>>("GetAccounts", reqParam);
            if (list != null)
            {
                return list.Select(a => new Account()
                {
                    AccountId = a.AccountNumber,
                    Number = a.AccountNumberDisplay,
                    CloseDate = a.AccountCloseDate,
                    OpenDate = a.AccountOpenDate ?? new DateTime(0),
                    TypeId = a.AccountType ?? 0
                });
            }
            return null;
        }

        public IEnumerable<Operation> LoadMoney(int clientId)
        {
            var reqParam = new SvcBl.ClientID() { ClientIdentifier = clientId };
            var list = Service.Exec<IEnumerable<SvcBl.Operation>>("GetOperations", reqParam);
            if (list != null)
            {
                return list.Select(o => new Operation()
                {
                    Income = o.ACCOUNT_INCOME_AMOUNT,
                    AccountId = o.ACCOUNT_NUMBER,
                    Date = o.ACCOUNT_OPERATION_DATE ?? new DateTime(0),
                    Description = o.ACCOUNT_OPERATION_EXPLAINED,
                    Payment = o.ACCOUNT_PAYMENT_AMOUNT,
                    Type = o.ACCOUNT_OPERATION_TYPE
                });
            }
            return null;
        }

        public IEnumerable<Role> LoadRoles(int clientId)
        {
            var reqParam = new SvcBl.ClientID() { ClientIdentifier = clientId };
            var list = Service.Exec<IEnumerable<SvcBl.Role>>("GetRoles", reqParam);
            if (list != null)
            {
                return list.Select(r => new Role()
                {
                    AccountId = r.ACCOUNT_NUMBER,
                    AgreementId = r.AGREEMENT_NUMBER,
                    ClientId = r.CLIENT_ID,
                    Name = r.CLIENT_ROLE
                });
            }
            return null;
        }
    }
}

