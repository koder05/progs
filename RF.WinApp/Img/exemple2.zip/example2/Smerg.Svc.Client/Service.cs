﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using RestSharp;
using log4net;
using log4net.Core;
using log4net.Config;
using log4net.Util;
using Smerg.Svc.Client.Logging;

namespace Smerg.Svc.Client
{
    internal static class Service
    {
        static Service()
        {
            if (SvcConfiguration.Configuration.ServiceSettings.IgnoreSslValidation)
                ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
            XmlConfigurator.Configure();
        }

        internal static T Exec<T>(string apiMethod, object body, Method httpMethod = Method.POST)
        {
            //var client = new RestClient("https://s-npf1-app01.npfSmerg.ru:8095/mibt/api");
            var client = new RestClient(SvcConfiguration.Configuration.ServiceSettings.Realm);
            var request = new RestRequest("{method}", httpMethod);
            request.RequestFormat = DataFormat.Json;
            request.AddUrlSegment("method", apiMethod);
            if (string.IsNullOrEmpty(SvcConfiguration.Configuration.ServiceSettings.AuthorizationHeader) == false)
                request.AddHeader("Authorization", SvcConfiguration.Configuration.ServiceSettings.AuthorizationHeader);
            //request.AddHeader("Authorization", "Basic cHVibGljOnB1YmxpYw==");
            if (httpMethod == Method.POST || httpMethod == Method.PUT)
                request.AddBody(body);

            var logger = new RestClientLogger(client);
            logger.LogRequest(request);
            var res = client.Execute(request);
            logger.LogResponse(res);
            var ret = client.Deserialize<T>(res);
            return ret.Data;
        }
    }
}
