﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using Smerg.PrivateOffice.BL.Models.Mib;
using Smerg.PrivateOffice.BL.Repo;
using Smerg.Svc.Client;

namespace Smerg.Mib
{
    public class MibServiceRepo : IMibService
    {
        public OrderResponse CreateOrder(OrderRequest req)
        {
            req.Request.Operation = "CreateOrder";
            req.Request.Language = "RU";
            req.Request.Order.Merchant = SvcConfiguration.Configuration.ServiceSettings.MibMerchant;
            req.Request.Order.Currency = 643;
            req.Request.Order.OrderType = "Purchase";
            req.Request.Order.AddParams = new OrderRequestParams() { Recurfrequency = "1", RecurendRecur = "21001212" };
            var ret = Service.Exec<OrderResponse>("CreateOrder", req);
            //var ret = new OrderResponse()
            //{
            //    Response = new OrderResponseOperation()
            //    {
            //        Order = new OrderResponseOperationOrder()
            //        {
            //            OrderID = 3405,
            //            SessionID = "974834DE8224C6EEF4DF7543E58B43E7",
            //            URL = "http://localhost:53513/mibtest.html"
            //        },
            //        Operation = "CreateOrder",
            //        Status = "00"
            //    }
            //};

            if (ret != null && ret.Response != null && ret.Response.Status == "00" && ret.Response.Order != null && ret.Response.Order.OrderID > 0)
            {
                ret.PurchaseUrl = new Uri(string.Format("{0}?OrderID={1}&SessionID={2}", ret.Response.Order.URL, ret.Response.Order.OrderID, ret.Response.Order.SessionID));
                return ret;
            }

            return null;
        }

        public object ConfirmPurchase(PaymentDetails pmnt)
        {
            var body = new
            {
                AgreementNumber = pmnt.AgreementId,
                Periodicity = pmnt.Periodicity,
                Amount = pmnt.Amount,
                PaymentOrderId = pmnt.OrderId,
                PaymentSessionId = pmnt.SessionId

            };
            return Service.Exec<object>("SetNewPaymentParams", body);
        }

        public AutoPaymentResponse GetAutoPayment(AutoPaymentRequest req)
        {
            //return new AutoPaymentResponse()
            //{
            //    AgreementId = 110,
            //    Periodicity = 2,
            //    Amount = 10m,
            //    DateFrom = DateTime.Now,
            //    PaymentOrderId = "333",
            //    PaymentSessionId = "ADGHNJH < LHHKLGUYFIK",
            //    Description = "dddd",
            //    DescriptionFull = "fffff"
            //};
            return Service.Exec<AutoPaymentResponse>("GetPaymentParams", req);
        }

        public object AutoPaymentCancel(int agreeId)
        {
            return Service.Exec<object>("SwitchOffRegPay", new { AgreementNumber = agreeId });
        }

        public PurchaseResult CheckPurchaseResult(string xmlmsg)
        {
            if (string.IsNullOrEmpty(xmlmsg) == false)
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xmlmsg);
                var ret = new PurchaseResult();
                ret.Status = PurchaseStatus.ERROR;
                var node = doc.SelectSingleNode("/Message/OrderID");
                if (node != null)
                {
                    int id;
                    int.TryParse(node.InnerText, out id);
                    ret.OrderId = id;
                }
                node = doc.SelectSingleNode("/Message/OrderStatus");
                if (node != null)
                {
                    var o = Enum.Parse(typeof(PurchaseStatus), node.InnerText);
                    ret.Status = o == null ? PurchaseStatus.ERROR : (PurchaseStatus)o;
                }

                return ret;
            }

            return null;
        }
    }
}
