﻿using System;
using System.Collections.Generic;
using System.Linq;
using Smerg.PrivateOffice.BL.Models;
using Smerg.PrivateOffice.BL.Repo;
using SvcBl = Smerg.Svc.BL.Models;

namespace Smerg.Svc.Client
{
    public class DataSynchronizer : IDataSynchronizer
    {
        public bool BossSynchronize(User user)
        {
            var reqParam = new SvcBl.RegistrationInfo()
            {
                ClientID = user.Client.ClientId,
                Email = user.Client.Email,
                PhoneMobile = user.Client.Phone,
                UserLogin = user.Name,
                UserPassword = user.PasswordHash
            };
            var res = Service.Exec<int>("UpdateBackInfoReg", reqParam);
            return res == 1;
        }
    }


    public class DataSynchronizerStub : IDataSynchronizer
    {
        public bool BossSynchronize(User user)
        {
            return true;
        }
    }
}
