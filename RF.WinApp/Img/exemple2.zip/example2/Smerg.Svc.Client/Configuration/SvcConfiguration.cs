﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace Smerg.Svc.Client
{
    public class SvcConfiguration : ConfigurationSection
    {
        public static readonly string ConfigurationSectionName = "Smerg.svc";

        [ConfigurationProperty("service", IsRequired = true)]
        public ServiceElement ServiceSettings
        {
            get
            {
                return (ServiceElement)base["service"];
            }
            set
            {
                base["service"] = value;
            }
        }

        private static object _sync = new object();
        private static SvcConfiguration _cnfg = null;
        public static SvcConfiguration Configuration
        {
            get
            {
                if (_cnfg == null)
                    lock (_sync)
                        _cnfg = ConfigurationManager.GetSection(ConfigurationSectionName) as SvcConfiguration;
                return _cnfg;
            }
        }
    }
}

