﻿using System;
using System.Drawing;

namespace SqlCompactSandbox
{
    class EmguText
    {
        public void Test1()
        {
            //var model = new Mat(@"C:\TEMP\Emgu\Cert\CertBlank.png");
            //model.SetTo(new MCvScalar(255, 255, 255, 255));
            var blank = Image.FromFile(@"C:\TEMP\Emgu\Cert\CertBlank.png");
            Graphics g = Graphics.FromImage(blank);
            g.Clear(Color.Empty);
            Font font = new Font("Arial", 12, FontStyle.Regular, GraphicsUnit.Pixel);

            //FIO
            var text = "Бильшекташев-Петровский Муххамеддин Гальбидурусович - Бильшекташев-Петровский Муххамеддин Гальбидурусович - Бильшекташев-Петровский Муххамеддин Гальбидурусович";
            var rect = new RectangleF(164, 93, 998 - 164, 14);
            Text(text, font, rect, g);

            //actual time
            var dfrom = new DateTime(2018, 2, 1, 2, 8, 0);
            var dto = new DateTime(2018, 4, 10, 13, 12, 0);
            text = string.Format("Действителен с {0:dd MMMM yyyy г. H:mm:ss UTC} по {1:dd MMMM yyyy г. H:mm:ss UTC}", dfrom, dto);
            rect = new RectangleF(152, 137, 998 - 152, 14);
            Text(text, font, rect, g);

            //actual from
            text = string.Format("Действителен с: {0:dd MMMM yyyy г. H:mm:ss UTC}", dfrom);
            rect = new RectangleF(152, 227, 998 - 152, 14);
            Text(text, font, rect, g);

            //expired
            text = string.Format("Действителен по: {0:dd MMMM yyyy г. H:mm:ss UTC}", dto);
            rect = new RectangleF(152, 242, 998 - 152, 14);
            Text(text, font, rect, g);

            //cert owner
            text = "                                                     CN = Заявлениевый Апин Договорович, SN = Заявлениевый, G = Апин Договорович, C = RU, СНИЛС = 00000999999, ИНН = 770032607592, г. Москва (77)";
            rect = new RectangleF(139, 258, 998 - 139, 28);
            Text(text, font, rect, g, false);

            //cert value
            text = "                       0440 5AD2 1B4B DA38 506C 305F 6836 8D6F AEDB C0AC FE52 F72C 4CB4 EF00 53C9 2C31 0CDD CCAB 845D 5D85 E093 CB7B C631 83C5 4E8B 73A7 CD1B 0C4C 0979 8FD9 9025 5034 8D5C";
            rect = new RectangleF(152, 363, 998 - 152, 28);
            Text(text, font, rect, g, false);

            //x509 value
            text = "5f 5b df d3 fb 90 f1 83 70 11 a 2 27 ff e d dc 7a cd ce d5 36";
            rect = new RectangleF(243, 528, 998 - 243, 14);
            Text(text, font, rect, g, false);

            //x509 actual time
            var x509dfrom = new DateTime(2018, 2, 1, 12, 8, 0);
            var x509dto = new DateTime(2018, 4, 10, 19, 12, 0);
            text = string.Format("Действителен с {0:dd MMMM yyyy г. H:mm:ss} Действителен по {1:dd MMMM yyyy г. H:mm:ss}", x509dfrom, x509dto);
            rect = new RectangleF(243, 768, 998 - 243, 14);
            Text(text, font, rect, g, false);

            //issuer key value
            text = "                       FD9A 31EB A858 67DD 556D E7DA 01B8 438F D9CA C042 1679 FF2E 7B01 9A2E 86DC 8759 6803 A2BB 2066 8912 CD5E B996 5C79 E7AF 015C 49EC CCB6 DF0B 92DE EE71 CDCE B88B";
            rect = new RectangleF(152, 979, 998 - 152, 28);
            Text(text, font, rect, g, false);

            blank.Save(@"C:\TEMP\Emgu\Cert\CertRawData.png");
        }

        public void Text(string text, Font textFont, RectangleF textPlaceHolder, Graphics canvas, bool tryFit = true, bool tryWrap = true)
        {
            var fontSize = textFont.Size;
            if (tryFit)
            {
                while (canvas.MeasureString(text, textFont).Width > textPlaceHolder.Width)
                {
                    fontSize--;
                    if (fontSize < 7)
                        break;
                    textFont = new Font(textFont.FontFamily, fontSize, textFont.Style, textFont.Unit);
                }
            }

            var sfo = StringFormatFlags.FitBlackBox;
            if (!tryWrap)
                sfo |= StringFormatFlags.NoWrap;

            canvas.DrawString(text, textFont, Brushes.Black
                , textPlaceHolder
                , new StringFormat(sfo)
                );
        }
    }
}
