﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using smerg.Agent.BL;
using System.Data.Entity;
using SqlCompactSandbox.Migrations;

namespace SqlCompactSandbox
{
    class Program
    {
        static void Main(string[] args)
        {
            //Database.SetInitializer(new MigrateDatabaseToLatestVersion<smerg.Agent.BL.EF.MyDbContext, Configuration>());
            //using (var db = new smerg.Agent.BL.EF.MyDbContext())
            //{
            //    var m = db.PersonData.FirstOrDefault();
            //    Console.WriteLine(m.LastName);
            //}

            //new TesserExmpl().Do();
            //new ImageProcess().Test();
            //new EmguTest().TestCert();
            //new EmguText().Test1();
            //new VerificationCenter().Cert();

            //Console.WriteLine(Utils.GetRaiffeisenLikeHash("Abn123456!"));
            Console.WriteLine(Utils.GetRaiffeisenLikeHash("Temp123"));

            Console.WriteLine("press.......");
            Console.ReadLine();
        }
    }
}
