﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Smerg.Agent.BL;
using System.Data.Entity.Infrastructure;
using System.Configuration;
using Smerg.Agent.BL.Auth;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity.Validation;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Core;
using System.Data.Entity.Core.Metadata.Edm;

namespace Smerg.Agent.BL.EF
{
    public class MyDbContext : DbContext
    {
        public MyDbContext() : base("MainDb")
        //: base()
        {
            //Task.Factory.StartNew(() => {this.Database.Connection.ConnectionString = ConfigurationManager.ConnectionStrings["MainDb"].ConnectionString + ";Encrypt Database=True; password=" + AuthProvider.Behavior.GetCredentials()?.Psw;});
        }

        public DbSet<PersonData> PersonData { get; set; }
        public DbSet<Filestore> Files { get; set; }
        public DbSet<CladrModel> Addr { get; set; }
        public DbSet<OksmCountry> CountryInfo { get; set; }
        public DbSet<Phone> Phones { get; set; }
        public DbSet<Heir> Heirs { get; set; }

        protected override bool ShouldValidateEntity(DbEntityEntry entityEntry)
        {
            if (entityEntry.Entity is Filestore)
            {
                return false;
            }
            return base.ShouldValidateEntity(entityEntry);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            //try delete entities (owned pk) after remove fk association
            var states = ((IObjectContextAdapter)this).ObjectContext.ObjectStateManager;
            ChangeTracker.DetectChanges();
            foreach (var rel in states.GetObjectStateEntries(EntityState.Deleted).Where(e => e.IsRelationship))
            {
                ObjectStateEntry l;
                ObjectStateEntry r;

                var keyl = rel.OriginalValues[0] as EntityKey;
                var keyr = rel.OriginalValues[1] as EntityKey;
                if (keyl != null && keyr != null)
                {
                    states.TryGetObjectStateEntry(keyl, out l);
                    states.TryGetObjectStateEntry(keyr, out r);

                    if ((l != null && l.State == EntityState.Deleted) || (r != null && r.State == EntityState.Deleted))
                        continue;

                    if (r != null && r.State == EntityState.Unchanged)
                        r.ChangeState(EntityState.Deleted);
                }
            }
            return base.SaveChanges();
        }
    }
}
