﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RF.LinqExt;
using Smerg.Agent.BL;
using System.Data.Entity;

namespace Smerg.Agent.BL.EF
{
    public class PersonDataRepo : IPersonDataRepo
    {
        private MyDbContext _db;
        private IFilterOperatorResolver opResolver = new FilterPropResolver();
        public PersonDataRepo(MyDbContext db)
        {
            //need to create new sdf file when database is empty yet
            //db.SaveChanges();
            //roll migrations scripts
            //Database.SetInitializer(new MigrateDatabaseToLatestVersion<MyDbContext, SqlCompactSandbox.Migrations.Configuration>());
            _db = db;
        }

        public PersonData New()
        {
            var m = _db.PersonData.Create();
            m.AddrReg = _db.Addr.Create();
            m.AddrFact = _db.Addr.Create();
            m.PhoneMobile = _db.Phones.Create();
            m.Heirs = new List<Heir>();
            return m;
        }

        public object Create(PersonData o)
        {
            _db.PersonData.Add(o);
            _db.SaveChanges();
            return o;
        }

        public void Delete(PersonData o)
        {
            _db.Files.RemoveRange(o.Files);
            _db.Heirs.RemoveRange(o.Heirs);
            var ar = o.AddrReg;
            var af = o.AddrFact;
            var fc1 = o.ForeignCountryCitizenship;
            var fc2 = o.ForeignCountryTaxpayer;
            var fc3 = o.ForeignCountryResidence;
            var fc4 = o.ForeignCountryAccounts;
            var ph1 = o.PhoneMobile;
            var ph2 = o.Phone2;
            var ph3 = o.Phone3;

            _db.PersonData.Remove(o);
            if (ar != null)
                _db.Addr.Remove(ar);
            if (af != null)
                _db.Addr.Remove(af);
            if (fc1 != null)
                _db.CountryInfo.Remove(fc1);
            if (fc2 != null)
                _db.CountryInfo.Remove(fc2);
            if (fc3 != null)
                _db.CountryInfo.Remove(fc3);
            if (fc4 != null)
                _db.CountryInfo.Remove(fc4);
            if (ph1 != null)
                _db.Phones.Remove(ph1);
            if (ph2 != null)
                _db.Phones.Remove(ph2);
            if (ph3 != null)
                _db.Phones.Remove(ph3);

            _db.SaveChanges();
        }

        public PersonData GetById(Guid id)
        {
            throw new NotImplementedException();
        }

        public int GetIndexOf(PersonData o, FilterParameterCollection filters, SortParameterCollection orderBy)
        {
            var list = _db.PersonData.Filtering(filters, opResolver).Sorting(orderBy);
            int i = 0;
            foreach (var m in list)
            {
                if (m.Id == o.Id)
                    return i;
                i++;
            }
            return 0;
        }

        public IEnumerable<PersonData> GetList(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy)
        {
            lock (_db)
            {
                var list = _db.PersonData.Filtering(filters, opResolver).Sorting(orderBy).Paging(startRowIndex, maximumRows);
                foreach (var m in list)
                    yield return m;
            }
        }

        public int GetListCount(FilterParameterCollection filters)
        {
            lock (_db)
            {
                return _db.PersonData.Filtering(filters, opResolver).Count();
            }
        }

        public void Update(PersonData o)
        {
            try
            {
                _db.SaveChanges();
            }
            catch(Exception e)
            {
                throw e;
            }
        }

        private void SaveHeirs(IList<Heir> heirs, Guid id)
        {
            foreach (var item in GetHeirsByPersonID(id))
            {
                RemoveHeir(item);
            }
            foreach (var heir in heirs)
            {
                AddHeir(heir);
            }
        }

        public void AddFile(Filestore f)
        {
            _db.Files.Add(f);
            _db.SaveChanges();
        }

        public void RemoveFile(Filestore file)
        {
            _db.Files.Remove(file);
            _db.SaveChanges();
        }

        public void AddHeir(Heir h)
        {
            _db.Heirs.Add(h);
            _db.SaveChanges();
        }

        public void RemoveHeir(Heir hier)
        {
            _db.Heirs.Remove(hier);
            _db.SaveChanges();
        }

        public IEnumerable<Heir> GetHeirsByPersonID(Guid personID)
        {
            return _db.Heirs.Where(c => c.PersonData.Id == personID).ToList();
        }
    }
}
