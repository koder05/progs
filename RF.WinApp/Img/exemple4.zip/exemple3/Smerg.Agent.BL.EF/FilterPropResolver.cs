﻿using System;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Reflection;
using System.Data.Entity.SqlServer;
using RF.LinqExt;

namespace Smerg.Agent.BL.EF
{
    public class FilterPropResolver : DefaultFilterOperatorResolver
    {
        public override Expression FindResolution(OperatorType op, Expression prop, Expression val)
        {
            if (op == OperatorType.In)
            {
                var enumerableType = typeof(Enumerable);
                var bar =
                (
                    from m in enumerableType.GetMethods(BindingFlags.Static | BindingFlags.Public)
                    where m.Name == "Contains"
                    let p = m.GetParameters()
                    where p.Length == 2
                        && p[0].ParameterType.IsGenericType
                        && p[0].ParameterType.GetGenericTypeDefinition() == typeof(IEnumerable<>)
                    select m
                ).SingleOrDefault();

                var pm = prop as MemberExpression;
                var propInfo = pm.Member as PropertyInfo;
                if (propInfo.PropertyType.BaseType == typeof(Enum))
                    return Expression.Call(
                        bar.MakeGenericMethod(new[] { typeof(int) })
                        , Expression.Convert(val, typeof(List<int>))
                        , Expression.Convert(prop, typeof(int))
                        );

                return Expression.Empty();
            }
            else
            {
                return base.FindResolution(op, prop, val);
            }
        }
    }
}
