﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Smerg.Agent.BL.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class EnumRequiredAttribute : ValidationAttribute
    {
        private int[] excludeValues;
        private Type type;
        public EnumRequiredAttribute(Type enumType, params int[] exclude)
        {
            type = enumType;
            excludeValues = exclude;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            string msg = this.FormatErrorMessage(validationContext?.DisplayName);

            if (value != null && value.GetType() == type)
            {
                var val = Convert.ToInt32(value);
                foreach(var i in excludeValues)
                    if(i == val)
                        return new ValidationResult(msg);
                return ValidationResult.Success;
            }
            return new ValidationResult(msg);
        }
    }
}
