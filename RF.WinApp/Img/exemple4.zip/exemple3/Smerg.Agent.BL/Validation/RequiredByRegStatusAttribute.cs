﻿using System;
using System.ComponentModel.DataAnnotations;
using Smerg.Agent.BL;

namespace Smerg.Agent.BL.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class RequiredByRegStatusAttribute : ValidationAttribute
    {
        private RegStatus _status;
        public RequiredByRegStatusAttribute(RegStatus s)
        {
            _status = s;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = validationContext.ObjectInstance as PersonData;
            if (model != null && model.RegStatus >= _status
                && (value == null || string.IsNullOrEmpty(value.ToString())))
            {
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            }
            return ValidationResult.Success;
        }
    }
}