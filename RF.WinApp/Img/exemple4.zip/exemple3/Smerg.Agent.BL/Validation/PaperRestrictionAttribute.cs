﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL.Validation
{
    internal class PaperRestrictionAttribute : RegularExpressionAttribute
    {
        private PaperRuleAttribute _rule;
        public PaperRestrictionAttribute(PaperRuleAttribute rule)
            : base(rule.Rx)
        {
            _rule = rule;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var rxResult = base.IsValid(value, validationContext);

            if (rxResult != ValidationResult.Success && _rule != null)
            {
                rxResult.ErrorMessage = string.Format("{0} Пример: {1}", rxResult.ErrorMessage, _rule.Sample);
            }

            return rxResult;
        }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class PaperPartRestrictionAttribute : ValidationAttribute
    {
        private PaperPart _part;
        public PaperPartRestrictionAttribute(PaperPart part)
        {
            _part = part;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = validationContext.ObjectInstance as PersonData;
            if (model != null)
            {
                var doc = model.PaperType;
                string name = Enum.GetName(typeof(Paper), doc);
                if (!string.IsNullOrEmpty(name))
                {
                    var fi = typeof(Paper).GetField(name);
                    var attr = Attribute.GetCustomAttributes(fi).FirstOrDefault(a => a is PaperRuleAttribute && ((PaperRuleAttribute)a).Part == _part);
                    if (attr != null)
                    {
                        var validAttr = new PaperRestrictionAttribute(attr as PaperRuleAttribute);
                        return validAttr.GetValidationResult(value, validationContext);
                    }
                }
            }
            return ValidationResult.Success;
        }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class PaperSeriesRestrictionAttribute : PaperPartRestrictionAttribute
    {
        public PaperSeriesRestrictionAttribute() 
            : base(PaperPart.Series) 
        { }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class PaperNumberRestrictionAttribute : PaperPartRestrictionAttribute
    {
        public PaperNumberRestrictionAttribute() 
            : base(PaperPart.Number) 
        { }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class PaperIssuerRestrictionAttribute : PaperPartRestrictionAttribute
    {
        public PaperIssuerRestrictionAttribute()
            : base(PaperPart.IssuerCode)
        { }
    }
}
