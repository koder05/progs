﻿using System;
using System.ComponentModel.DataAnnotations;
using Smerg.Agent.BL;

namespace Smerg.Agent.BL.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class RequiredStatementKindAttribute : ValidationAttribute
    {
        private RegStatus _status;
        public RequiredStatementKindAttribute(RegStatus s)
        {
            _status = s;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = validationContext.ObjectInstance as PersonData;
            if (new EnumRequiredAttribute(typeof(StatementKind), (int)StatementKind.Undefined).IsValid(value) == false
                && model != null && model.RegStatus >= _status)
            {
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            }
            return ValidationResult.Success;
        }
    }
}