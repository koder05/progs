﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL
{
    public class PaperRuleAttribute : Attribute
    {
        public string Mask { get; private set; }
        public string Rx { get; private set; }
        public string Sample { get; private set; }

        public PaperPart Part { get; private set; }

        public PaperRuleAttribute(string mask, string regex, string sample, PaperPart part)
        {
            Mask = mask;
            Rx = regex;
            Sample = sample;
            Part = part;
        }
    }

    public class PaperSeriesAttribute : PaperRuleAttribute
    {
        public PaperSeriesAttribute(string mask, string regex, string sample)
            : base(mask, regex, sample, PaperPart.Series) 
        {
        }
    }

    public class PaperNumberAttribute : PaperRuleAttribute
    {
        public PaperNumberAttribute(string mask, string regex, string sample)
            : base(mask, regex, sample, PaperPart.Number) 
        {
        }
    }
}
