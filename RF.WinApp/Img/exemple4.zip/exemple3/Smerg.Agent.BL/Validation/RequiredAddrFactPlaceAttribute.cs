﻿using System;
using System.ComponentModel.DataAnnotations;
using Safmar.Agent.BL;

namespace Safmar.Agent.BL.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class RequiredAddrFactPlaceAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = validationContext.ObjectInstance as PersonData;
            if (model != null && string.IsNullOrEmpty(model.AddrFactCity) && string.IsNullOrEmpty(model.AddrFactLocality) && string.IsNullOrEmpty(model.AddrFactArea))
            {
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            }
            return ValidationResult.Success;
        }
    }
}
