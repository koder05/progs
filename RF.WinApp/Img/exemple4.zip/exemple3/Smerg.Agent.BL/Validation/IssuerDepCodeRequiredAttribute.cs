﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Smerg.Agent.BL.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class IssuerDepCodeRequiredAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = validationContext.ObjectInstance as PersonData;
            if (model != null && model.PaperType == Paper.PassportRus
                && (value == null || string.IsNullOrEmpty(value.ToString())))
            {
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            }
            return ValidationResult.Success;
        }
    }
}
