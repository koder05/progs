﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.ComponentModel.DataAnnotations;

namespace Smerg.Agent.BL.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class IpaComplexityAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            string ipa = value != null ? Convert.ToString(value) : string.Empty;
            if (SNILSValidate(ipa) == false)
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            return ValidationResult.Success;
        }

        public bool SNILSValidate(String snils)
        {
            Boolean result = false;
            if (new Regex(@"\d{3}-\d{3}-\d{3}\s\d{2}").IsMatch(snils))
            {
                String workSnils = snils.Replace("-", "").Replace(" ", "");
                if (workSnils.Length == 11)
                {
                    var snils9 = workSnils.Substring(0, 9);
                    int snils9Int = 0;
                    if (int.TryParse(snils9, out snils9Int))
                    {
                        if (snils9Int <= 1001998)
                            return true;

                        Int32 controlSum = SNILSContolCalc(snils9);
                        Int32 strControlSum = Int32.Parse(workSnils.Substring(9, 2));
                        if (controlSum == strControlSum)
                        {
                            result = true;
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="workSnils">First 9 digits</param>
        /// <returns></returns>
        private Int32 SNILSContolCalc(String workSnils)
        {
            Int32 totalSum = 0;
            for (Int32 i = workSnils.Length - 1, j = 0; i >= 0; i--, j++)
            {
                Int32 digit = Int32.Parse(workSnils[i].ToString());
                totalSum += digit * (j + 1);
            }

            return SNILSCheckControlSum(totalSum);
        }

        private static Int32 SNILSCheckControlSum(Int32 _controlSum)
        {
            Int32 result;
            if (_controlSum < 100)
            {
                result = _controlSum;
            }
            else if (_controlSum <= 101)
            {
                result = 0;
            }
            else
            {
                Int32 balance = _controlSum % 101;
                result = SNILSCheckControlSum(balance);
            }
            return result;
        }
    }

}
