﻿using System;
using System.ComponentModel.DataAnnotations;
using Safmar.Agent.BL;

namespace Safmar.Agent.BL.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class RequiredAddrRegPlaceAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = validationContext.ObjectInstance as PersonData;
            if (model != null && string.IsNullOrEmpty(model.AddrRegCity) && string.IsNullOrEmpty(model.AddrRegLocality) && string.IsNullOrEmpty(model.AddrRegArea))
            {
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            }
            return ValidationResult.Success;
        }
    }
}
