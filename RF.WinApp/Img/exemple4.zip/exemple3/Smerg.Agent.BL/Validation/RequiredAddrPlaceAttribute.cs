﻿using System;
using System.ComponentModel.DataAnnotations;
using Smerg.Agent.BL;

namespace Smerg.Agent.BL.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class RequiredAddrPlaceAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = validationContext.ObjectInstance as CladrModel;
            if (model != null && string.IsNullOrEmpty(model.City) && string.IsNullOrEmpty(model.Locality) && string.IsNullOrEmpty(model.Area))
            {
                return new ValidationResult(this.FormatErrorMessage(validationContext.DisplayName));
            }
            return ValidationResult.Success;
        }
    }
}
