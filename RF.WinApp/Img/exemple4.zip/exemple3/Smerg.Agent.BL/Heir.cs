﻿using RF.BL.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL
{
    public class Heir : BaseModel
    {
        [Required(ErrorMessage ="Введите Фамилию правопреемника")]
        [RegularExpression("^[А-Яа-я- ]*$", ErrorMessage = "Допускаются русские буквы, пробелы и дефис")]
        public string Lastname { get; set; }

        [Required(ErrorMessage = "Введите Имя правопреемника")]
        [RegularExpression("^[А-Яа-я- ]*$", ErrorMessage = "Допускаются русские буквы, пробелы и дефис")]
        public string Firstname { get; set; }

        [Required(ErrorMessage = "Введите Отчество правопреемника")]
        [RegularExpression("^[А-Яа-я- ]*$", ErrorMessage = "Допускаются русские буквы, пробелы и дефис")]
        public string Middlename { get; set; }

        [Required(ErrorMessage = "Введите дату рождения правопреемника")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? BirthdayDate { get; set; }

        [Required(ErrorMessage = "Введите долю правопреемника")]
        public string part { get; set; }

        //[Required]
        //public Guid PersonData_Id { get; set; }

        [Required]
        public PersonData PersonData { get; set; }
    }
}
