﻿using System;
using System.Text.RegularExpressions;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

using RF.BL.Model;

namespace Smerg.Agent.BL
{
    public class Phone : BaseModel
    {
        [Required]
        public string CountryCode { get; set; } = "7";

        [Required]
        public string CityCode { get; set; }

        [Required]
        public string Number { get; set; }
        public string Ext { get; set; }

        [NotMapped]
        [Required]
        public string FullNumber
        {
            get
            {
                if (string.IsNullOrEmpty(Number))
                    return string.Empty;

                return string.Concat(
                    string.IsNullOrEmpty(CountryCode) ? string.Empty : string.Concat("+", CountryCode)
                    , string.IsNullOrEmpty(CityCode) ? string.Empty : string.Concat("(", CityCode, ")")
                    , FormatNumber(Number)
                    , string.IsNullOrEmpty(Ext) ? "" : string.Concat("#", Ext)
                    );
            }
            set
            {
                if (value != null)
                {
                    var parts = (from Group g in Regex.Match(value.Replace("-", ""), @"^\+(\d+)\((\d{3,7})\)(\d{3,7})?(#\d*)?$").Groups select g.Value).ToArray();
                    if (parts != null && parts.Length == 5)
                    {
                        CountryCode = parts[1];
                        CityCode = parts[2];
                        Number = parts[3];
                        if (!string.IsNullOrEmpty(parts[4]))
                            Ext = parts[4].Replace("#", "");
                        return;
                    }
                }
                Number = string.Empty;
                CityCode = string.Empty;
            }
        }

        public static string FormatNumber(string rawDigits)
        {
            if (string.IsNullOrEmpty(rawDigits))
                return string.Empty;
            var ret = string.Join("-", (from Group g in Regex.Match(rawDigits, @"^(\d{2,3})?(\d{2})?(\d{2})?$").Groups where !string.IsNullOrEmpty(g.Value) select g.Value).Skip(1).ToArray());
            if (string.IsNullOrEmpty(ret))
                return Regex.Replace(rawDigits, @"[^0-9]", "");
            return ret;
        }
    }
}
