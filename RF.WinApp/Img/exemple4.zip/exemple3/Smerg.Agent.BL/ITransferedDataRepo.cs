﻿using System;
using System.Collections.Generic;
using System.Linq;
using RF.LinqExt;
using RestSharp;

namespace Smerg.Agent.BL
{
    public interface ITransferedDataRepo
    {
        int GetListCount(FilterParameterCollection filters);
        IEnumerable<TransferedData> GetList(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
        int GetIndexOf(TransferedData o, FilterParameterCollection filters, SortParameterCollection orderBy);
        TransferedPersonData GetPersonData(string key);
        void UpdatePersonData(TransferedPersonData data);
        Filestore GetListInExcel(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
        Filestore GetPersonInsReport(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
        IRestResponse GetStatusesSupervisorFile(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
        IRestResponse GetStatusesUserFile(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
        IRestResponse GetActsFile(string[] ids);
        IRestResponse PrintReceiptAct(string numberAct);
        IRestResponse GetReceiptActsList(DateTime? dateFrom, DateTime? dateTo);
        IRestResponse GetReceiptActDetails(string numberAct);
    }
}
