﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.Agent.BL
{
    public interface ICladrSeeker
    {
        IEnumerable<CladrModel> FindRegion(string find);
        IEnumerable<CladrModel> FindArea(string find, CladrModel part);
        IEnumerable<CladrModel> FindCity(string find, CladrModel part);
        IEnumerable<CladrModel> FindLocality(string find, CladrModel part);
        IEnumerable<CladrModel> FindStreet(string find, CladrModel part);
        IEnumerable<CladrModel> FindHouse(string find, CladrModel part);
        IEnumerable<CladrModel> FindBuilding(string find, CladrModel part);
        IEnumerable<CladrModel> FindApartmant(string find, CladrModel part);
    }
}
