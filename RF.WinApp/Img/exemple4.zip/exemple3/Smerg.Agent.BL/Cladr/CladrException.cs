﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.Agent.BL
{
    public class CladrException : SvcException
    {
        public CladrException()
        {
        }

        public CladrException(string message)
            : base(message)
        {
        }

        public CladrException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
