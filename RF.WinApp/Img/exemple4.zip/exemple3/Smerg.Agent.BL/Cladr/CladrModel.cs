﻿using RF.BL.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.Agent.BL
{
    public class CladrModel : BaseModel
    {
        [Required(ErrorMessage = "Индекс обязательный")]
        [Display(Name = "Индекс")]
        public string PostCode { get; set; }

        public int RegionCode { get; set; }

        [Required(ErrorMessage = "Введите регион")]
        [Display(Name = "Регион")]
        public string Region { get; set; }

        [Display(Name = "Округ")]
        public string District { get; set; }

        [Display(Name = "Район")]
        public string Area { get; set; }

        [Display(Name = "Город")]
        public string City { get; set; }

        [Display(Name = "Городсткой район")]
        public string CityDistrict { get; set; }

        [Display(Name = "Населенный пункт")]
        public string Locality { get; set; }

        [Required(ErrorMessage = "Введите улицу")]
        [Display(Name = "Улица")]
        public string Street { get; set; }

        [Required(ErrorMessage = "Введите дом")]
        [Display(Name = "Дом")]
        public string House { get; set; }

        [Display(Name = "Тип дома")]
        public string HouseType { get; set; }

        [Display(Name = "Корпус")]
        public string Building { get; set; }

        [Display(Name = "Тип строения")]
        public string BuildingType { get; set; }

        [Display(Name = "Квартира")]
        public string Apartment { get; set; }

        [Display(Name = "Тип помещения")]
        public string ApartmentType { get; set; }


        private string _Presentation;
        [Display(Name = "Адрес строкой")]
        public string Presentation
        {
            get
            {
                if (string.IsNullOrEmpty(_Presentation))
                    _Presentation = ConstructPresentation();
                return _Presentation;
            }
            set
            {
                _Presentation = value;
            }
        }


        [NotMapped]
        public string FullHouse
        {
            get
            {
                return string.Concat(HouseType, House);
            }
        }

        [NotMapped]
        public string FullBuilding
        {
            get
            {
                return string.Concat(BuildingType, Building);
            }
        }

        [NotMapped]
        public string FullApartment
        {
            get
            {
                return string.Concat(ApartmentType, Apartment);
            }
        }

        public void NotifyChanged()
        {
            foreach (var prop in this.GetType().GetProperties())
                OnPropertyChanged(prop.Name);
        }

        private string ConstructPresentation()
        {
            string ret = string.Format("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}"
                , this.PostCode
                , this.Region
                , this.Area
                , this.City
                , this.Locality
                , this.Street
                , this.FullHouse
                , this.FullBuilding
                , this.FullApartment
                );
            return ret.Replace(", , ,", ",").Replace(", ,", ",").Trim(' ',',');
        }
    }
}
