﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL
{
    public interface IPfrDepProv
    {
        string FilePath { get; set; }
        IEnumerable<string> GetRegions();
        IEnumerable<string> GetAreas(string region);
        IEnumerable<PfrDepModel> GetDeps(string region, string area);
        PfrDepModel GetDepartmentByCode(string departmentCode);
    }
}
