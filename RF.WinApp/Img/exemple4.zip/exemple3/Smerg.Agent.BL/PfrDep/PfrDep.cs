﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL
{
    public class PfrDepModel
    {
        public string Region { get; set; }
        public string Area { get; set; }
        public string Dep { get; set; }
        public string DepCode { get; set; }
    }
}
