﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

using RF.BL.Model;
using Smerg.Agent.BL.Validation;
using System.Linq;

namespace Smerg.Agent.BL
{
    public class PersonData : BaseModel
    {
        [Required(ErrorMessage = "Требуется СНИЛС")]
        [IpaComplexity(ErrorMessage = "Неверный СНИЛС")]
        [Display(Name = "СНИЛС")]
        public string IPA { get; set; }

        [Display(Name = "ИНН")]
        public string INN { get; set; }

        [Required(ErrorMessage = "Введите фамилию")]
        [RegularExpression("^[A-Za-zА-Яа-я- ]*$", ErrorMessage = "Допускаются буквы, пробелы и дефис")]
        [Display(Name = "Фамилия")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Введите имя")]
        [RegularExpression("^[A-Za-zА-Яа-я- ]*$", ErrorMessage = "Допускаются буквы, пробелы и дефис")]
        [Display(Name = "Имя")]
        public string FirstName { get; set; }

        [RegularExpression("^[A-Za-zА-Яа-я- ]*$", ErrorMessage = "Допускаются буквы, пробелы и дефис")]
        [Display(Name = "Отчество")]
        public string SecondName { get; set; }

        [Required(ErrorMessage = "Введите фамилию при рождении")]
        [RegularExpression("^[A-Za-zА-Яа-я- ]*$", ErrorMessage = "Допускаются буквы, пробелы и дефис")]
        [Display(Name = "Фамилия")]
        public string BirthLastName { get; set; }

        [Required(ErrorMessage = "Введите имя при рождении")]
        [RegularExpression("^[A-Za-zА-Яа-я- ]*$", ErrorMessage = "Допускаются буквы, пробелы и дефис")]
        [Display(Name = "Имя")]
        public string BirthFirstName { get; set; }

        [RegularExpression("^[A-Za-zА-Яа-я- ]*$", ErrorMessage = "Допускаются буквы, пробелы и дефис")]
        [Display(Name = "Отчество")]
        public string BirthSecondName { get; set; }

        [Required(ErrorMessage = "Введите фамилию, указанную в СНИЛС")]
        [RegularExpression("^[A-Za-zА-Яа-я- ]*$", ErrorMessage = "Допускаются буквы, пробелы и дефис")]
        [Display(Name = "Фамилия")]
        public string LastNameBySnils { get; set; }

        [Required(ErrorMessage = "Введите имя, указанное в СНИЛС")]
        [RegularExpression("^[A-Za-zА-Яа-я- ]*$", ErrorMessage = "Допускаются буквы, пробелы и дефис")]
        [Display(Name = "Имя")]
        public string FirstNameBySnils { get; set; }

        [RegularExpression("^[A-Za-zА-Яа-я- ]*$", ErrorMessage = "Допускаются буквы, пробелы и дефис")]
        [Display(Name = "Отчество")]
        public string MiddleNameBySnils { get; set; }

        private bool _FIOsnilsEqFIODoc = false;
        [Required(ErrorMessage = "*")]
        public bool FIOsnilsEqFIODoc
        {
            get
            {
                return _FIOsnilsEqFIODoc;
            }
            set
            {
                _FIOsnilsEqFIODoc = value;
                if (value)
                    FillSnilsName();
                this.OnPropertyChanged("FIOsnilsEqFIODoc");
            }
        }

        [Required(ErrorMessage = "Введите дату рождения")]
        [Display(Name = "Дата рождения")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? BirthDate { get; set; }

        [Required(ErrorMessage = "Введите место рождения")]
        [Display(Name = "Место рождения")]
        public string BirthPlace { get; set; }

        [EnumRequired(typeof(Gender), (int)Gender.None, ErrorMessage = "Недопустимое значение")]
        [Display(Name = "Пол")]
        public Gender Gender { get; set; }

        [EnumRequired(typeof(Paper), (int)Paper.None, ErrorMessage = "Недопустимое значение")]
        [Display(Name = "Вид документа")]
        public Paper PaperType { get; set; }

        [Required(ErrorMessage = "Введите серию паспорта")]
        [Display(Name = "Серия")]
        [PaperSeriesRestriction]
        public string PaperSer { get; set; }

        [Required(ErrorMessage = "Введите номер паспорта")]
        [Display(Name = "Номер")]
        [PaperNumberRestriction]
        public string PaperNum { get; set; }

        [Required(ErrorMessage = "Введите дату выдачи паспорта")]
        [Display(Name = "Дата выдачи")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? PaperIssueDate { get; set; }

        [Required(ErrorMessage = "Заполните поле Кем выдан")]
        [Display(Name = "Кем выдан")]
        public string PaperIssuer { get; set; }

        //[IssuerDepCodeRequired(ErrorMessage = "Требуется код подразделения")]
        [Required(ErrorMessage = "Введите код подразделения")]
        [Display(Name = "Код подразделения")]
        [PaperIssuerRestriction]
        public string PaperIssuerDepCode { get; set; }

        [Required(ErrorMessage = "Введите мобильный телефон")]
        [Display(Name = "Моб.телефон")]
        public virtual Phone PhoneMobile { get; set; }

        [Display(Name = "Телефон 2")]
        public virtual Phone Phone2 { get; set; }        
        [Display(Name = "Телефон 3")]
        public virtual Phone Phone3 { get; set; }

        [EmailAddress(ErrorMessage = "Неверный формат адреса электропочты")]
        [Display(Name = "Эл.почта")]
        public string Email { get; set; }

        public RegStatus RegStatus { get; set; }

        public RegStatus RegStatusFund { get; set; }

        [RequiredByRegStatus(RegStatus.CodeSendReady, ErrorMessage = "Требуется ввести СМС код")]
        [Display(Name = "Введите СМС-код для проверки")]
        public string RegSmsVerifyCode { get; set; }

        public string RegSessionId { get; set; }

        [RequiredStatementKind(RegStatus.DeclReady, ErrorMessage = "Требуется вид заявления")]
        [Display(Name = "Вид заявления")]
        public StatementKind RegStatementKind { get; set; } = StatementKind.Undefined;

        [RequiredByRegStatus(RegStatus.DeclReady, ErrorMessage = "Требуется код отделения ПФР")]
        [Required(ErrorMessage = "Требуется Код отделения ПФР")]
        //[RequiredByRegStatus(RegStatus.DeclReady, ErrorMessage = "Требуется код отделения ПФР")]
        [Display(Name = "Код отделения ПФР")]
        public string RegPFRDepartmentCode { get; set; }

        [NotMapped]
        public PfrDepModel RegPFRDepartment { get; set; }
        public string NpfClientId { get; set; }
        public string NpfAgreementId { get; set; }

        [Display(Name = "Пенс.накопления")]        
        public decimal? AccountAmount { get; set; }
        public bool IsAccountAmountSent { get; set; }

        [Display(Name = "Кодовое слово")]
        public string CodeWord  { get; set; }

        [Required(ErrorMessage = "Требуется вид заявления")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Display(Name = "Дата договора")]
        public DateTime AgreementDate { get; set; } = DateTime.Now;

        [Required]
        public virtual CladrModel AddrReg { get; set; }

        [Required]
        public virtual CladrModel AddrFact { get; set; }

        [Display(Name = "Наличие двойного гражданства")]
        public virtual OksmCountry ForeignCountryCitizenship { get; set; }
        [Display(Name = "Является ли иностранным налогоплательщиком")]
        public virtual OksmCountry ForeignCountryTaxpayer { get; set; }
        [Display(Name = "Наличие вида на жительство в иностранном государстве")]
        public virtual OksmCountry ForeignCountryResidence { get; set; }
        [Display(Name = "Распространяется ли законодательство иностранного государства о налогообложении иностранных счетов")]
        public virtual OksmCountry ForeignCountryAccounts { get; set; }

        public virtual ICollection<Filestore> Files { get; set; }

        public virtual ICollection<Heir> Heirs { get; set; }

        [Display(Name = "Время начала обзвона")]
        [DisplayFormat(DataFormatString = "{0:H:mm}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Time)]
        public DateTime? EstimatedCallTimeFrom { get; set; }

        [Display(Name = "Время конца обзвона")]
        [DisplayFormat(DataFormatString = "{0:H:mm}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Time)]
        public DateTime? EstimatedCallTimeTo { get; set; }

        [Required]
        [Display(Name = "Способ привлечения")]
        public string SaleChannel { get; set; }

        [Display(Name = "ФИО на английском языке")]
        public string USAFIO { get; set; }
        public string SSN { get; set; }
        public string TIN { get; set; }

        [Display(Name = "Является резидентом США")]
        public bool IsUSATaxpayer { get; set; }
        public string PrevNpf { get; set; }
        public bool IsPrevNpfSent { get; set; }

        [NotMapped]
        public string BirthFullName
        {
            get
            {
                return string.Format("{0} {1} {2}", this.BirthLastName, this.BirthFirstName, this.BirthSecondName).Trim();
            }
        }

        [NotMapped]
        public string PaperFullName
        {
            get
            {
                return string.Format("{0}{1}", this.PaperSer, this.PaperNum).Trim();
            }
        }

        [NotMapped]
        public List<string> SaleChanelList { get; set; }

        [NotMapped]
        public string UID
        {
            get
            {
                return Id.ToString().Replace("-","").ToUpper();
            }
        }

        [NotMapped]
        public bool IsSendFileUC
        {
            get
            {
                if (Files != null)
                {
                    var vcFiles = new FileСlarification[] { FileСlarification.PfrCertDecl, FileСlarification.PfrProcuratory, FileСlarification.PfrCert, FileСlarification.Passport };
                    return (vcFiles.Intersect(Files.Where(f => f.Status == FileStatus.Sent).Select(f => f.Сlarification).Distinct()).Count() == vcFiles.Length);
                }
                return false;
            }
        }

        [NotMapped]
        public bool IsSendFileBO
        {
            get
            {
                if (Files != null)
                {
                    var vcFiles = new FileСlarification[] { FileСlarification.ContractOps, FileСlarification.PassportOnContractOps, FileСlarification.ClientCard, FileСlarification.SNILS, FileСlarification.Consent };
                    return (vcFiles.Intersect(Files.Where(f => f.Status == FileStatus.Sent).Select(f => f.Сlarification)).Count() == vcFiles.Length);
                }
                return false;
            }
        }

        [NotMapped]
        public bool IsComplieteNPF
        {
            get
            {
                if (Files != null)
                {
                    return Files.Any(f => f.Сlarification == FileСlarification.PassportOnContractOps && f.Status == FileStatus.Sent);
                }
                return false;
            }
        }

        [NotMapped]
        public bool IsExistFilePfrrfReceipt
        {
            get
            {
                if (Files != null)
                {
                    return Files.Any(f => f.Сlarification == FileСlarification.PFRF_RECEIPT);
                }
                return false;
            }
        }

        [NotMapped]
        public bool IsExistFileAccountStateInformation
        {
            get
            {
                if (Files != null)
                {
                    return Files.Any(f => f.Сlarification == FileСlarification.ACCOUNT_STATE_INFORMATION);
                }
                return false;
            }
        }

        [NotMapped]
        public bool IsExistFileStatementXml
        {
            get
            {
                if (Files != null)
                {
                    return Files.Any(f => f.Сlarification == FileСlarification.Unknown && f.FileName == "Statement.pdf");
                }
                return false;
            }
        }

        [NotMapped]
        public bool IsExistFileStatementPdf
        {
            get
            {
                if (Files != null)
                {
                    return Files.Any(f => f.Сlarification == FileСlarification.Unknown && f.FileName == "Statement.xml");
                }
                return false;
            }
        }

        [NotMapped]
        public bool IsEqualBirthFIO
        {
            get
            {
                return (!string.IsNullOrEmpty(FirstName) && string.Equals(FirstName, BirthFirstName))
                    && (!string.IsNullOrEmpty(LastName) && string.Equals(LastName, BirthLastName))
                    && (!string.IsNullOrEmpty(SecondName) && string.Equals(SecondName, BirthSecondName));
            }
                }

        public void FillBirthName()
        {
            this.BirthFirstName = this.FirstName;
            this.BirthLastName = this.LastName;
            this.BirthSecondName = this.SecondName;
            this.OnPropertyChanged("BirthFirstName");
            this.OnPropertyChanged("BirthLastName");
            this.OnPropertyChanged("BirthSecondName");
        }

        public void FillSnilsName()
        {
            this.FirstNameBySnils = this.FirstName;
            this.LastNameBySnils = this.LastName;
            this.MiddleNameBySnils = this.SecondName;
            this.OnPropertyChanged("FirstNameBySnils");
            this.OnPropertyChanged("LastNameBySnils");
            this.OnPropertyChanged("MiddleNameBySnils");
        }

        public void DetectGender()
        {
            if (this.Gender == Gender.None && string.IsNullOrEmpty(this.SecondName) == false)
            {
                Gender newg = Gender.None;
                if (this.SecondName.EndsWith("ич", StringComparison.InvariantCultureIgnoreCase))
                    newg = Gender.Male;
                if (this.SecondName.EndsWith("на", StringComparison.InvariantCultureIgnoreCase))
                    newg = Gender.Famale;
                if (newg != this.Gender)
                {
                    this.Gender = newg;
                    this.OnPropertyChanged("Gender");
                }
            }
        }

        public void CopyAddr()
        {
            var a = this.AddrReg.ShallowCopy() as CladrModel;
            a.Id = Guid.NewGuid();
            this.AddrFact = a;

            //this.AddrFact.PostCode = this.AddrReg.PostCode;
            //this.AddrFact.Region = this.AddrReg.Region;
            //this.AddrFact.Area = this.AddrReg.Area;
            //this.AddrFact.City = this.AddrReg.City;
            //this.AddrFact.Locality = this.AddrReg.Locality;
            //this.AddrFact.Street = this.AddrReg.Street;
            //this.AddrFact.House = this.AddrReg.House;
            //this.AddrFact.Building = this.AddrReg.Building;
            //this.AddrFact.Apartment = this.AddrReg.Apartment;
            this.AddrFact.NotifyChanged();
            this.OnPropertyChanged("AddrFact");
        }

        public void FilesChanged()
        {
            this.OnPropertyChanged("Files");
        }

        public void HeirsChanged()
        {
            this.OnPropertyChanged("Heirs");
        }
    }
}
