﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL.Auth
{
    public interface IAuthBehavior
    {
        Credentials GetCredentials();
        string GetToken(string realm);
    }
}
