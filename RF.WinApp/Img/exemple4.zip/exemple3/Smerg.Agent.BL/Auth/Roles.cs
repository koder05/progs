﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL.Auth
{
    public static class Roles
    {
        public const string User = "user";
        public const string Supervisor = "superuser";
    }
}
