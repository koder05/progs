﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL.Auth
{
    public class Credentials
    {
        private int _expiredInSec = 30;

        private DateTime _d = DateTime.Now;
        public string Login { get; set; }
        public string Psw { get; set; }
        public string SmsCode { get; set; }

        public bool IsExpired
        {
            get
            {
                return _d.AddSeconds(_expiredInSec) <= DateTime.Now;
            }
        }

        public void ForceExpired()
        {
            _d = DateTime.MinValue;
        }
    }
}
