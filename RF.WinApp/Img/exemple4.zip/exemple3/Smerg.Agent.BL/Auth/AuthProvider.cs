﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL.Auth
{
    public static class AuthProvider
    {
        private static readonly object sync = new object();
        public static IAuthBehavior _behavior;
        public static IAuthBehavior Behavior
        {
            get
            {
                if (_behavior == null)
                    throw new InvalidOperationException("Не задан сервис авторизации.");
                return _behavior;
            }
            set
            {
                lock (sync)
                {
                    _behavior = value;
                }
            }
        }

    }
}
