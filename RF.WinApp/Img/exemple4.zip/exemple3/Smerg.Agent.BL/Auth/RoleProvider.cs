﻿using System;
using System.Collections.Generic;
using System.Linq;
using RF.Common;

namespace Smerg.Agent.BL.Auth
{
    public static class RoleProvider
    {
        private static readonly object sync = new object();
        private static IMembership _membership;

        public static void Init(IMembership membership)
        {
            lock (sync)
                _membership = membership;
        }

        public static bool IsInRole(string role)
        {
            if (_membership == null)
                throw new RFAppException("Не задан ролевой сервис авторизации.");
            return _membership.IsInRole(role);
        }

        public static IEnumerable<string> Roles
        {
            get
            {
                if (_membership == null)
                    throw new RFAppException("Не задан ролевой сервис авторизации.");
                return _membership.Roles;
            }
        }
    }
}
