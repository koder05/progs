﻿using System;
using System.Collections.Generic;
using System.Linq;
using RF.LinqExt;

namespace Smerg.Agent.BL
{
    public interface IPersonDataRepo
    {
        PersonData New();
        object Create(PersonData o);
        void Delete(PersonData o);
        void Update(PersonData o);
        PersonData GetById(Guid id);
        int GetListCount(FilterParameterCollection filters);
        IEnumerable<PersonData> GetList(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
        int GetIndexOf(PersonData o, FilterParameterCollection filters, SortParameterCollection orderBy);
        void AddFile(Filestore file);
        void RemoveFile(Filestore file);
        void AddHeir(Heir h);
        void RemoveHeir(Heir hier);
        IEnumerable<Heir> GetHeirsByPersonID(Guid persinID);
    }
}
