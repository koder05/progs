﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace Smerg.Agent.BL
{
    public interface IStatementProvider
    {
        string SendDeclaration(PersonData data, IList<Filestore> docBlanks);
        void DeleteDeclaration(PersonData data);
        RegStatus SendScans(PersonData data);
        RegStatus ConfirmSMS(PersonData data);
        RegStatus ConfirmDeclaration(PersonData data);
        RegStatus AskStatus(PersonData data);
        void RepeatSMS(PersonData data);
        Filestore GetVCReport(List<PersonData> sessList);
    }
}
