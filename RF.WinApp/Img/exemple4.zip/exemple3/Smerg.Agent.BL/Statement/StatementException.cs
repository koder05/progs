﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.Agent.BL
{
    public class StatementException : SvcException
    {
        public string Kind { get; set; }

        public StatementException()
        {
        }

        public StatementException(string message)
            : base(message)
        {
        }

        public StatementException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
