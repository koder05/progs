﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL
{
    public class SvcException : Exception
    {
        public bool IsAlert { get; set; }

        public SvcException()
        {
        }

        public SvcException(string message)
            : base(message)
        {
        }

        public SvcException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
