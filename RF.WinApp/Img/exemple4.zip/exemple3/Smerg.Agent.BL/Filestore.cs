﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RF.BL.Model;

namespace Smerg.Agent.BL
{
    public class Filestore : BaseModel
    {
        [MaxLength]
        [Column(TypeName="image")]
        [Display(Name = "Файл")]
        public byte[] Body { get; set; }

        [Required]
        public PersonData Person { get; set; }

        [Required]
        public string FileName { get; set; }

        [Required]
        public DateTime UploadDate { get; set; } = DateTime.Now;

        public FileStatus Status { get; set; } = FileStatus.None;

        [Required]
        [Display(Name = "Тип файла")]
        public FileСlarification Сlarification { get; set; }

    }
}
