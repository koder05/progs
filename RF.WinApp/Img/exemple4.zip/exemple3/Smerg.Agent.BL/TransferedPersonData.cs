﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL
{
    [NotMapped]
    public class TransferedPersonData
    {
        public string Id { get; set; }
        public PersonData Person { get; set; }
        public bool IPAIsEnable  { get; set; }
        public bool LastNameIsEnable  { get; set; }
        public bool FirstNameIsEnable  { get; set; }
        public bool SecondNameIsEnable  { get; set; }
        public bool LastNameBySnilsIsEnable { get; set; }
        public bool FirstNameBySnilsIsEnable { get; set; }
        public bool MiddleNameBySnilsIsEnable { get; set; }
        public bool BirthDateIsEnable  { get; set; }
        public bool GenderIsEnable  { get; set; }
        public bool PaperSerIsEnable  { get; set; }
        public bool PaperNumIsEnable  { get; set; }
        public bool PaperIssueDateIsEnable  { get; set; }
        public bool PaperIssuerIsEnable  { get; set; }
        public bool PaperIssuerCodeIsEnable { get; set; }

        public bool IsSummaryEnable
        {
            get
            {
                return IPAIsEnable || LastNameIsEnable || FirstNameIsEnable || SecondNameIsEnable || LastNameBySnilsIsEnable || FirstNameBySnilsIsEnable
                    || MiddleNameBySnilsIsEnable || BirthDateIsEnable || GenderIsEnable || PaperSerIsEnable || PaperNumIsEnable || PaperIssueDateIsEnable || PaperIssuerIsEnable;
            }
        }
    }
}
