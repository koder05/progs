﻿using System;
using System.Collections.Generic;
using System.Linq;
using Smerg.Agent.BL.Auth;

namespace Smerg.Agent.BL.Thirdpart
{
    public class ThirdpartInfo
    {
        public Uri SvcRealm { get; set; }
        public Credentials Credentials { get; set; }
        public object SvcSpecifiedInfo { get; set; }
    }
}
