﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL.Thirdpart
{
    public interface IThirdpartInfoProvider
    {
        ThirdpartInfo GetInfo(SupportedSvc svcId);
    }
}
