﻿using System;
using System.Collections.Generic;
using System.Linq;
using RF.BL.Model;
using System.ComponentModel.DataAnnotations.Schema;

namespace Smerg.Agent.BL
{
    [NotMapped]
    public class TransferedData
    {
        public string Id { get; set; }
        public List<TransferStatus> Statuses { get; set; }
        public List<TransferCheckResult> PersonData { get; set; }
    }

    [NotMapped]
    public class TransferStatus
    {
        public string CheckName { get; set; }
        public IEnumerable<TransferCheckResult> CheckResults { get; set; }
    }

    [NotMapped]
    public class TransferCheckResult
    {
        public string Field { get; set; }
        public string Value { get; set; }
    }
}
