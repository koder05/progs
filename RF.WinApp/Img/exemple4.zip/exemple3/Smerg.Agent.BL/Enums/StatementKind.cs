﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Smerg.Agent.BL
{
    public enum StatementKind
    {
        [Description("Неизвестно"), Display(Name = "Неизвестно")]
        Undefined = 16,
        [Description("Переход из ПФР в НПФ"), Display(Name = "Переход из ПФР в НПФ")]
        PFR2NPF = 1,
        [Description("Переход из НПФ в НПФ"), Display(Name = "Переход из НПФ в НПФ")]
        NPF2NPF = 2,
        PFR2NPF4Chipped = 4,
        NPF2NPF4Chipped = 8
    }

    public class StatementKindComparer : IComparer<StatementKind>
    {
        public int Compare(StatementKind a, StatementKind b)
        {
            if (a == b)
                return 0;
            if (a == StatementKind.Undefined)
                return -1;
            if (b == StatementKind.Undefined)
                return 1;
            if (a < b)
                return -1;
            return 1;
        }
    }
}
