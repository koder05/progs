﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Smerg.Agent.BL
{
    public enum Gender
    {
        [Description("-------"), Display(Name = "-------")]
        None = 0,
        [Description("Мужской"), Display(Name = "Мужской")]
        Male = 1,
        [Description("Женский"), Display(Name = "Женский")]
        Famale = 2
    }
}
