﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Smerg.Agent.BL
{
    public enum Paper
    {
        [Description("-------"), Display(Name = "-------")]
        None = 0,

        [Description("Паспорт СССР"), Display(Name = "Паспорт СССР")]
        PassportUSSR = 1,

        [Description("Свид. о рожд."), Display(Name = "Свид. о рожд.")]
        [PaperSeries("", "[IVX]{1,4}-[А-Я]{2}", "XVI-ИЯ")]
        [PaperNumber("000000", @"\d{6}", "123456")]
        BirthCert = 3,

        [Description("Паспорт иностранного гражданина"), Display(Name = "Паспорт иностранного гражданина")]
        PassportForeign = 10,

        [Description("Вид на жительство"), Display(Name = "Вид на жительство")]
        ResidencePermitRus = 12,

        [Description("Разрешение на врем. проживание"), Display(Name = "Разрешение на врем. проживание")]
        TempResidencePermitRus = 15,

        [Description("Паспорт РФ"), Display(Name = "Паспорт РФ")]
        [PaperSeries("00 00", @"\d{2} \d{2}", "12 34")]
        [PaperNumber("000000", @"\d{6}", "123456")]
        [PaperRule("000-000", @"\d{3}-\d{3}", "123-456", PaperPart.IssuerCode)]
        PassportRus = 21
    }

    public enum PaperPart
    {
        Series,
        Number,
        IssuerCode
    }

    public class PaperComparer : IComparer<Paper>
    {
        public int Compare(Paper a, Paper b)
        {
            if (a == b)
                return 0;
            if (a == Paper.None)
                return -1;
            if (b == Paper.None)
                return 1;
            if (a == Paper.PassportRus)
                return -1;
            if (b == Paper.PassportRus)
                return 1;
            if (a < b)
                return -1;
            return 1;
        }
    }
}
