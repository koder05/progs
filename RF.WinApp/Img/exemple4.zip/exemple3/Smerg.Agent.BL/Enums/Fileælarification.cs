﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Smerg.Agent.BL
{
    public enum FileСlarification
    {
        [Display(Name = "Общий"), Description("Общий")]
        Unknown = 0,
        [Display(Name = "Бланк заявления"), Description("Бланк заявления")]
        PfrDeclarationForm = 1,
        [Display(Name = "Бланк доверенности"), Description("Бланк доверенности")]
        PfrProcuratoryForm = 2,
        [Display(Name = "Бланк сертификата УЦ"), Description("Бланк сертификата УЦ")]
        PfrCertForm = 3,
        [Display(Name = "Бланк заявления на сертификат УЦ"), Description("Бланк заявления на сертификат УЦ")]
        PfrCertDeclForm = 4,
        [Display(Name = "Заявление"), Description("Заявление")]
        PfrDeclaration = 5,
        [Display(Name = "Доверенность УЦ"), Description("Доверенность УЦ")]
        PfrProcuratory = 6,
        [Display(Name = "Сертификат УЦ"), Description("Сертификат УЦ")]
        PfrCert = 7,
        [Display(Name = "Заявление на создание КСКП ЭП"), Description("Заявление на создание КСКП ЭП")]
        PfrCertDecl = 8,
        [Display(Name = "Паспорт"), Description("Паспорт")]
        Passport = 9,
        [Display(Name = "Паспорт прописка"), Description("Паспорт прописка")]
        PassportAddr = 10,
        [Display(Name = "Паспорт на фоне анкеты"), Description("Паспорт на фоне анкеты")]
        PassportOnForm = 11,
        [Display(Name = "Паспорт на фоне согласия"), Description("Паспорт на фоне согласия")]
        PassportOnConsent = 12,
        [Display(Name = "Страховое свидетельство"), Description("Страховое свидетельство")]
        SNILS = 13,
        [Display(Name = "Договор ОПС"), Description("Договор ОПС")]
        ContractOps = 14,
        [Display(Name = "Согласие на обработку перс. данных"), Description("Согласие на обработку перс. данных")]
        Consent = 15,
        [Display(Name = "Фотография клиента"), Description("Фотография клиента")]
        Photo = 16,
        [Display(Name = "Копия квитанции о регистрации заявления ЗЛ"), Description("Копия квитанции о регистрации заявления ЗЛ")]
        Receipt = 17,
        [Display(Name = "Копия карточки клиента"), Description("Копия карточки клиента")]
        ClientCard = 18,
        [Display(Name = "Паспорт на фоне договора ОПС"), Description("Паспорт на фоне договора ОПС")]
        PassportOnContractOps = 19,
        [Display(Name = "Копия расписки ПФР о приеме заявления"), Description("Копия расписки ПФР о приеме заявления")]
        PFRF_RECEIPT = 21,
        [Display(Name = "Копия Выписка СЗИ6"), Description("Копия Выписка СЗИ6")]
        ACCOUNT_STATE_INFORMATION = 22
    }

    /// <summary>
    /// Пустографы
    /// </summary>
    public enum RawDataForms
    {
        PfrCertRaw = FileСlarification.PfrCert,
        ContractOpsRaw = FileСlarification.ContractOps,
        PfrDeclarationRaw = FileСlarification.PfrDeclaration,
        PfrProcuratoryRaw = FileСlarification.PfrProcuratory,
        ConsentRaw = FileСlarification.Consent,
        ClientCardRaw = FileСlarification.ClientCard
    }

    public enum PrintForms
    {
        VCCert = FileСlarification.PfrCert,
        VCDeclaration = FileСlarification.PfrDeclaration,
        VCProcuratory = FileСlarification.PfrProcuratory,
        ContractOps = FileСlarification.ContractOps,
        Consent = FileСlarification.Consent,
        ClientCard = FileСlarification.ClientCard
    }
}
