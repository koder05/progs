﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL
{
    public enum CladrPart
    {
        Unknown,
        Region,
        Area,
        City,
        Locality,
        Street,
        House,
        Building
    }
}
