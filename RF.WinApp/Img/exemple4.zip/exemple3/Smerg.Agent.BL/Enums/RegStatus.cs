﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Smerg.Agent.BL
{
    public enum RegStatus
    {
        [Description("Нет")]
        None = 0,
        [Description("Подача заявления")]
        DeclReady = 1,
        [Description("Заявление подано")]
        DeclSent = 2,
        [Description("Документы переданы")]
        DocsSent = 3,
        [Description("Выслано СМС")]
        SmsRecived = 4,
        [Description("Подтверждение СМС кода")]
        CodeSendReady = 5,
        [Description("СМС код передан")]
        CodeSent = 6,
        [Description("Ожидается завершение регистрации")]
        RegReady = 7,
        [Description("Отправлено на регистрацию")]
        RegConfirmed = 8,
        [Description("Регистрация завершена")]
        RegComplete = 9,
        [Description("Персданные переданы в НПФ")]
        NpfSent = 10,
        [Description("Передача в НПФ завершена")]
        NpfComplete = 11
    }
}
