﻿using System;
using System.Collections.Generic;
using System.Linq;
using RF.LinqExt;

namespace smerg.Agent.BL
{
    public interface ITransferedDataRepo
    {
        int GetListCount(FilterParameterCollection filters);
        IEnumerable<TransferedData> GetList(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
        int GetIndexOf(TransferedData o, FilterParameterCollection filters, SortParameterCollection orderBy);
        TransferedPersonData GetPersonData(string key);
        void UpdatePersonData(TransferedPersonData data);
        Filestore GetListInExcel(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
        Filestore GetPersonInsReport(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
    }
}
