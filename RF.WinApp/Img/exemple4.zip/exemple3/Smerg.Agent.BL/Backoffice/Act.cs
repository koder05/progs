﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations.Schema;

namespace Smerg.Agent.BL.Acts
{
    [NotMapped]
    public class Act
    {
        public string Code { get; set; }
        public DateTime Date { get; set; }
        public string User { get; set; }
        public int AgreeCount { get; set; }
        public ICollection<Agree> AgreeList { get; set; }
    }

    [NotMapped]
    public class Agree
    {
        public string Code { get; set; }
        public DateTime Date { get; set; }
        public string IPA { get; set; }
        public ICollection<File> Files { get; set; }
    }

    [NotMapped]
    public class File
    {
        public string Type { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }
        public string Comment { get; set; }
    }
}
