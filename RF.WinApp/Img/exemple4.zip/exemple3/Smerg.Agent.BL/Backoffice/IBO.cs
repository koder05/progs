﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Smerg.Agent.BL
{
    public interface IBO
    {
        void CheckPersonData(PersonData pd);
        void CheckIPADouble(string ipa);
        string PostPersonData(PersonData pd);
        void PostPersonDocs(PersonData pd);
        IEnumerable<OksmCountry> FindOksmCountry(string find);
        IEnumerable<FileСlarification> FileСlarifications4Upload { get; }
        IEnumerable<string> GetAgreeSources();
        void PostPN(PersonData pd);
        void PostPrevNpf(PersonData pd);
        Stream GetPrintFormAct(string numberAct);
    }
}
