﻿using System;
using System.Collections.Generic;
using System.Linq;
using RF.LinqExt;

namespace Smerg.Agent.BL.Acts
{
    public interface IActRepo
    {
        Act Create(Act act);
        int GetListCount(FilterParameterCollection filters);
        IEnumerable<Act> GetList(FilterParameterCollection filters, int startRowIndex, int maximumRows, SortParameterCollection orderBy);
        int GetIndexOf(Act a, FilterParameterCollection filters, SortParameterCollection orderBy);
        Act GetDetails(Act act);
        Filestore GetActPrintForm(Act act);
    }
}
