﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smerg.Agent.BL
{
    public class BOException : SvcException
    {
        public BOException()
        {
        }

        public BOException(string message)
            : base(message)
        {
        }

        public BOException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
