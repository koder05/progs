﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Smerg.Agent.PrintForms
{
    public class MultipagePrintForm
    {
        public List<IPrintForm> Pages { get; private set; } = new List<IPrintForm>();

        public MultipagePrintForm(params IPrintForm[] forms)
        {
            Pages.AddRange(forms);
        }

        public void Concat(MultipagePrintForm extForm)
        {
            Pages.AddRange(extForm.Pages);
        }
    }
}
