﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Smerg.Agent.PrintForms
{
    public interface IPrintForm
    {
        Image Draw();
    }
}
