﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;

namespace Smerg.Agent.PrintForms
{
    public class ImgWrapper : IPrintForm
    {
        private Image _img;

        public ImgWrapper(Image img)
        {
            _img = img;
        }

        public ImgWrapper(byte[] img)
        {
            using (var s = new MemoryStream(img))
                _img = Image.FromStream(s);
        }

        public Image Draw()
        {
            return _img;
        }
    }
}
