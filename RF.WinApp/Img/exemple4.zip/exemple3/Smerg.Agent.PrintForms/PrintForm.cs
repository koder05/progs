﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;


namespace Smerg.Agent.PrintForms
{
    public abstract class PrintForm : IPrintForm
    {
        private string _blankResourcePath;
        private string _formName;
        private bool _rawDataOnly;
        private Image img;
        private Graphics canvas;

        public PrintForm(string blankResourcePath, string formName, bool rawDataOnly)
        {
            _blankResourcePath = blankResourcePath;
            _formName = formName;
            _rawDataOnly = rawDataOnly;
        }

        protected abstract void DrawForm();

        public Image Draw()
        {
            img = GetImageFromResources();
            canvas = Graphics.FromImage(img);
            if (_rawDataOnly)
                canvas.Clear(Color.White);
            DrawForm();
            return img;
        }

        protected Image GetImageFromResources()
        {
            var asm = Assembly.GetAssembly(this.GetType());
            var resourcePath = string.Concat(asm.GetName().Name, ".", _blankResourcePath);
            using (var imgBody = asm.GetManifestResourceStream(resourcePath))
                return Image.FromStream(imgBody);
        }

        protected byte[] ToByteArray()
        {
            using (var ms = new MemoryStream())
            {
                img.Save(ms, img.RawFormat);
                return ms.ToArray();
            }
        }

        protected void Text(string text, Font textFont
                    , float x, float y, float w, float h
                    , bool tryFit = true, bool tryWrap = true, StringFormat sf = null)
        {
            RectangleF textPlaceHolder = new RectangleF(x, y, w, h);

            if (sf == null)
            {
                var sfo = StringFormatFlags.FitBlackBox;

                if (!tryWrap)
                    sfo |= StringFormatFlags.NoWrap;

                sf = new StringFormat(sfo);
                sf.LineAlignment = StringAlignment.Far;
            }

            if (tryFit && !string.IsNullOrEmpty(text))
            {
                while (textFont.Size > 5 && !TextFitting(canvas, text, textFont, textPlaceHolder.Size, sf))
                {
                    textFont = new Font(textFont.FontFamily, textFont.Size - 1, textFont.Style, textFont.Unit);
                }
            }

            canvas.DrawString(text, textFont, Brushes.Black, textPlaceHolder, sf);
        }

        private bool TextFitting(Graphics canvas, string text, Font textFont, SizeF textPlaceHolder, StringFormat sf)
        {
            int charactersFitted;
            int linesFilled;

            var widthNotFit = canvas.MeasureString(text, textFont, textPlaceHolder, sf, out charactersFitted, out linesFilled).Width >= textPlaceHolder.Width
                || charactersFitted < text.Length;

            if (widthNotFit)
                return false;

            var heightNotFit = canvas.MeasureString(text, textFont, textPlaceHolder, sf, out charactersFitted, out linesFilled).Height >= textPlaceHolder.Height
                || charactersFitted < text.Length;

            return !heightNotFit;
        }
    }
}
