﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Documents;

using RF.WinApp;
using RF.LinqExt;
using Smerg.Agent.BL;
using RF.Common;

namespace Smerg.Agent.Data
{
    public class PersonDataViewProvider : IDataView
    {
        private IPersonDataRepo _rep;
        private IStatementProvider _regRepo;
        private IPfrDepProv _pfrDep;
        private Action<SvcException> _fallback;
        private IPrintFormProv[] _printFormProviders;

        public ICladrSeeker CladrSeekerRepo { get; private set; }
        public IBO BackofficeRepo { get; private set; }

        internal void SetFallback(Action<SvcException> foo)
        {
            _fallback = foo;
        }

        public PersonDataViewProvider(IPersonDataRepo rep, IStatementProvider regRepo, ICladrSeeker cladr, IPfrDepProv pfr, IBO bo, IPrintFormProv[] raw)
        {
            _rep = rep;
            _regRepo = regRepo;
            CladrSeekerRepo = cladr;
            _pfrDep = pfr;
            _printFormProviders = raw;
            BackofficeRepo = bo;
        }

        public Type ModelType
        {
            get
            {
                return typeof(PersonData);
            }
        }

        public object ActivateEmptyModel()
        {
            var m = _rep.New();
            return m;
        }

        public void Create(object o)
        {
            _rep.Create(o as PersonData);
            try
            {
                BackofficeRepo.CheckPersonData(o as PersonData);
            }
            catch (BOException ex)
            {
                _fallback(ex);
            }
            catch (Exception ex)
            {
                _fallback(new BOException(ex.Message));
            }
        }

        public void Delete(IEnumerable<object> pool)
        {
            foreach (var o in pool.Cast<PersonData>())
                _rep.Delete(o);
        }

        public int GetIndexOf(object o, FilterParameterCollection filters, SortParameterCollection orderBy)
        {
            return _rep.GetIndexOf((PersonData)o, filters, orderBy);
        }

        public IEnumerable<object> GetList(FilterParameterCollection filters, int pageIndex, int pageSize, SortParameterCollection orderBy)
        {
            return _rep.GetList(filters, pageIndex, pageSize, orderBy).Cast<object>().ToList();
        }

        public int GetListCount(FilterParameterCollection filters)
        {
            return _rep.GetListCount(filters);
        }

        public void Update(object o)
        {
            _rep.Update(o as PersonData);
            try
            {
                BackofficeRepo.CheckPersonData(o as PersonData);
            }
            catch (BOException ex)
            {
                _fallback(ex);
            }
            catch (Exception ex)
            {
                _fallback(new BOException(ex.Message));
            }
        }

        public void AddFile(Filestore file)
        {
            _rep.AddFile(file);
        }

        public void RemoveFile(Filestore file)
        {
            _rep.RemoveFile(file);
        }

        public IEnumerable<FileСlarification> FileСlarifications4Upload
        {
            get
            {
                return BackofficeRepo.FileСlarifications4Upload;
            }
        }

        public void CheckIPA(string ipa)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        BackofficeRepo.CheckIPADouble(ipa);
                    }
                    catch (BOException ex)
                    {
                        _fallback(ex);
                    }
                }
                ,
                () => { }
            );
        }

        public void RegProcessBegin(PersonData m, Action<PersonData> callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    var pool = new List<Filestore>();
                    try
                    {
                        var sessid = _regRepo.SendDeclaration(m, pool);
                        if (string.IsNullOrEmpty(sessid) == false)
                        {
                            m.RegStatus = RegStatus.DeclSent;
                            m.RegSessionId = sessid;
                            foreach (var f in pool)
                                m.Files.Add(f);
                            //m.RegStatus = RegStatus.DocsSent;
                        }
                    }
                    catch (StatementException ex)
                    {
                        _fallback(ex);
                    }
                }
                ,
                () =>
                {
                    Action foo = () => { _rep.Update(m); callback(m); };
                    this.RegProcessCompleteAsk(m, (pd) => foo(), (ex) => foo());
                }
            );
        }

        public void RegProcessReset(PersonData m, Action<PersonData> callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        _regRepo.DeleteDeclaration(m);
                    }
                    catch (StatementException ex)
                    {
                        _fallback(ex);
                    }

                    foreach (var file in m.Files.Where(f => f.Сlarification > FileСlarification.Unknown && f.Сlarification < FileСlarification.Passport).ToList())
                    {
                        RemoveFile(file);
                    }
                    m.RegStatus = RegStatus.None;
                    m.RegSmsVerifyCode = null;
                    m.RegSessionId = null;
                }
                ,
                () =>
                {
                    _rep.Update(m);
                    callback(m);
                }
            );
        }

        public void RegProcessDocSend(PersonData m, Action<PersonData> callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        m.RegStatus = _regRepo.SendScans(m);
                    }
                    catch (StatementException ex)
                    {
                        _rep.Update(m);
                        _fallback(ex);
                    }
                }
                ,
                () =>
                {
                    _rep.Update(m);
                    callback(m);
                }
            );
        }

        public void RegProcessSmsSend(PersonData m, Action<PersonData> callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        m.RegStatus = _regRepo.ConfirmSMS(m);
                    }
                    catch (StatementException ex)
                    {
                        _fallback(ex);
                    }
                }
                ,
                () =>
                {
                    _rep.Update(m);
                    callback(m);
                }
            );
        }

        public void RegProcessSmsRepeat(PersonData m, Action callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        _regRepo.RepeatSMS(m);
                    }
                    catch (StatementException ex)
                    {
                        _fallback(ex);
                    }
                }
                ,
                () =>
                {
                    callback();
                }
            );
        }

        public void RegProcessCompleteAsk(PersonData m, Action<PersonData> callback)
        {
            RegProcessCompleteAsk(m, callback, _fallback);
        }

        public void RegProcessCompleteAsk(PersonData m, Action<PersonData> callback, Action<StatementException> fallback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        m.RegStatus = _regRepo.AskStatus(m);
                    }
                    catch (StatementException ex)
                    {
                        fallback(ex);
                    }
                }
                ,
                () =>
                {
                    _rep.Update(m);
                    callback(m);
                }
            );
        }

        public IEnumerable<string> GetPfrDepRegion()
        {
            return _pfrDep.GetRegions();
        }

        public IEnumerable<string> GetPfrDepArea(string region)
        {
            return _pfrDep.GetAreas(region);
        }

        public IEnumerable<PfrDepModel> GetPfrDep(string region, string area)
        {
            return _pfrDep.GetDeps(region, area);
        }

        public void BackofficeSend(PersonData m, Action<PersonData> callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        if (m.RegStatus == RegStatus.RegComplete)
                        {
                            BackofficeRepo.PostPersonData(m);
                        }
                    }
                    catch (BOException ex)
                    {
                        _fallback(ex);
                    }
                }
                ,
                () =>
                {
                    _rep.Update(m);
                    callback(m);
                }
            );
        }

        public void BackofficeSendDocs(PersonData m, Action<PersonData> callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        if (m.RegStatus == RegStatus.NpfSent)
                        {
                            BackofficeRepo.PostPersonDocs(m);
                            m.RegStatus = RegStatus.NpfComplete;
                        }
                    }
                    catch (BOException ex)
                    {
                        _rep.Update(m);
                        _fallback(ex);
                    }
                }
                ,
                () =>
                {
                    _rep.Update(m);
                    callback(m);
                }
            );
        }

        public void PrintForm(IEnumerable<FileСlarification> types, IEnumerable<PersonData> models)
        {
            AsyncHelper.Stitch<Smerg.Agent.PrintForms.MultipagePrintForm>(
                (o) =>
                {
                    var res = new Smerg.Agent.PrintForms.MultipagePrintForm();
                    try
                    {
                        foreach (var m in models)
                            foreach (var t in types)
                                foreach (var rawProv in _printFormProviders)
                                {
                                    var f = rawProv.GetPrintForm(t, m, System.Configuration.ConfigurationManager.AppSettings["useRawPrintForms"] == "yes");
                                    if (f != null)
                                        res.Concat(f);
                                }

                        if (res.Pages.Count == 0)
                            throw new SvcException("Не удалось получить ни одной печатной формы");
                    }
                    catch (SvcException ex)
                    {
                        _fallback(ex);
                    }

                    return res;
                }
                ,
                (o, form) =>
                {
                    PrintHelper.DoPreview(PrintHelper.CreateImagePack(form));
                }
                , null
            );
        }
    }
}
