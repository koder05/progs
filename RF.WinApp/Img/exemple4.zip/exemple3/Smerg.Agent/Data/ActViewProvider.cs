﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using RF.WinApp;
using RF.LinqExt;
using Smerg.Agent.BL;
using Smerg.Agent.BL.Acts;
using Smerg.Agent.ViewModel;
using RF.Common;

namespace Smerg.Agent.Data
{
    public class ActViewProvider : IDataView
    {
        private IActRepo _rep;
        private Action<SvcException> _fallback;
        public ActViewProvider(IActRepo rep)
        {
            _rep = rep;
        }

        public Type ModelType
        {
            get
            {
                return typeof(ActViewModel);
            }
        }

        public object ActivateEmptyModel()
        {
            return new ActViewModel(GetActDetailsFoo);
        }

        public void Create(object o)
        {
            try
            {
                var m = o as Act;
                if (m != null && m.AgreeList != null)
                    _rep.Create(m);
            }
            catch (SvcException ex)
            {
                _fallback(ex);
            }
        }

        public void Delete(IEnumerable<object> pool)
        {
            throw new NotImplementedException();
        }

        public int GetIndexOf(object o, FilterParameterCollection filters, SortParameterCollection orderBy)
        {
            return _rep.GetIndexOf(o as Act, filters, orderBy);
        }

        public IEnumerable<object> GetList(FilterParameterCollection filters, int pageIndex, int pageSize, SortParameterCollection orderBy)
        {
            return _rep.GetList(filters, pageIndex, pageSize, orderBy)
                .Select(a => new ActViewModel(GetActDetailsFoo) { Code = a.Code, Date = a.Date, User = a.User, AgreeCount = a.AgreeCount })
                .Cast<object>().ToList();
        }

        public int GetListCount(FilterParameterCollection filters)
        {
            try
            {
                return _rep.GetListCount(filters);
            }
            catch (SvcException ex)
            {
                _fallback(ex);
            }

            return 0;
        }

        public void Update(object o)
        {
            throw new NotImplementedException();
        }

        public void GetReport(Act act, Action<Filestore> callback)
        {
            AsyncHelper.Stitch(
                (o) =>
                {
                    try
                    {
                        return _rep.GetActPrintForm(act);
                    }
                    catch (SvcException ex)
                    {
                        _fallback(ex);
                    }

                    return null;
                }
                ,
                (o, m) =>
                {
                    callback(m);
                }, null
            );
        }

        internal void SetFallback(Action<SvcException> foo)
        {
            _fallback = foo;
        }

        private Act GetActDetailsFoo(object a)
        {
            return _rep.GetDetails(a as Act);
        }
    }
}
