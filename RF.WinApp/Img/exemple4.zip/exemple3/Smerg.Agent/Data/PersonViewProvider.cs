﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Text;

using RF.WinApp;
using RF.LinqExt;
using Smerg.Agent.BL;
using RF.Common;

namespace Smerg.Agent.Data
{
    public class PersonViewProvider : IDataView
    {
        private IPersonDataRepo _rep;
        private IStatementProvider _regRepo;
        private IPfrDepProv _pfrDep;
        private Action<SvcException> _fallback;
        private IPrintFormProv[] _printFormProviders;

        public ICladrSeeker CladrSeekerRepo { get; private set; }
        public IBO BackofficeRepo { get; private set; }

        internal void SetFallback(Action<SvcException> foo)
        {
            _fallback = foo;
        }

        public PersonViewProvider(IPersonDataRepo rep, IStatementProvider regRepo, ICladrSeeker cladr, IPfrDepProv pfr, IBO bo, IPrintFormProv[] raw)
        {
            _rep = rep;
            _regRepo = regRepo;
            CladrSeekerRepo = cladr;
            _pfrDep = pfr;
            _printFormProviders = raw;
            BackofficeRepo = bo;
        }

        public Type ModelType
        {
            get
            {
                return typeof(PersonData);
            }
        }

        public object ActivateEmptyModel()
        {
            var m = _rep.New();
            return m;
        }

        public void Create(object o)
        {
            var m = o as PersonData;
            _rep.Create(m);

            try
            {
                BackofficeRepo.PostPersonData(m);
                _rep.Update(m);
                VCReg(m);
            }
            catch (SvcException ex)
            {
                _fallback(ex);
            }
            catch (Exception ex)
            {
                _fallback(new SvcException(ex.Message));
            }
            finally
            {
                _rep.Update(m);
            }
        }

        public void Delete(IEnumerable<object> pool)
        {
            foreach (var o in pool.Cast<PersonData>())
                _rep.Delete(o);
        }

        public int GetIndexOf(object o, FilterParameterCollection filters, SortParameterCollection orderBy)
        {
            return _rep.GetIndexOf((PersonData)o, filters, orderBy);
        }

        public IEnumerable<object> GetList(FilterParameterCollection filters, int pageIndex, int pageSize, SortParameterCollection orderBy)
        {
            return _rep.GetList(filters, pageIndex, pageSize, orderBy).Cast<object>().ToList();
        }

        public int GetListCount(FilterParameterCollection filters)
        {
            return _rep.GetListCount(filters);
        }

        public void Update(object o)
        {
            var m = o as PersonData;
            try
            {
                if (string.IsNullOrEmpty(m.NpfClientId))
                {
                    BackofficeRepo.PostPersonData(m);
                    _rep.Update(m);
                }
                if (m.RegStatus < RegStatus.RegReady)
                    VCReg(m);
            }
            catch (SvcException ex)
            {
                _fallback(ex);
            }
            catch (Exception ex)
            {
                _fallback(new SvcException(ex.Message));
            }
            finally
            {
                _rep.Update(m);
            }
        }

        public IEnumerable<FileСlarification> FileСlarifications4Upload
        {
            get
            {
                return BackofficeRepo.FileСlarifications4Upload;
            }
        }

        public void CheckIPA(string ipa)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        BackofficeRepo.CheckIPADouble(ipa);
                    }
                    catch (BOException ex)
                    {
                        _fallback(ex);
                    }
                }
                ,
                () => { }
            );
        }

        private void VCReg(PersonData m)
        {
            if (m.RegStatus == RegStatus.None)
            {
                m.RegStatementKind = StatementKind.NPF2NPF;
                var pool = new List<Filestore>();
                var sessid = _regRepo.SendDeclaration(m, pool);
                if (string.IsNullOrEmpty(sessid) == false)
                {
                    m.RegStatus = RegStatus.DeclSent;
                    m.RegSessionId = sessid;
                    foreach (var f in pool)
                        m.Files.Add(f);
                }
            }

            if (m.RegStatus > RegStatus.None && m.RegStatus < RegStatus.RegComplete)
            {
                _rep.Update(m);
                var tasks = new List<Task>();
                Exception innerEx = null;
                tasks.Add(Task.Factory.StartNew(() => VCRegWaitStatus(m)).ContinueWith((t) => { if (t.IsFaulted) innerEx = t.Exception; }));
                //timeout (10 min)
                tasks.Add(Task.Factory.StartNew(() => Thread.Sleep(1000 * 60 * 10)));
                //tasks.Add(Task.Factory.StartNew(() => Thread.Sleep(1000 * 6)));

                if (Task.WaitAny(tasks.ToArray()) == 1)
                {
                    throw new StatementException("Превышение времени ожидания статуса от УЦ");
                }

                if (innerEx != null)
                {
                    throw new StatementException(innerEx.Message, innerEx.InnerException);
                }
            }
        }


        /// <summary>
        /// Wait Verification Center new status, spam every 10 sec
        /// </summary>
        /// <param name="m"></param>
        private void VCRegWaitStatus(PersonData m)
        {
            var stat = m.RegStatus;
            while (stat == m.RegStatus)
            {
                try
                {
                    stat = _regRepo.AskStatus(m);
                }
                catch (StatementException ex)
                {
                    if (ex.Kind != "AskStatus")
                        throw ex;
                }

                Thread.Sleep(10000);
            }

            m.RegStatus = stat;
        }

        public void RegProcessSmsSend(PersonData m, Action<PersonData> callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        m.RegStatus = _regRepo.ConfirmSMS(m);
                        _rep.Update(m);
                        VCReg(m);
                    }
                    catch (StatementException ex)
                    {
                        _fallback(ex);
                    }
                }
                ,
                () =>
                {
                    _rep.Update(m);
                    callback(m);
                }
            );
        }

        public void RegProcessSmsRepeat(PersonData m, Action callback)
        {
            AsyncHelper.Stitch(
                (o) =>
                {
                    try
                    {
                        _regRepo.RepeatSMS(m);
                    }
                    catch (StatementException ex)
                    {
                        _fallback(ex);
                        return false;
                    }

                    return true;
                }
                ,
                (o, sucсes) =>
                {
                    if(sucсes)
                        callback();
                }, null
            );
        }
        public void RegProcess(PersonData m, Action<PersonData> callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        if (string.IsNullOrEmpty(m.NpfClientId))
                        {
                            BackofficeRepo.PostPersonData(m);
                            _rep.Update(m);
                        }
                        if (m.RegStatus < RegStatus.RegReady)
                            VCReg(m);
                    }
                    catch (SvcException ex)
                    {
                        _fallback(ex);
                    }
                }
                ,
                () =>
                {
                    _rep.Update(m);
                    callback(m);
                }
            );
        }

        public void SendDocs(PersonData m, Action<PersonData> callback)
        {
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        if (m.RegStatus >= RegStatus.DeclSent)
                        {
                            m.RegStatus = _regRepo.SendScans(m);
                            _rep.Update(m);
                            if (m.RegStatus < RegStatus.RegComplete)
                                VCReg(m);

                            BackofficeRepo.PostPrevNpf(m);
                            BackofficeRepo.PostPN(m);
                            BackofficeRepo.PostPersonDocs(m);
                            m.RegStatus = RegStatus.NpfComplete;
                        }
                    }
                    catch (SvcException ex)
                    {
                        _rep.Update(m);
                        _fallback(ex);
                    }
                }
                ,
                () =>
                {
                    _rep.Update(m);
                    callback(m);
                }
            );
        }


        public IEnumerable<string> GetPfrDepRegion()
        {
            return _pfrDep.GetRegions();
        }

        public IEnumerable<string> GetPfrDepArea(string region)
        {
            return _pfrDep.GetAreas(region);
        }

        public IEnumerable<PfrDepModel> GetPfrDep(string region, string area)
        {
            return _pfrDep.GetDeps(region, area);
        }

        public void PrintForm(IEnumerable<FileСlarification> types, IEnumerable<PersonData> models)
        {
            AsyncHelper.Stitch<Smerg.Agent.PrintForms.MultipagePrintForm>(
                (o) =>
                {
                    var res = new Smerg.Agent.PrintForms.MultipagePrintForm();
                    try
                    {
                        foreach (var m in models)
                            foreach (var t in types)
                                foreach (var rawProv in _printFormProviders)
                                {
                                    var f = rawProv.GetPrintForm(t, m, System.Configuration.ConfigurationManager.AppSettings["useRawPrintForms"] == "yes");
                                    if (f != null)
                                        res.Concat(f);
                                }

                        if (res.Pages.Count == 0)
                            throw new SvcException("Не удалось получить ни одной печатной формы");
                    }
                    catch (SvcException ex)
                    {
                        _fallback(ex);
                    }

                    return res;
                }
                ,
                (o, form) =>
                {
                    PrintHelper.DoPreview(PrintHelper.CreateImagePack(form));
                }
                , null
            );
        }

        public void GetVCReport(Action<Filestore> callback)
        {
            AsyncHelper.Stitch(
                (o) =>
                {
                    try
                    {
                        var filters = new FilterParameterCollection();
                        //filters.Add("RegStatus", (int)RegStatus.RegComplete, OperatorType.LessThan);
                        filters.Add("RegSessionId", null, OperatorType.IsNotNull);
                        var list = _rep.GetList(filters, 0, int.MaxValue, new SortParameterCollection()).ToList();
                        return _regRepo.GetVCReport(list);
                    }
                    catch (SvcException ex)
                    {
                        _fallback(ex);
                    }

                    return null;
                }
                ,
                (o, m) =>
                {
                    callback(m);
                }, null
            );
        }
    }
}
