﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RF.WinApp;
using RF.LinqExt;
using Smerg.Agent.BL;
using RF.Common;

namespace Smerg.Agent.Data
{
    public class TransferedDataViewProvider : IDataView
    {
        private ITransferedDataRepo _rep;
        public TransferedDataViewProvider(ITransferedDataRepo rep)
        {
            _rep = rep;
        }

        public Type ModelType
        {
            get
            {
                return typeof(TransferedData);
            }
        }

        public object ActivateEmptyModel()
        {
            throw new NotImplementedException();
        }

        public void Create(object o)
        {
            throw new NotImplementedException();
        }

        public void Delete(IEnumerable<object> pool)
        {
            throw new NotImplementedException();
        }

        public void Update(object o)
        {
            throw new NotImplementedException();
        }

        public int GetIndexOf(object o, FilterParameterCollection filters, SortParameterCollection orderBy)
        {
            return _rep.GetIndexOf((TransferedData)o, filters, orderBy);
        }

        public IEnumerable<object> GetList(FilterParameterCollection filters, int pageIndex, int pageSize, SortParameterCollection orderBy)
        {
            return _rep.GetList(filters, pageIndex, pageSize, orderBy).Cast<object>().ToList();
        }

        public int GetListCount(FilterParameterCollection filters)
        {
            return _rep.GetListCount(filters);
        }

        public void GetPersonData(string key, Action<TransferedPersonData> callback, Action<SvcException> fallback)
        {
            AsyncHelper.Stitch(
                (o) =>
                {
                    try
                    {
                        return _rep.GetPersonData(key);
                    }
                    catch (SvcException ex)
                    {
                        fallback(ex);
                    }

                    return null;
                }
                ,
                (o, m) =>
                {
                    callback(m);
                }, null
            );
        }

        public void GetExcelReport(FilterParameterCollection filters, Action<Filestore> callback, Action<SvcException> fallback)
        {
            AsyncHelper.Stitch(
                (o) =>
                {
                    try
                    {
                        return _rep.GetListInExcel(filters, 0, int.MaxValue, null);
                    }
                    catch (SvcException ex)
                    {
                        fallback(ex);
                    }

                    return null;
                }
                ,
                (o, m) =>
                {
                    callback(m);
                }, null
            );
        }

        public void GetInsuReport(FilterParameterCollection filters, Action<Filestore> callback, Action<SvcException> fallback)
        {
            AsyncHelper.Stitch(
                (o) =>
                {
                    try
                    {
                        return _rep.GetPersonInsReport(filters, 0, int.MaxValue, null);
                    }
                    catch (SvcException ex)
                    {
                        fallback(ex);
                    }

                    return null;
                }
                ,
                (o, m) =>
                {
                    callback(m);
                }, null
            );
        }

        public void UpdatePersonData(TransferedPersonData data, Action callback, Action<SvcException> fallback)
        {
            _rep.UpdatePersonData(data);
            AsyncHelper.Stitch(
                () =>
                {
                    try
                    {
                        _rep.UpdatePersonData(data);
                    }
                    catch (SvcException ex)
                    {
                        fallback(ex);
                    }
                }
                ,
                () =>
                {
                    callback();
                }
            );
        }
    }
}
