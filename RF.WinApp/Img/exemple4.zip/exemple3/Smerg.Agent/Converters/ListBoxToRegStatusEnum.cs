﻿using System;
using System.Collections;
using System.Globalization;
using System.Linq;
using System.Windows.Data;
using Smerg.Agent.BL;

namespace Smerg.Agent.View
{
    /// <summary>
    /// Convert SelectedItemCollection from ListBox to RegStatusEnum List`1[int]
    /// </summary>
    public class ListBoxToRegStatusEnum : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var list = value as IList;
            if(list != null)
                return list.Cast<object>().Select(o => (int)(o as RF.WinApp.EnumViewModel<RegStatus>).Value).ToList();
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
