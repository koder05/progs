﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Data;

using Smerg.Agent.BL;

namespace Smerg.Agent.View
{
    public class RegProcessConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var model = value as PersonData;
            var status = parameter.ToString();
            switch(status)
            {
                case "BeginButtonVisibility":
                    return model.RegStatus == RegStatus.None ? Visibility.Visible : Visibility.Collapsed;
                case "DeclPanelVisibility":
                    return model.RegStatus > RegStatus.None ? Visibility.Visible : Visibility.Collapsed;
                case "DeclPanelIsEnable":
                    return model.RegStatus <= RegStatus.DeclReady;
                case "DeclSendButtonVisibility":
                    return model.RegStatus == RegStatus.DeclReady ? Visibility.Visible : Visibility.Collapsed;
                case "DocsPanelVisibility":
                    return model.RegStatus >= RegStatus.DeclSent && model.RegStatus < RegStatus.NpfComplete ? Visibility.Visible : Visibility.Collapsed;
                case "DocSendButtonVisibility":
                    return model.RegStatus == RegStatus.DeclSent
                        && model.Files.Any(f => f.Сlarification == FileСlarification.PfrDeclaration)
                        && model.Files.Any(f => f.Сlarification == FileСlarification.PfrProcuratory)
                        && model.Files.Any(f => f.Сlarification == FileСlarification.PfrCert)
                        && model.Files.Any(f => f.Сlarification == FileСlarification.Passport)
                        ? Visibility.Visible : Visibility.Collapsed;
                case "SmsPanelVisibility":
                    return model.RegStatus == RegStatus.CodeSendReady || model.RegStatus == RegStatus.SmsRecived 
                        || (model.RegStatus > RegStatus.CodeSendReady && !string.IsNullOrEmpty(model.RegSmsVerifyCode)) ? Visibility.Visible : Visibility.Collapsed;
                case "SmsSendButtonVisibility":
                    return model.RegStatus == RegStatus.CodeSendReady || model.RegStatus == RegStatus.SmsRecived ? Visibility.Visible : Visibility.Collapsed;
                case "SmsBoxIsEnable":
                    return model.RegStatus == RegStatus.CodeSendReady || model.RegStatus == RegStatus.SmsRecived;
                case "CompleteWaitPanelVisibility":
                    return model.RegStatus >= RegStatus.DocsSent && model.RegStatus < RegStatus.RegComplete
                        && !(model.RegStatus == RegStatus.CodeSendReady || model.RegStatus == RegStatus.SmsRecived)
                        ? Visibility.Visible : Visibility.Collapsed;
                case "NpfSendPanelVisibility":
                    return model.RegStatus >= RegStatus.RegComplete && model.RegStatus < RegStatus.NpfComplete ? Visibility.Visible : Visibility.Collapsed;
                case "NpfSendDocsPanelVisibility":
                    return model.RegStatus >= RegStatus.NpfSent && model.RegStatus < RegStatus.NpfComplete ? Visibility.Visible : Visibility.Collapsed;
                case "NpfSendVisibility":
                    return model.RegStatus == RegStatus.RegComplete  ? Visibility.Visible : Visibility.Collapsed;
                case "NpfSendDocsVisibility":
                    return model.RegStatus == RegStatus.NpfSent ? Visibility.Visible : Visibility.Collapsed;
                case "CompleteVisibility":
                    return model.RegStatus == RegStatus.NpfComplete ? Visibility.Visible : Visibility.Collapsed;
                case "ClearButtonVisibility":
                    return model.RegStatus < RegStatus.RegComplete && model.RegStatus > RegStatus.DeclReady ? Visibility.Visible : Visibility.Collapsed;
                case "NpfStatus":
                    return string.IsNullOrEmpty(model.NpfClientId) ? "--" : (model.RegStatus == RegStatus.NpfComplete ? "успешно завершено" : "персданные переданы" );
                case "ProcessButtonVisibility":
                    return model.RegStatus < RegStatus.SmsRecived ? Visibility.Visible : Visibility.Collapsed; 
                case "ModelIsEnabled":
                    return string.IsNullOrEmpty(model.NpfClientId); 
            }

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }

    public class RegProcessConverter2 : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if(values[0] is PersonData)
                return new RegProcessConverter().Convert(values[0], targetType, parameter, culture);
            //return values.All(v => (bool)v) ? Visibility.Visible : Visibility.Collapsed;
            return Visibility.Collapsed;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}