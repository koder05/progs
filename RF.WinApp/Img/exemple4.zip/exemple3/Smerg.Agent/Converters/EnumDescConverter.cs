﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.ComponentModel;
using System.Reflection;
using System.Windows.Data;

namespace Smerg.Agent.View
{
    public class EnumDescConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null)
            {
                Type t = value.GetType();
                string name = Enum.GetName(t, value);
                FieldInfo fi = t.GetField(name);
                DescriptionAttribute attr = (DescriptionAttribute)Attribute.GetCustomAttribute(fi, (typeof(DescriptionAttribute)));
                if (attr != null && string.IsNullOrEmpty(attr.Description) == false)
                    return attr.Description;
            }

            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}

