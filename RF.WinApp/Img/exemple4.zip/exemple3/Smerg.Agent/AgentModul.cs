﻿using System;
using Microsoft.Practices.Prism.MefExtensions.Modularity;
using Microsoft.Practices.Prism.Modularity;
using System.Threading.Tasks;

using Smerg.Agent.BL.Auth;
using RF.Common.DI;
using System.Windows;

namespace Smerg.Agent
{
    [ModuleExport(typeof(AgentModule))]
    public class AgentModule : IModule
    {
        public void Initialize()
        {
            var auth = IoC.Resolve<IAuthBehavior>();
            AuthProvider.Behavior = auth;

            Uri uri = new Uri("/Smerg.Agent;component/LocalStyles.xaml", UriKind.RelativeOrAbsolute);
            Application.Current.Resources.MergedDictionaries.Add(new ResourceDictionary() { Source = uri });

            
            Task.Factory.StartNew(() => AuthProvider.Behavior.GetToken(""))
             .ContinueWith((t) =>
             {
                if (t.IsFaulted)
                    RF.Common.UI.UIErrorOverdoor.Show(t.Exception);
             }, TaskScheduler.FromCurrentSynchronizationContext());
             
        }
    }
}
