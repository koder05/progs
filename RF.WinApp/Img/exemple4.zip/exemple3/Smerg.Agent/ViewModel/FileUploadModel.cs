﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;

namespace Smerg.Agent
{
    public class FileUploadModel
    {
        [Required]
        public string FileName { get; set; }

        public BL.FileСlarification Сlarification { get; set; }
    }
}
