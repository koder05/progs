﻿using System;
using System.Collections.Generic;
using System.Linq;
using RF.WinApp;
using Smerg.Agent.BL;

namespace Smerg.Agent
{
    internal class PaperModel
    {
        public string Name { get; set; }
        public Paper Value { get; set; }
        public string SeriesMask { get; set; }
        public string NumberMask { get; set; }
        public string IssuerCodeMask { get; set; }
        public PaperModel(EnumViewModel<Paper> vm)
        {
            Name = vm.Name;
            Value = vm.Value;
            string name = Enum.GetName(typeof(Paper), Value);
            if (!string.IsNullOrEmpty(name))
            {
                var fi = typeof(Paper).GetField(name);
                var attrs = Attribute.GetCustomAttributes(fi).Where(a => a is PaperRuleAttribute).Cast<PaperRuleAttribute>();
                foreach(var attr in attrs)
                {
                    switch(attr.Part)
                    {
                        case PaperPart.Series:
                            SeriesMask = attr.Mask;
                            break;
                        case PaperPart.Number:
                            NumberMask = attr.Mask;
                            break;
                        case PaperPart.IssuerCode:
                            IssuerCodeMask = attr.Mask;
                            break;
                    }
                }
            }
        }
    }
}
