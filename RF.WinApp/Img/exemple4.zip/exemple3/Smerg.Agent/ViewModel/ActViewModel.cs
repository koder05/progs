﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;

using Smerg.Agent.BL.Acts;


namespace Smerg.Agent.ViewModel
{
    internal class ActViewModel : Act, INotifyPropertyChanged
    {
        private object _sync = new object();
        private NotifyTaskCompletion<Act> _det;
        private Func<object, Act> _getActDetailsTask;
        public ActViewModel(Func<object, Act> asyncTask)
        {
            _getActDetailsTask = asyncTask;
        }
        public NotifyTaskCompletion<Act> ActDetailed
        {
            get
            {
                lock (_sync)
                {
                    if (_getActDetailsTask == null)
                        return null;
                    if (_det == null)
                        _det = new NotifyTaskCompletion<Act>(_getActDetailsTask, this);
                    return _det;
                }
            }
        }

        private string _f;
        public string FileWithIPAFullPath
        {
            get
            {
                return _f;
            }
            set
            {
                if (_f == value)
                    return;

                _f = value;
                this.AgreeList = this.AgreeList ?? new List<Agree>();
                foreach (var s in System.IO.File.ReadAllLines(_f).Where(l => !string.IsNullOrEmpty(l)))
                {
                    this.AgreeList.Add(new Agree { Code = s });
                }
                PropertyChanged(this, new PropertyChangedEventArgs("AgreeList"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
