﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace Smerg.Agent
{
    public class RelayCommand<T> : ICommand
    {
        private Action<T> execute;
        private Func<T, bool> canExecute;

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public RelayCommand(Action<T> _execute, Func<T, bool> _canExecute = null)
        {
            this.execute = _execute;
            this.canExecute = _canExecute;
        }

        public bool CanExecute(object parameter)
        {
            T o = (T)Convert.ChangeType(parameter, typeof(T));
            return this.canExecute == null || this.canExecute(o);
        }

        public void Execute(object parameter)
        {
            T o = (T)Convert.ChangeType(parameter, typeof(T));
            this.execute(o);
        }
    }
}
