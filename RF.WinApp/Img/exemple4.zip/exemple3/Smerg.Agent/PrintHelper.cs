﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Markup;
using System.IO;
using System.IO.Packaging;
using System.Windows.Xps.Packaging;
using System.Runtime.InteropServices;
using System.Windows.Interop;
using Microsoft.Win32.SafeHandles;
using System.Security;
using System.Runtime.ConstrainedExecution;

using Smerg.Agent.BL;
using Smerg.Agent.Controls;
using Smerg.Agent.View;
using Smerg.Agent.PrintForms;

namespace Smerg.Agent
{
    static class PrintHelper
    {
        public static void DoPreview(FixedDocument doc)
        {
            if (doc.Pages.Count > 0)
            {
                using (MemoryStream stream = new MemoryStream())
                {
                    using (Package package = Package.Open(stream, FileMode.Create))
                    {
                        string inMemoryPackageName = "memorystream://myXps.xps";
                        Uri packageUri = new Uri(inMemoryPackageName);
                        PackageStore.AddPackage(packageUri, package);
                        try
                        {
                            using (XpsDocument xpsDoc = new XpsDocument(package, CompressionOption.Maximum, inMemoryPackageName))
                            {
                                var writer = XpsDocument.CreateXpsDocumentWriter(xpsDoc);
                                writer.Write(doc);
                                var windows = new PrintPreview(xpsDoc.GetFixedDocumentSequence());
                                windows.ShowDialog();
                            }
                        }
                        finally
                        {
                            PackageStore.RemovePackage(packageUri);
                        }
                    }
                }
            }
        }

        public static FixedDocument CreateImagePack(MultipagePrintForm form)
        {
            FixedDocument doc = new FixedDocument();
            doc.DocumentPaginator.PageSize = new Size(96 * 8.5, 96 * 11);
            foreach (var page in form.Pages)
            {
                PageContent p = new PageContent();
                FixedPage fixedPage = new FixedPage();
                using (var img = page.Draw())
                    fixedPage.Children.Add(new VisualHost { Visual = DrawImage(img) });
                ((IAddChild)p).AddChild(fixedPage);
                doc.Pages.Add(p);
            }
            return doc;
        }

        private static Visual DrawFilestore(Filestore file)
        {
            DrawingVisual visual = new DrawingVisual();
            using (DrawingContext dc = visual.RenderOpen())
            {
                dc.DrawImage(RawImage2Wpf(file.Body), new Rect(new Size(96 * 8.5, 96 * 11)));
            }

            return visual;
        }

        private static Visual DrawImage(System.Drawing.Image img)
        {
            DrawingVisual visual = new DrawingVisual();
            using (DrawingContext dc = visual.RenderOpen())
            {
                dc.DrawImage(Image2Wpf(img), new Rect(new Size(96 * 8.5, 96 * 11)));
            }

            return visual;
        }

        private static BitmapSource RawImage2Wpf(byte[] img)
        {
            using (var ms = new MemoryStream(img))
            {
                var bi = new BitmapImage();
                bi.BeginInit();
                bi.CacheOption = BitmapCacheOption.OnLoad;
                bi.StreamSource = ms;
                bi.EndInit();
                return bi;
            }
        }

        private static BitmapSource Image2Wpf(System.Drawing.Image source)
        {
            using (var bitmap = new System.Drawing.Bitmap(source))
            using (var handle = new SafeHBitmapHandle(bitmap))
            {
                return Imaging.CreateBitmapSourceFromHBitmap(handle.DangerousGetHandle(),
                    IntPtr.Zero, Int32Rect.Empty,
                    BitmapSizeOptions.FromEmptyOptions());
            }
        }

        [DllImport("gdi32")]
        private static extern int DeleteObject(IntPtr o);

        private sealed class SafeHBitmapHandle : SafeHandleZeroOrMinusOneIsInvalid
        {
            [SecurityCritical]
            public SafeHBitmapHandle(System.Drawing.Bitmap bitmap)
                : base(true)
            {
                SetHandle(bitmap.GetHbitmap());
            }

            [ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
            protected override bool ReleaseHandle()
            {
                return DeleteObject(handle) > 0;
            }
        }

    }
}
