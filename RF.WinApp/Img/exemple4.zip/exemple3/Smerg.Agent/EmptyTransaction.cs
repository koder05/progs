﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RF.Common.Transactions;

namespace Smerg.Agent
{
    public class EmptyTransaction : ITransaction
    {
        public void Complete()
        {
        }

        public void Dispose()
        {
        }

        private void Dispose(bool disposing)
        {
        }
    }

    public class EmptyTransactionLauncher : ITransactionLauncher
    {
        public ITransaction StartNew()
        {
            return new EmptyTransaction();
        }
    }

}
