﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Data;
using RF.WinApp;
using RF.BL.Model;

namespace Smerg.Agent.View
{
    public class RefObjectValidationRule : DataAnnotationsValidationRule
    {
        protected override string Validate(object model, string propertyName)
        {
            var ret = base.Validate(model, propertyName);
            if (string.IsNullOrEmpty(ret))
            {
                var prop = model.GetType().GetProperty(propertyName);
                if (prop != null)
                {
                    var refObj = prop.GetValue(model, null);
                    if (refObj is BaseModel)
                    {
                        foreach (var p in refObj.GetType().GetProperties().Where(p => p.CanRead && p.CanWrite))
                        {
                            ret = Validate(refObj, p.Name);
                            if (!string.IsNullOrEmpty(ret))
                                break;
                        }
                    }
                }
            }

            return ret;
        }
    }
}
