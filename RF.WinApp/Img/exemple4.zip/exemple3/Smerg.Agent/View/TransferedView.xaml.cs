﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Smerg.Agent.Data;
using RF.WinApp.JIT;
using Smerg.Agent.BL;
using RF.WinApp;
using RF.WinApp.Infrastructure.Behaviour;

namespace Smerg.Agent.View
{
    [Export("TransferedView")]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class TransferedView : UserControl
    {
        private TransferedDataViewProvider _pr;

        public TransferedView()
        {
            InitializeComponent();
            _pr = TransferedDataCRUD.DataViewProvider as TransferedDataViewProvider;
            abEditPersonData.Applied += UpdatePersonData;
        }

        private DataObj CurrentData
        {
            get
            {
                return TransferedDataCRUD.SelectedItem as DataObj;
            }
        }

        public TransferedData CurrentModel
        {
            get
            {
                var d = CurrentData;
                if (d != null)
                    return d.Model as TransferedData;
                return null;
            }
        }

        private void btnEditPersonData_Click(object sender, RoutedEventArgs e)
        {
            abEditPersonData.Open(null, null);
            _pr.GetPersonData(CurrentModel.Id, (m) => abEditPersonData.DataContext = m, SvcError);
        }

        private void UpdatePersonData(object sender, EventArgs e)
        {
            var form = sender as ActionBlock;
            if (!form.ValidateAll())
                return;

            var t = form.DataContext as TransferedPersonData;
            form.Close(null, null);
            _pr.UpdatePersonData(t, () => { }, SvcError);
        }

        private void btnExcelReport_Click(object sender, RoutedEventArgs e)
        {
            _pr.GetExcelReport(TransferedDataCRUD.CurrentFilters, (f) => Helper.ShowFile(f), SvcError);
        }

        private void btnInsuReport_Click(object sender, RoutedEventArgs e)
        {
            _pr.GetInsuReport(TransferedDataCRUD.CurrentFilters, (f) => Helper.ShowFile(f), SvcError);
        }

        private void SvcError(SvcException ex)
        {
            string msg = ex.Message;
            if (ex.InnerException != null)
                msg = string.Concat(msg, Environment.NewLine, ex.InnerException.Message);
            MessageBox.Show(msg
                , ex.IsAlert ? "Ответ сервиса" : "Ошибка сервиса"
                , MessageBoxButton.OK
                , ex.IsAlert ? MessageBoxImage.Warning : MessageBoxImage.Error);
        }
    }
}
