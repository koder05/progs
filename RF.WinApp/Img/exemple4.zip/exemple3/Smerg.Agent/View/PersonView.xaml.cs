﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.IO;
using System.ComponentModel.Composition;
using System.ComponentModel;
using Smerg.Agent.BL;
using RF.WinApp;
using RF.WinApp.JIT;
using Smerg.Agent.Data;
using RF.WinApp.Infrastructure.Behaviour;

namespace Smerg.Agent.View
{
    [Export("PersonView")]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class PersonView : UserControl
    {
        public static ICommand PrintCommand { get; private set; } = new RoutedCommand("PrintCommand", typeof(PersonDataView));

        private PersonViewProvider _pr;
        public PersonView()
        {
            InitializeComponent();
            _pr = PersonDataCRUD.DataViewProvider as PersonViewProvider;
            _pr.SetFallback(SvcError);
            CommandBindings.Add(new CommandBinding(PrintCommand, Print));
            HeirAddAB.Applied += AddHeir;
        }

        public ICladrSeeker CladrSeekerRepo
        {
            get
            {
                return _pr.CladrSeekerRepo;
            }
        }

        public IBO BackofficeRepo
        {
            get
            {
                return _pr.BackofficeRepo;
            }
        }

        public IEnumerable<FileСlarification> FileСlarifications4Upload
        {
            get
            {
                var vcFiles = new FileСlarification[] { FileСlarification.PfrCertDecl, FileСlarification.PfrProcuratory, FileСlarification.PfrCert, FileСlarification.Passport };
                return vcFiles.Union(_pr.FileСlarifications4Upload);
            }
        }

        public IEnumerable<string> PfrDepRegion
        {
            get
            {
                return _pr.GetPfrDepRegion();
            }
        }

        private DataObj CurrentData
        {
            get
            {
                if (PersonDataCRUD.FormNew.IsVisible)
                    return PersonDataCRUD.FormNew.DataContext as DataObj;
                if (PersonDataCRUD.FormEdit.IsVisible)
                    return PersonDataCRUD.FormEdit.DataContext as DataObj;
                return PersonDataCRUD.SelectedItem as DataObj;
            }
        }

        public PersonData CurrentModel
        {
            get
            {
                var d = CurrentData;
                if (d != null)
                    return d.Model as PersonData;
                return null;
            }
        }

        private void FioButton_Click(object sender, RoutedEventArgs e)
        {
            var m = CurrentModel;
            if (m != null)
            {
                m.FillBirthName();
            }
        }

        private void SecondNameTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var m = CurrentModel;
            if (m != null)
            {
                m.DetectGender();
            }
        }

        private void AddrCopyButton_Click(object sender, RoutedEventArgs e)
        {
            var m = CurrentModel;
            if (m != null)
            {
                m.CopyAddr();
            }
        }

        protected void Print(object sender, ExecutedRoutedEventArgs e)
        {
            PrintPack(new FileСlarification[] { (FileСlarification)(int)e.Parameter }, new PersonData[] { CurrentModel });
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            PrintPack(new FileСlarification[] {
                FileСlarification.PfrCert, FileСlarification.PfrProcuratory, FileСlarification.PfrDeclaration,
                FileСlarification.Consent, FileСlarification.ClientCard, FileСlarification.ContractOps
            }, PersonDataCRUD.SelectedItems.Cast<DataObj>().Select(o => o.Model as PersonData));
        }

        private void PrintPack(IEnumerable<FileСlarification> types, IEnumerable<PersonData> models)
        {
            foreach (var t in types)
                if (!Enum.IsDefined(typeof(Smerg.Agent.BL.PrintForms), (int)t))
                {
                    MessageBox.Show(string.Format("Тип документа \"{0}\" не поддерживает печатную форму", RF.Common.Utils.GetEnumDescription<FileСlarification>(t))
                        , "Внимание", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

            _pr.PrintForm(types, models);
        }

        private void IPA_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Convert.ToBoolean(e.NewValue))
            {
                RF.Common.AsyncHelper.Stitch(() => { }, () => { (sender as Control).Focus(); });
            }
        }

        private void IPA_LostFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as TextBox;
            if (!string.IsNullOrEmpty(tb.Text) && PersonDataCRUD.FormNew.IsVisible && tb.ValidateAll())
                _pr.CheckIPA((sender as TextBox).Text);
        }

        private void RegProcessButton_Click(object sender, RoutedEventArgs e)
        {
            _pr.RegProcess(CurrentModel, Redraw);
        }

        private void RegProcessSmsSendButton_Click(object sender, RoutedEventArgs e)
        {
            var model = CurrentModel;
            model.RegStatus = RegStatus.CodeSendReady;
            if (RegSmsVerifyCodeTB.ValidateAll())
            {
                _pr.RegProcessSmsSend(model, Redraw);
            }
        }

        private void RegProcessSmsRepeatButton_Click(object sender, RoutedEventArgs e)
        {
            _pr.RegProcessSmsRepeat(CurrentModel, () => MessageBox.Show("Вам посвторно отправлено СМС", "Ответ сервиса",MessageBoxButton.OK, MessageBoxImage.Warning));
        }

        private void RegProcessNpfSendDocsButton_Click(object sender, RoutedEventArgs e)
        {
            _pr.SendDocs(CurrentModel, Redraw);
        }

        private void Redraw(PersonData m)
        {
            CurrentModel.FilesChanged();
            CurrentData.Model = m;
            CurrentData.IsEditing = false;
        }

        private void SvcError(SvcException ex)
        {
            string msg = ex.Message;
            if (ex.InnerException != null)
                msg = string.Concat(msg, Environment.NewLine, ex.InnerException.Message);
            MessageBox.Show(msg
                , ex.IsAlert ? "Ответ сервиса" : "Ошибка сервиса"
                , MessageBoxButton.OK
                , ex.IsAlert ? MessageBoxImage.Warning : MessageBoxImage.Error);
        }

        private void PfrDepRegion_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
                PfrDepAreaDDL.ItemsSource = _pr.GetPfrDepArea(e.AddedItems[0].ToString());
        }

        private void PfrDepArea_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
                PfrDepDDL.ItemsSource = _pr.GetPfrDep(PfrDepRegionDDL.SelectedValue.ToString(), e.AddedItems[0].ToString());
        }

        private void PfrDep_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
                PfrDepCodeTB.Text = (e.AddedItems[0] as PfrDepModel).DepCode;
        }

        private void AgreeSource_Populating(object sender, PopulatingEventArgs e)
        {
            e.Cancel = true;
            RF.Common.AsyncHelper.Stitch((o) =>
            {
                return BackofficeRepo.GetAgreeSources();
            }
            , (o, list) => 
            {
                AutoCompleteBox acb = o as AutoCompleteBox;
                acb.ItemsSource = list;
                acb.PopulateComplete();
            }
            , sender);
        }

        private void NewHeirButton_Click(object sender, RoutedEventArgs e)
        {
            HeirAddAB.Open(null, null);
            HeirAddAB.DataContext = new Heir();
        }

        private void AddHeir(object sender, EventArgs e)
        {
            var form = sender as ActionBlock;
            if (!form.ValidateAll())
                return;

            var h = form.DataContext as Heir;
            CurrentModel.Heirs.Add(h);
            form.Close(null, null);
            CurrentModel.HeirsChanged();
        }

        private void dgHeirs_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            var dobjOld = e.OldValue as DataObj;
            var dobjNew = e.NewValue as DataObj;
            if (dobjOld != null)
                (dobjOld.Model as PersonData).PropertyChanged -= OnPersonDataChanged;
            if (dobjNew != null)
                (dobjNew.Model as PersonData).PropertyChanged += OnPersonDataChanged;
        }

        private void OnPersonDataChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Heirs")
            {
                var grid = Helper.FindChild<DataGrid>(PersonDataCRUD.FormNew.IsVisible ? PersonDataCRUD.FormNew : PersonDataCRUD.FormEdit, "dgHeirs");
                grid.Items.Refresh();
                BindingOperations.GetBindingExpression(grid, DataGrid.ItemsSourceProperty)?.UpdateTarget();
            }
        }

        private void btnDelHeir_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            var h = btn.DataContext as Heir;
            if (h != null && 
                MessageBox.Show(string.Format("Хотите удалить правопреемника {0} {1} {2}?", h.Lastname, h.Firstname, h.Middlename), "Удаление", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                CurrentModel.Heirs.Remove(h);
                CurrentModel.HeirsChanged();
            }
        }

        private void btnVCReport_Click(object sender, RoutedEventArgs e)
        {
            _pr.GetVCReport((f) => Helper.ShowFile(f));
        }
    }
}
