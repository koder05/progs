﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using System.Windows;
using System.Windows.Controls;
using System.IO;
using System.ComponentModel.Composition;
using System.ComponentModel;
using Smerg.Agent.BL;
using RF.WinApp;
using RF.WinApp.JIT;
using Smerg.Agent.Data;
using RF.WinApp.Infrastructure.Behaviour;

namespace Smerg.Agent.View
{
    [Export("PersonDataView")]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class PersonDataView : UserControl
    {
        public static ICommand FileBrowseAction { get; private set; } = new RoutedCommand("FileBrowseAction", typeof(PersonDataView));
        public static ICommand PrintCommand { get; private set; } = new RoutedCommand("PrintCommand", typeof(PersonDataView));

        private PersonDataViewProvider _pr;
        public PersonDataView()
        {
            InitializeComponent();
            _pr = PersonDataCRUD.DataViewProvider as PersonDataViewProvider;
            _pr.SetFallback(SvcError);

            CommandBindings.Add(new CommandBinding(FileBrowseAction, FileBrowse));
            CommandBindings.Add(new CommandBinding(PrintCommand, Print));

            FileImportAB.Applied += AddFile;
        }

        public ICladrSeeker CladrSeekerRepo
        {
            get
            {
                return _pr.CladrSeekerRepo;
            }
        }

        public IBO BackofficeRepo
        {
            get
            {
                return _pr.BackofficeRepo;
            }
        }

        public IEnumerable<EnumViewModel<Gender>> Genders
        {
            get
            {
                return new EnumViewModel<Gender>().GetList();
            }
        }

        public IEnumerable<object> Papers
        {
            get
            {
                return new EnumViewModel<Paper>().GetList().OrderBy(e => e.Value, new PaperComparer()).Where(vm => vm.Value == Paper.PassportRus).Select(vm => new PaperModel(vm));
            }
        }

        public IEnumerable<EnumViewModel<StatementKind>> StatementKinds
        {
            get
            {
                return new EnumViewModel<StatementKind>().GetList().OrderBy(e => e.Value, new StatementKindComparer());
            }
        }

        public IEnumerable<EnumViewModel<RegStatus>> RegStatuses
        {
            get
            {
                return new EnumViewModel<RegStatus>().GetList();
            }
        }

        public IEnumerable<EnumViewModel<FileСlarification>> FileСlarifications
        {
            get
            {
                return new EnumViewModel<FileСlarification>().GetList();
            }
        }

        public IEnumerable<FileСlarification> FileСlarifications4Upload
        {
            get
            {
                return _pr.FileСlarifications4Upload;
            }
        }

        public IEnumerable<string> PfrDepRegion
        {
            get
            {
                return _pr.GetPfrDepRegion();
            }
        }

        private DataObj CurrentData
        {
            get
            {
                if (PersonDataCRUD.FormNew.IsVisible)
                    return PersonDataCRUD.FormNew.DataContext as DataObj;
                if (PersonDataCRUD.FormEdit.IsVisible)
                    return PersonDataCRUD.FormEdit.DataContext as DataObj;
                return PersonDataCRUD.SelectedItem as DataObj;
            }
        }

        public PersonData CurrentModel
        {
            get
            {
                var d = CurrentData;
                if (d != null)
                    return d.Model as PersonData;
                return null;
            }
        }

        private void FioButton_Click(object sender, RoutedEventArgs e)
        {
            var m = CurrentModel;
            if (m != null)
            {
                m.FillBirthName();
            }
        }

        private void SecondNameTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var m = CurrentModel;
            if (m != null)
            {
                m.DetectGender();
            }
        }

        private void AddrCopyButton_Click(object sender, RoutedEventArgs e)
        {
            var m = CurrentModel;
            if (m != null)
            {
                m.CopyAddr();
            }
        }

        private void NewFileButton_Click(object sender, RoutedEventArgs e)
        {
            FileImportAB.Open(null, null);
            FileImportAB.DataContext = new FileUploadModel();
        }

        private void FileBrowse(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog();
            if (dlg.ShowDialog() == true)
            {
                string filename = dlg.FileName;
                tbImportFileName.Text = filename;
                tbImportFileName.ToolTip = filename;
            }
        }

        protected void Print(object sender, ExecutedRoutedEventArgs e)
        {
            PrintPack(new FileСlarification[] { (FileСlarification)(int)e.Parameter }, new PersonData[] { CurrentModel });
        }

        private void PrintButton_Click(object sender, RoutedEventArgs e)
        {
            PrintPack(new FileСlarification[] {
                FileСlarification.PfrCert, FileСlarification.PfrProcuratory, FileСlarification.PfrDeclaration,
                FileСlarification.Consent, FileСlarification.ClientCard, FileСlarification.ContractOps
            }, PersonDataCRUD.SelectedItems.Cast<DataObj>().Select(o => o.Model as PersonData));
        }

        private void PrintPack(IEnumerable<FileСlarification> types, IEnumerable<PersonData> models)
        {
            foreach (var t in types)
                if (!Enum.IsDefined(typeof(Smerg.Agent.BL.PrintForms), (int)t))
                {
                    MessageBox.Show(string.Format("Тип документа \"{0}\" не поддерживает печатную форму", RF.Common.Utils.GetEnumDescription<FileСlarification>(t))
                        , "Внимание", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

            _pr.PrintForm(types, models);
        }

        private void FileDelButton_Click(object sender, RoutedEventArgs e)
        {
            var f = FileDG.SelectedItem as Filestore;
            if (MessageBox.Show(string.Format("Хотите удалить файл \"{0}\"?", f.FileName), "Удаление", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                _pr.RemoveFile(f);
                CurrentModel.FilesChanged();
            }
        }

        private void FileViewButton_Click(object sender, RoutedEventArgs e)
        {
            var f = FileDG.SelectedItem as Filestore;
            Helper.ShowFile(f);
        }

        private void AddFile(object sender, EventArgs e)
        {
            var form = sender as ActionBlock;
            if (!form.ValidateAll())
                return;

            var model = form.DataContext as FileUploadModel;
            var f = Helper.ReadFile(model.FileName);
            f.Сlarification = model.Сlarification;
            f.Person = PersonDataCRUD.SelectedModel as PersonData;
            _pr.AddFile(f);
            form.Close(null, null);
            CurrentModel.FilesChanged();
        }

        private void IPA_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Convert.ToBoolean(e.NewValue))
            {
                RF.Common.AsyncHelper.Stitch(() => { }, () => { (sender as Control).Focus(); });
            }
        }

        private void IPA_LostFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as TextBox;
            if (!string.IsNullOrEmpty(tb.Text) && PersonDataCRUD.FormNew.IsVisible && tb.ValidateAll())
                _pr.CheckIPA((sender as TextBox).Text);
        }

        private void RegProcessBeginButton_Click(object sender, RoutedEventArgs e)
        {
            CurrentModel.RegStatus = RegStatus.DeclReady;
            Redraw(CurrentModel);
        }

        private void RegProcessDeclSendButton_Click(object sender, RoutedEventArgs e)
        {
            if (RegPanel.ValidateAll())
            {
                _pr.RegProcessBegin(CurrentModel, Redraw);
            }
        }

        private void RegProcessDocSendButton_Click(object sender, RoutedEventArgs e)
        {
            _pr.RegProcessDocSend(CurrentModel, Redraw);
        }

        private void RegProcessSmsSendButton_Click(object sender, RoutedEventArgs e)
        {
            var model = CurrentModel;
            model.RegStatus = RegStatus.CodeSendReady;
            if (RegSmsVerifyCodeTB.ValidateAll())
            {
                _pr.RegProcessSmsSend(model, Redraw);
            }
        }

        private void RegProcessCompleteAskButton_Click(object sender, RoutedEventArgs e)
        {
            if (RegSmsVerifyCodeTB.ValidateAll())
            {
                _pr.RegProcessCompleteAsk(CurrentModel, Redraw);
            }
        }

        private void RegProcessNpfSendButton_Click(object sender, RoutedEventArgs e)
        {
            _pr.BackofficeSend(CurrentModel, Redraw);
        }

        private void RegProcessNpfSendDocsButton_Click(object sender, RoutedEventArgs e)
        {
            _pr.BackofficeSendDocs(CurrentModel, Redraw);
        }

        private void RegProcessClearButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show(
                    string.Format("Хотите прервать процесс и начать заново?{0}Все файлы с полученными бланками документов и их загруженные сканкопии будут удалены.", Environment.NewLine)
                    , "Удаление", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                _pr.RegProcessReset(CurrentModel, Redraw);
            }
        }

        private void Redraw(PersonData m)
        {
            CurrentModel.FilesChanged();
            CurrentData.Model = m;
            CurrentData.IsEditing = false;
        }

        private void SvcError(SvcException ex)
        {
            string msg = ex.Message;
            if (ex.InnerException != null)
                msg = string.Concat(msg, Environment.NewLine, ex.InnerException.Message);
            MessageBox.Show(msg
                , ex.IsAlert ? "Ответ сервиса" : "Ошибка сервиса"
                , MessageBoxButton.OK
                , ex.IsAlert ? MessageBoxImage.Warning : MessageBoxImage.Error);
        }

        private void PfrDepRegion_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
                PfrDepAreaDDL.ItemsSource = _pr.GetPfrDepArea(e.AddedItems[0].ToString());
        }

        private void PfrDepArea_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
                PfrDepDDL.ItemsSource = _pr.GetPfrDep(PfrDepRegionDDL.SelectedValue.ToString(), e.AddedItems[0].ToString());
        }

        private void PfrDep_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
                PfrDepCodeTB.Text = (e.AddedItems[0] as PfrDepModel).DepCode;
        }

        private void FileDG_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            var dobjOld = e.OldValue as DataObj;
            var dobjNew = e.NewValue as DataObj;
            if (dobjOld != null)
                (dobjOld.Model as PersonData).PropertyChanged -= OnPersonDataChanged;
            if (dobjNew != null)
                (dobjNew.Model as PersonData).PropertyChanged += OnPersonDataChanged;
        }

        void OnPersonDataChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Files")
            {
                FileDG.Items.Refresh();
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var b = Helper.FindChild<Xceed.Wpf.Toolkit.MaskedTextBox>((sender as FrameworkElement).Parent, "PaperIssuerDepCodeTB");

            if (e.AddedItems.Count > 0)
            {
                //var p = (dynamic)e.AddedItems[0];
                //b.Mask = p.Mask;
                //switch (p)
                //{
                //    case Paper.BirthCert:
                //        b.Mask = "000()000";
                //        break;
                //    case Paper.PassportRus:
                //        b.Mask = "000-000";
                //        break;
                //    default:
                //        b.Mask = "000^^000";
                //        break;
                //}
            }
        }
    }
}
