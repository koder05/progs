﻿using System;
using System.ComponentModel.Composition;
using Microsoft.Practices.Prism.Regions;
using System.Windows.Controls;
using Microsoft.Practices.Prism.Commands;
using RF.WinApp.Infrastructure.Behaviour;
using RF.WinApp.Infrastructure.Models;
using RF.WinApp.Infrastructure.CC;
using RF.WinApp;
using System.Windows.Media.Imaging;
using System.Windows;

namespace Smerg.Agent.View
{
    [ViewExport(RegionName = RegionNames.MenuRegion)]
    //public class AgentMenu : AloneMenuItem
    //{
    //    public AgentMenu()
    //        : base("Сафмар", "/PersonDataView")
    //    {
    //    }
    //}

    public class AgentMenu : SplitButton
    {
        public AgentMenu()
            : base()
        {
            this.Header = "Сафмар";
            var m = new SplitMenuItem() { Header = "Новые", Command = new DelegateCommand(OnNewExecuted) };
            AddExtendedButton(m);
            this.AddChild(m);

            m = new SplitMenuItem() { Header = "Переданные", Command = new DelegateCommand(OnTransferedExecuted) };
            AddExtendedButton(m);
            this.AddChild(m);

            m = new SplitMenuItem() { Header = "Акты        ", Command = new DelegateCommand(OnActExecuted) };
            AddExtendedButton(m);
            this.AddChild(m);

            this.AddChild(new Separator());

            m = new SplitMenuItem() { Header = "Кабинет агента" };
            AddExtendedButton(m);
            this.AddChild(m);

            this.AddChild(new Separator());

            m = new SplitMenuItem() { Header = "Старые Новые", Command = new DelegateCommand(OnOldNewExecuted) };
            AddExtendedButton(m);
            this.AddChild(m);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
        }

        private void OnNewExecuted()
        {
            Uri viewNav = new Uri("/PersonView", UriKind.Relative);
            regionManager.RequestNavigate(RegionNames.WorkspaceRegion, viewNav);
        }

        private void OnOldNewExecuted()
        {
            Uri viewNav = new Uri("/PersonDataView", UriKind.Relative);
            regionManager.RequestNavigate(RegionNames.WorkspaceRegion, viewNav);
        }

        private void OnTransferedExecuted()
        {
            Uri viewNav = new Uri("/TransferedView", UriKind.Relative);
            regionManager.RequestNavigate(RegionNames.WorkspaceRegion, viewNav);
        }

        private void OnActExecuted()
        {
            Uri viewNav = new Uri("/ActView", UriKind.Relative);
            regionManager.RequestNavigate(RegionNames.WorkspaceRegion, viewNav);
        }

        private void AddExtendedButton(SplitMenuItem mi)
        {
            mi.ButtonMenuItemsSource.Add(new MenuItem()
            {
                Header = "Закладка",
                ToolTip = "Открыть в новой закладке"
                ,
                Icon = new Image() { Source = new BitmapImage(new Uri("pack://application:,,,/RF.WinApp;component/Img/tab_new.png")), Width = 18, Height = 18 }
                ,
                Command = new DelegateCommand(() => 
                {
                    TabsPlatesCC.SetAddingOrder(true);
                    mi.Apply(null, null);
                })
            });
            mi.ButtonMenuItemsSource.Add(new MenuItem()
            {
                Header = "Плитка",
                ToolTip = "Открыть в текущей закладке"
                ,
                Icon = new Image() { Source = new BitmapImage(new Uri("pack://application:,,,/RF.WinApp;component/Img/application_view_tile.png")), Width = 18, Height = 18 }
                ,
                Command = new DelegateCommand(() => 
                {
                    TabsPlatesCC.SetAddingOrder(false);
                    mi.Apply(null, null);
                })
            });
        }

        [Import]
        public IRegionManager regionManager;
    }
}
