﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Smerg.Agent.Data;
using Smerg.Agent.BL;
using RF.WinApp.JIT;
using Smerg.Agent.BL.Acts;

namespace Smerg.Agent.View
{
    [Export("ActView")]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public partial class ActView : UserControl
    {
        public static ICommand FileBrowseAction { get; private set; } = new RoutedCommand("FileBrowseAction", typeof(ActView));
        private ActViewProvider _pr;
        public ActView()
        {
            InitializeComponent();
            _pr = ActCRUD.DataViewProvider as ActViewProvider;
            _pr.SetFallback(SvcError);
            CommandBindings.Add(new CommandBinding(FileBrowseAction, FileBrowse));
        }

        private void btnExcelReport_Click(object sender, RoutedEventArgs e)
        {
            _pr.GetReport((ActCRUD.SelectedItem as DataObj).Model as Act, Helper.ShowFile);
        }

        private void FileBrowse(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.DefaultExt = "*txt";
            //dlg.Filter = "Text files (*.txt)|*.txt*|Adobe Acrobat files (*.pdf)|*.pdf";
            dlg.Filter = "Text files (*.txt)|*.txt*";
            if (dlg.ShowDialog() == true)
            {
                string filename = dlg.FileName;
                tbImportFileName.Text = filename;
                tbImportFileName.ToolTip = filename;
            }
        }

        private void SvcError(SvcException ex)
        {
            string msg = ex.Message;
            if (ex.InnerException != null)
                msg = string.Concat(msg, Environment.NewLine, ex.InnerException.Message);
            MessageBox.Show(msg
                , ex.IsAlert ? "Ответ сервиса" : "Ошибка сервиса"
                , MessageBoxButton.OK
                , ex.IsAlert ? MessageBoxImage.Warning : MessageBoxImage.Error);
        }
    }
}
