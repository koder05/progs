﻿using System;
using System.Windows;
using System.Windows.Documents;

namespace Smerg.Agent.View
{
    public partial class PrintPreview : Window
    {
        private FixedDocumentSequence _document;

        public PrintPreview(FixedDocumentSequence document)
        {
            if(document == null)

            _document = document;
            InitializeComponent();
            PreviewD.Document = document;
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
        }
    }
}
