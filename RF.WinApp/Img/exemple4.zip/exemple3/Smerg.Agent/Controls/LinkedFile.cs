﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Smerg.Agent.BL;
using System.Windows.Data;
using System.ComponentModel;

namespace Smerg.Agent.Controls
{
    public class LinkedFile : Control, INotifyPropertyChanged
    {
        public static readonly DependencyProperty FileСlarificationProperty =
                DependencyProperty.Register("FileСlarification", typeof(FileСlarification), typeof(LinkedFile), new PropertyMetadata(FileСlarification.Unknown, null, CoerceFileСlarification));
        public static readonly DependencyProperty PersonDataProperty =
                DependencyProperty.Register("PersonData", typeof(PersonData), typeof(LinkedFile), new UIPropertyMetadata(null, OnChangePersonData));

        private static object CoerceFileСlarification(DependencyObject d, object e)
        {
            return e;
        }

        private static void OnChangePersonData(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (LinkedFile)d;
            var mold = e.OldValue as PersonData;
            var m = e.NewValue as PersonData;
            if (mold != null)
                mold.PropertyChanged -= a.OnPersonDataChanged;
            if (m != null)
            {
                m.PropertyChanged += a.OnPersonDataChanged;
                a.OnPersonDataChanged(a, new PropertyChangedEventArgs("Files"));
            }
        }

        public static ICommand DocViewCommand { get; private set; } = new RoutedCommand("DocViewCommand", typeof(LinkedFile));
        public static ICommand DocUploadCommand { get; private set; } = new RoutedCommand("DocUploadCommand", typeof(LinkedFile));

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        void OnPersonDataChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Files")
            {
                File = this.PersonData.Files.Where(f => f.Сlarification == FileСlarification).OrderByDescending(f => f.UploadDate).FirstOrDefault();
                OnPropertyChanged(new PropertyChangedEventArgs("FileLinked"));
                OnPropertyChanged(new PropertyChangedEventArgs("File"));
            }
        }

        public LinkedFile()
        {
            CommandBindings.Add(new CommandBinding(DocViewCommand, DocView));
            CommandBindings.Add(new CommandBinding(DocUploadCommand, DocUpload));
        }

        public FileСlarification FileСlarification
        {
            get
            {
                return (FileСlarification)this.GetValue(FileСlarificationProperty);
            }
            set
            {
                this.SetValue(FileСlarificationProperty, value);
            }
        }

        public PersonData PersonData
        {
            get
            {
                return (PersonData)this.GetValue(PersonDataProperty);
            }
            set
            {
                this.SetValue(PersonDataProperty, value);
            }
        }

        public bool FileLinked
        {
            get
            {
                return File != null;
            }
        }

        public bool PrintEnabled
        {
            get
            {
                return Enum.IsDefined(typeof(Smerg.Agent.BL.PrintForms), (int)this.FileСlarification);
            }
        }

        public Filestore File { get; private set; }

        public string FileСlarificationName
        {
            get { return RF.Common.Utils.GetEnumDescription<FileСlarification>(this.FileСlarification); }
        }

        protected virtual void DocView(object sender, ExecutedRoutedEventArgs e)
        {
            if (File != null)
            {
                Helper.ShowFile(File);
            }
            else
            {
                MessageBox.Show("Файл отсутствует!", "ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        protected virtual void DocUpload(object sender, ExecutedRoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog();
            if (dlg.ShowDialog() == true)
            {
                var fold = File;
                var fnew = Helper.ReadFile(dlg.FileName);

                if (fold != null)
                {
                    fold.Body = fnew.Body;
                    fold.FileName = fnew.FileName;
                    fold.UploadDate = fnew.UploadDate;
                }
                else
                {
                    fnew.Сlarification = this.FileСlarification;
                    this.PersonData.Files.Add(fnew);
                }

                this.PersonData.FilesChanged();
            }
        }
    }
}
