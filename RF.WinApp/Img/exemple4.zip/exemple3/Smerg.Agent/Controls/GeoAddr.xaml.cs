﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Threading;
using System.Windows.Shapes;
using Smerg.Agent.BL;
using RF.Common.DI;
using RF.Common;

namespace Smerg.Agent.View
{
    public partial class GeoAddr : UserControl
    {
        public static readonly DependencyProperty CladrSeekerRepoProperty;
        public static readonly DependencyProperty AddrProperty;
        public static readonly DependencyProperty AddrRegionProperty;
        public static readonly DependencyProperty AddrAreaProperty;
        public static readonly DependencyProperty AddrCityProperty;
        public static readonly DependencyProperty AddrStreetProperty;
        public static readonly DependencyProperty AddrLocalityProperty;
        public static readonly DependencyProperty AddrHouseProperty;
        public static readonly DependencyProperty AddrBuildingProperty;

        static GeoAddr()
        {
            CladrSeekerRepoProperty = DependencyProperty.Register("CladrSeekerRepo", typeof(ICladrSeeker), typeof(GeoAddr), new UIPropertyMetadata(null, OnChangeCladrSeekerRepo));
            AddrProperty = DependencyProperty.Register("Addr", typeof(object), typeof(GeoAddr), new UIPropertyMetadata(OnChangeAddr));
            AddrRegionProperty = DependencyProperty.Register("AddrRegion", typeof(AddrPart), typeof(GeoAddr), new UIPropertyMetadata(OnChangeAddrRegion));
            AddrAreaProperty = DependencyProperty.Register("AddrArea", typeof(AddrPart), typeof(GeoAddr), new UIPropertyMetadata(OnChangeAddrArea));
            AddrCityProperty = DependencyProperty.Register("AddrCity", typeof(AddrPart), typeof(GeoAddr), new UIPropertyMetadata(OnChangeAddrCity));
            AddrStreetProperty = DependencyProperty.Register("AddrStreet", typeof(AddrPart), typeof(GeoAddr), new UIPropertyMetadata(OnChangeAddrStreet));
            AddrLocalityProperty = DependencyProperty.Register("AddrLocality", typeof(AddrPart), typeof(GeoAddr), new UIPropertyMetadata(OnChangeAddrLocality));
            AddrHouseProperty = DependencyProperty.Register("AddrHouse", typeof(AddrPart), typeof(GeoAddr), new UIPropertyMetadata(OnChangeAddrHouse));
            AddrBuildingProperty = DependencyProperty.Register("AddrBuilding", typeof(AddrPart), typeof(GeoAddr), new UIPropertyMetadata(OnChangeAddrBuilding));
        }

        private static void OnChangeCladrSeekerRepo(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (GeoAddr)d;
            a.CladrSeekerRepo = e.NewValue as ICladrSeeker;
        }

        private static void OnChangeAddr(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (GeoAddr)d;
            //a.Addr = e.NewValue as CladrModel;
            var m = e.NewValue as CladrModel;
            if (m != null)
            {
                a.AddrRegion = new AddrPart { name = m.Region, code = m.RegionCode };
                a.AddrArea = new AddrPart { name = m.Area };
                a.AddrCity = new AddrPart { name = m.City };
                a.AddrLocality = new AddrPart { name = m.Locality };
                a.AddrStreet = new AddrPart { name = m.Street, post = m.PostCode };
                a.AddrHouse = new AddrPart { name = m.House, post = m.PostCode, type = m.HouseType };
                a.AddrBuilding = new AddrPart { name = m.Building, post = m.PostCode, type = m.BuildingType };
            }
            else
            {
                a.AddrRegion = new AddrPart();
                a.AddrArea = new AddrPart();
                a.AddrCity = new AddrPart();
                a.AddrLocality = new AddrPart();
                a.AddrStreet = new AddrPart();
                a.AddrHouse = new AddrPart();
                a.AddrBuilding = new AddrPart();
            }
        }

        private static void OnChangeAddrRegion(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (GeoAddr)d;
            if (a.Addr == null) return;
            var m = e.NewValue as AddrPart;
            if (m != null)
            {
                a.Addr.Region = m.name;
                a.Addr.RegionCode = m.code;
            }
            else
            {
                a.Addr.Region = "";
                a.Addr.RegionCode = 0;
            }
        }

        private static void OnChangeAddrArea(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (GeoAddr)d;
            if (a.Addr == null) return;
            var m = e.NewValue as AddrPart;
            a.Addr.Area = m?.name;
        }

        private static void OnChangeAddrCity(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (GeoAddr)d;
            if (a.Addr == null) return;
            var m = e.NewValue as AddrPart;
            a.Addr.City = m?.name;
        }

        private static void OnChangeAddrLocality(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (GeoAddr)d;
            if (a.Addr == null) return;
            var m = e.NewValue as AddrPart;
            a.Addr.Locality = m?.name;
        }

        private static void OnChangeAddrStreet(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (GeoAddr)d;
            if (a.Addr == null) return;
            var m = e.NewValue as AddrPart;
            if (m != null)
            {
                a.Addr.Street = m.name;
                if (!string.IsNullOrEmpty(m.post))
                {
                    a.Addr.PostCode = m.post;
                    a.Addr.NotifyChanged();
                }
            }
            else
            {
                a.Addr.Street = "";
            }
        }

        private static void OnChangeAddrHouse(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (GeoAddr)d;
            if (a.Addr == null) return;
            var m = e.NewValue as AddrPart;
            if (m != null)
            {
                a.Addr.House = m.name;
                if (!string.IsNullOrEmpty(m.post))
                {
                    a.Addr.PostCode = m.post;
                    a.Addr.NotifyChanged();
                }
            }
            else
            {
                a.Addr.House = "";
                a.Addr.HouseType = "";
            }
        }

        private static void OnChangeAddrBuilding(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (GeoAddr)d;
            if (a.Addr == null) return;
            var m = e.NewValue as AddrPart;
            if (m != null)
            {
                a.Addr.Building = m.name;
                if (!string.IsNullOrEmpty(m.post))
                {
                    a.Addr.PostCode = m.post;
                    a.Addr.NotifyChanged();
                }
            }
            else
            {
                a.Addr.Building = "";
                a.Addr.BuildingType = "";
            }
        }

        public GeoAddr()
        {
            InitializeComponent();
            this.IsVisibleChanged += GeoAddr_IsVisibleChanged;
        }

        public ICladrSeeker CladrSeekerRepo
        {
            get
            {
                var _repo = GetValue(CladrSeekerRepoProperty) as ICladrSeeker;
                if (_repo == null)
                {
                    _repo = IoC.Resolve<ICladrSeeker>();
                    CladrSeekerRepo = _repo;
                }
                return _repo;
            }
            set
            {
                SetValue(CladrSeekerRepoProperty, value);
            }
        }

        public CladrModel Addr
        {
            get
            {
                return GetValue(AddrProperty) as CladrModel;
            }
            set
            {
                SetValue(AddrProperty, value);
            }
        }

        AddrPart AddrRegion
        {
            get
            {
                return GetValue(AddrRegionProperty) as AddrPart;
            }
            set
            {
                SetValue(AddrRegionProperty, value);
            }
        }

        AddrPart AddrArea
        {
            get
            {
                return GetValue(AddrAreaProperty) as AddrPart;
            }
            set
            {
                SetValue(AddrAreaProperty, value);
            }
        }

        AddrPart AddrCity
        {
            get
            {
                return GetValue(AddrCityProperty) as AddrPart;
            }
            set
            {
                SetValue(AddrCityProperty, value);
            }
        }

        AddrPart AddrLocality
        {
            get
            {
                return GetValue(AddrLocalityProperty) as AddrPart;
            }
            set
            {
                SetValue(AddrLocalityProperty, value);
            }
        }

        AddrPart AddrStreet
        {
            get
            {
                return GetValue(AddrStreetProperty) as AddrPart;
            }
            set
            {
                SetValue(AddrStreetProperty, value);
            }
        }

        AddrPart AddrHouse
        {
            get
            {
                return GetValue(AddrHouseProperty) as AddrPart;
            }
            set
            {
                SetValue(AddrHouseProperty, value);
            }
        }

        AddrPart AddrBuilding
        {
            get
            {
                return GetValue(AddrBuildingProperty) as AddrPart;
            }
            set
            {
                SetValue(AddrBuildingProperty, value);
            }
        }

        private void AddrRegion_Populating(object sender, PopulatingEventArgs e)
        {
            AddrPopulating(sender, e, CladrPart.Region);
        }

        private void AddrArea_Populating(object sender, PopulatingEventArgs e)
        {
            AddrPopulating(sender, e, CladrPart.Area);
        }

        private void AddrCity_Populating(object sender, PopulatingEventArgs e)
        {
            AddrPopulating(sender, e, CladrPart.City);
        }

        private void AddrLocality_Populating(object sender, PopulatingEventArgs e)
        {
            AddrPopulating(sender, e, CladrPart.Locality);
        }

        private void AddrStreet_Populating(object sender, PopulatingEventArgs e)
        {
            AddrPopulating(sender, e, CladrPart.Street);
        }

        private void AddrHouse_Populating(object sender, PopulatingEventArgs e)
        {
            AddrPopulating(sender, e, CladrPart.House);
        }

        private void AddrBuilding_Populating(object sender, PopulatingEventArgs e)
        {
            AddrPopulating(sender, e, CladrPart.Building);
        }


        private CancellationTokenSource ts = null;
        private void GeoAddr_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (!this.IsVisible && ts != null)
            {
                ts.Dispose();
                ts = null;
            }
        }

        private void AddrPopulating(object sender, PopulatingEventArgs e, CladrPart part)
        {
            e.Cancel = true;

            //this is for 300ms delay before wait overdoor screen will blocks input
            //cancellation used for avoid multiply requests 
            if (ts != null) ts.Cancel();
            ts = new CancellationTokenSource();
            Task.Factory
            .StartNew(() => { for (int i = 0; i < 100; i++) { ts.Token.ThrowIfCancellationRequested(); Thread.Sleep(3); } }, ts.Token)
            .ContinueWith(_ =>
                Application.Current.Dispatcher.BeginInvoke(new Action(() => {
                    Find(part, e.Parameter, this.Addr, PopulateAddrBox, sender);
                    }), DispatcherPriority.Background), ts.Token, TaskContinuationOptions.OnlyOnRanToCompletion, TaskScheduler.Default
            );
        }

        private void PopulateAddrBox(object sender, IEnumerable<AddrPart> list)
        {
            AutoCompleteBox acb = sender as AutoCompleteBox;
            acb.ItemsSource = list;
            acb.PopulateComplete();
        }

        private void Find(CladrPart part, string find, CladrModel m, Action<object, IEnumerable<AddrPart>> callback, object param)
        {
            var _repo = CladrSeekerRepo;
            AsyncHelper.Stitch((o) =>
            {
                try
                {
                    switch (part)
                    {
                        case CladrPart.Region:
                            return _repo.FindRegion(find).Select(a => new AddrPart { name = a.Region, code = a.RegionCode });
                        case CladrPart.Area:
                            return _repo.FindArea(find, m).Select(a => new AddrPart { name = a.Area });
                        case CladrPart.City:
                            return _repo.FindCity(find, m).Select(a => new AddrPart { name = a.City });
                        case CladrPart.Locality:
                            return _repo.FindLocality(find, m).Select(a => new AddrPart { name = a.Locality });
                        case CladrPart.Street:
                            return _repo.FindStreet(find, m).Select(a => new AddrPart { name = a.Street, post = a.PostCode });
                        case CladrPart.House:
                            return _repo.FindHouse(find, m).Select(a => new AddrPart { name = a.House, post = a.PostCode });
                        case CladrPart.Building:
                            return _repo.FindBuilding(find, m).Select(a => new AddrPart { name = a.Building, post = a.PostCode });
                        default:
                            return new List<AddrPart>();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    return new List<AddrPart>();
                }
            }
            , callback, param);
        }
    }

    class AddrPart
    {
        public string post { get; set; }
        public string type { get; set; }
        public int code { get; set; }
        public string name { get; set; }
    }
}
