﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace Smerg.Agent.Controls
{
    public partial class RestrictInput : TextBox
    {
        private string prevText = string.Empty;

        public RestrictInput()
        {
        }

        public IInputHandler InputHandler { get; set; }
    }

    public interface IInputHandler
    { }
}
