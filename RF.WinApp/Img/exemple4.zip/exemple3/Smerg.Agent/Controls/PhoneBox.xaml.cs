﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using Smerg.Agent.BL;
using System.Windows.Data;
using System.Globalization;
using System.ComponentModel;

namespace Smerg.Agent.View
{
    public partial class PhoneBox : UserControl
    {
        private string prevText = string.Empty;

        public static readonly DependencyProperty PhoneProperty =
            DependencyProperty.Register("Phone", typeof(object), typeof(PhoneBox), new UIPropertyMetadata(OnChangePhone));
        public static readonly DependencyProperty NumProperty =
            DependencyProperty.Register("Num", typeof(string), typeof(PhoneBox), new UIPropertyMetadata());


        private static void OnChangePhone(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (PhoneBox)d;
            var phone = e.NewValue as Phone;
            a.Num = a.Format4MainBox(phone);
        }

        public PhoneBox()
        {
            InitializeComponent();
        }

        public Phone Phone
        {
            get
            {
                return GetValue(PhoneProperty) as Phone;
            }
            set
            {
                SetValue(PhoneProperty, value);
            }
        }

        public string Num
        {
            get
            {
                return (string)GetValue(NumProperty);
            }
            set
            {
                SetValue(NumProperty, value);
            }
        }

        private void MainBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var txt = sender as TextBox;
            if (txt != null && txt.Text.Length > 0)
            {
                var newText = string.Empty;
                int curCaret = -1;
                var raw = Regex.Replace(txt.Text, @"[^0-9()]", "");

                if (string.IsNullOrEmpty(raw))
                {
                    newText = string.Empty;
                }
                else if (Regex.IsMatch(raw, @"^\d$"))
                {
                    newText = "(" + raw;
                }
                else if (raw == "(" || Regex.IsMatch(raw, @"^\(\d{1,2}$"))
                {
                    newText = txt.Text;
                }
                else if (Regex.IsMatch(raw, @"^\(\d{3,6}\)$"))
                {
                    newText = txt.Text;
                    curCaret = newText.Length - 1;
                }
                else if (Regex.IsMatch(raw, @"^\(\d{3,6}$"))
                {
                    newText = raw + ")";
                    curCaret = newText.Length - 1;
                }
                else if (Regex.IsMatch(raw, @"^\(\d{7}\)$"))
                {
                    newText = raw.Substring(0, 7) + ")" + raw.Substring(7, 1);
                }
                else if (Regex.IsMatch(raw, @"^\(\d{,2}\)\d*$"))
                {
                    newText = prevText;
                }
                else if (Regex.IsMatch(raw, @"^\(\d{7,}$"))
                {
                    newText = raw.Substring(0, 7) + ")" + raw.Substring(7, raw.Length - 7);
                }
                else if (Regex.IsMatch(raw, @"^\(\d{3,6}\)\d+$"))
                {
                    newText = raw.Substring(0, Math.Min(12, raw.Length));
                }
                else if (Regex.IsMatch(raw, @"^\(\d{3,5}\)\d+\)\d*$"))
                {
                    var prev = prevText.LastIndexOf(')');
                    var now = raw.LastIndexOf(')');
                    if (prev == now - 1)
                        now = raw.IndexOf(')');
                    if (prev > now)
                    {
                        newText = raw.Remove(prev + 1, 1);
                        curCaret = now + 1;
                    }
                    else
                    {
                        newText = raw.Remove(prev, 1);
                        curCaret = txt.CaretIndex - 1;
                    }
                }

                prevText = newText;
                var p = newText.IndexOf(')');
                if (p == -1 || p == newText.Length - 1)
                    txt.Text = newText;
                else
                    txt.Text = string.Concat(newText.Substring(0, p + 1), Phone.FormatNumber(newText.Substring(p + 1, newText.Length - p - 1)));
                txt.CaretIndex = curCaret == -1 ? txt.Text.Length : curCaret;
            }
            Update();
        }

        string Format4MainBox(Phone phone)
        {
            if (phone == null)
                return string.Empty;
            return string.Concat(string.IsNullOrEmpty(phone.CityCode) ? "" : string.Format("({0})", phone.CityCode), Phone.FormatNumber(phone.Number));
        }

        private bool MainBoxNeedUpdate()
        {
            return Format4MainBox(Phone) != MainBox.Text;
        }

        private void Update()
        {
            if (MainBoxNeedUpdate())
            {
                if (string.IsNullOrEmpty(MainBox.Text))
                {
                    if (Phone != null)
                    {
                        Phone = null;
                        BindingOperations.GetBindingExpression(this, PhoneProperty)?.UpdateSource();
                    }
                }
                else
                {
                    if (Phone == null)
                    {
                        var phone = new Phone();
                        phone.FullNumber = string.Concat("+7", MainBox.Text);
                        Phone = phone;
                        BindingOperations.GetBindingExpression(this, PhoneProperty)?.UpdateSource();
                    }
                    else
                    {
                        Phone.FullNumber = string.Concat("+7", MainBox.Text);
                        //BindingOperations.GetBindingExpression(MainBox, TextBox.TextProperty)?.UpdateSource();
                    }
                }
            }
        }
    }
}
