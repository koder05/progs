﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using RF.Common.DI;
using Smerg.Agent.BL;
using RF.Common;

namespace Smerg.Agent.View
{
    /// <summary>
    /// Interaction logic for OksmCountry.xaml
    /// </summary>
    public partial class OksmCountryBox : UserControl
    {
        public static readonly DependencyProperty BackofficeRepoProperty;

        static OksmCountryBox()
        {
            BackofficeRepoProperty = DependencyProperty.Register("BackofficeRepo", typeof(IBO), typeof(OksmCountryBox), new UIPropertyMetadata(null, OnChangeBackofficeRepo));
        }

        private static void OnChangeBackofficeRepo(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var a = (OksmCountryBox)d;
            a.BackofficeRepo = e.NewValue as IBO;
        }

        public OksmCountryBox()
        {
            InitializeComponent();
        }

        public IBO BackofficeRepo
        {
            get
            {
                var _repo = GetValue(BackofficeRepoProperty) as IBO;
                if (_repo == null)
                {
                    _repo = IoC.Resolve<IBO>();
                    BackofficeRepo = _repo;
                }
                return _repo;
            }
            set
            {
                SetValue(BackofficeRepoProperty, value);
            }
        }

        private void AutoCompleteBox_Populating(object sender, PopulatingEventArgs e)
        {
            e.Cancel = true;
            var ctrl = sender as AutoCompleteBox;
            Find(e.Parameter, (o, l) =>
            {
                ctrl.ItemsSource = l;
                ctrl.PopulateComplete();
            }, sender);
        }

        private void Find(string find, Action<object, IEnumerable<OksmCountry>> callback, object param)
        {
            var _repo = BackofficeRepo;
            AsyncHelper.Stitch((o) =>
            {
                try
                {
                    return _repo.FindOksmCountry(find);
                }
                catch
                {
                    return new List<OksmCountry>();
                }
            }
            , callback, param);
        }

        private void AutoCompleteBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems != null && e.AddedItems.Count > 0)
            {
                var cnew = e.AddedItems[0] as OksmCountry;
                var c = this.DataContext as OksmCountry;
                if (c != null)
                {
                    c.FullName = cnew.FullName;
                    c.Code = cnew.Code;
                }
                else
                {
                    c = cnew;
                    DataContext = c;
                }
            }
        }

        private void AutoCompleteBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var ctrl = sender as AutoCompleteBox;
            if(string.IsNullOrEmpty(ctrl.Text))
            {
                DataContext = null;
            }
        }
    }
}
