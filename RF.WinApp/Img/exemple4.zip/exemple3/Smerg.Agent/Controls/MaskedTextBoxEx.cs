﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Data;
using System.Windows.Threading;
using Xceed.Wpf.Toolkit;

namespace Smerg.Agent.Controls
{
    public class MaskedTextBoxEx : MaskedTextBox
    {
        public static readonly DependencyProperty SafeMaskProperty =
            DependencyProperty.Register("SafeMask", typeof(string), typeof(MaskedTextBoxEx),
            new UIPropertyMetadata(string.Empty, OnChangeSafeMask, OnCoerceSafeMask));

        private static void SafeSetMask(DependencyObject o, object value)
        {
            if (value == null)
                value = string.Empty;
            if (value.Equals(string.Empty))
            {
                value = "CCCCCCCCCCCCCCCCCCCC";
                o.SetValue(MaskedTextBox.PromptCharProperty, ' ');
            }
            else
            {
                o.SetValue(MaskedTextBox.PromptCharProperty, '_');
            }

            try
            {
                o.SetValue(MaskedTextBox.MaskProperty, value);
            }
            catch (ArgumentException ex)
            {
                if (ex.Message.StartsWith("The mask cannot be applied to the current text."))
                {
                    o.SetValue(MaskedTextBox.ValueProperty, string.Empty);
                    o.SetValue(MaskedTextBox.MaskProperty, value);

                    //UpdateSource need for place new Value to undo cache
                    //BeginInvoke need for right order changed values in undo cache: control who calls new mask setter must be first 
                    Application.Current.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        BindingOperations.GetBindingExpression(o, MaskedTextBox.ValueProperty)?.UpdateSource();
                    }), DispatcherPriority.Background);
                }
                else
                {
                    throw ex;
                }
            }
        }

        private static object OnCoerceSafeMask(DependencyObject o, object value)
        {
            SafeSetMask(o, value);
            return value;
        }
        private static void OnChangeSafeMask(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            SafeSetMask(o, e.NewValue);
        }

        public string SafeMask
        {
            get
            {
                return (string)this.GetValue(SafeMaskProperty);
            }
            set
            {
                this.SetValue(SafeMaskProperty, value);
            }
        }
    }
}
