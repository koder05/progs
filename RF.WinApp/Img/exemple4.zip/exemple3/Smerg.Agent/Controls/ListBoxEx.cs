﻿using System.Collections;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Xceed.Wpf.Toolkit;

namespace Smerg.Agent.View
{
    public class ListBoxEx : ListBox
    {
        public ListBoxEx()
        {
            SelectionChanged += ListBoxCustom_SelectionChanged;
        }

        void ListBoxCustom_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SelectedItemsList = SelectedItems;
        }

        public IList SelectedItemsList
        {
            get { return (IList)GetValue(SelectedItemsListProperty); }
            set
            {
                SetValue(SelectedItemsListProperty, null);
                if (value != null && value.Count > 0)
                    SetValue(SelectedItemsListProperty, value);
            }
        }

        public static readonly DependencyProperty SelectedItemsListProperty =
           DependencyProperty.Register("SelectedItemsList", typeof(IList), typeof(ListBoxEx), new PropertyMetadata(null));
    }
}
