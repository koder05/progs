﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.IO;
using Smerg.Agent.BL;
using RF.WinApp;

namespace Smerg.Agent
{
    internal static class Helper
    {
        public static Filestore ReadFile(string filePath)
        {
            string fileFullName = filePath;
            byte[] fileStream = File.ReadAllBytes(fileFullName);
            string fileName = Path.GetFileName(fileFullName);
            return new Filestore()
            {
                Body = fileStream,
                FileName = fileName
            };
        }

        public static void ShowFile(Filestore f)
        {
            if (f == null)
                return;

            string tempDir = Path.Combine(Path.GetTempPath(), "Regionfund", "Atlas20");
            string filePath = Path.Combine(tempDir, f.FileName);
            Directory.CreateDirectory(tempDir);

            using (MemoryStream stream = new MemoryStream(f.Body, true))
            {
                stream.Write(f.Body, 0, f.Body.Length);
                using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
                {
                    stream.WriteTo(fileStream);
                }
            }

            System.Diagnostics.Process.Start(filePath);
        }

        public static IEnumerable<T> GetChildOfType<T>(this DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    var child = VisualTreeHelper.GetChild(depObj, i);
                    var result = child as T;
                    if (result != null)
                        yield return result;
                }
            }
        }

        public static T FindChild<T>(DependencyObject parent, string childName)   where T : DependencyObject
        {
            // Confirm parent and childName are valid. 
            if (parent == null) return null;

            T foundChild = null;

            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                // If the child is not of the request child type child
                T childType = child as T;
                if (childType == null)
                {
                    // recursively drill down the tree
                    foundChild = FindChild<T>(child, childName);

                    // If the child is found, break so we do not overwrite the found child. 
                    if (foundChild != null) break;
                }
                else if (!string.IsNullOrEmpty(childName))
                {
                    var frameworkElement = child as FrameworkElement;
                    // If the child's name is set for search
                    if (frameworkElement != null && frameworkElement.Name == childName)
                    {
                        // if the child's name is of the request name
                        foundChild = (T)child;
                        break;
                    }
                }
                else
                {
                    // child element found.
                    foundChild = (T)child;
                    break;
                }
            }

            return foundChild;
        }

        public static IEnumerable<EnumViewModel<Gender>> Genders
        {
            get
            {
                return new EnumViewModel<Gender>().GetList();
            }
        }

        public static IEnumerable<object> Papers
        {
            get
            {
                return new EnumViewModel<Paper>().GetList().OrderBy(e => e.Value, new PaperComparer()).Where(vm => vm.Value == Paper.PassportRus).Select(vm => new PaperModel(vm));
            }
        }

        public static IEnumerable<EnumViewModel<StatementKind>> StatementKinds
        {
            get
            {
                return new EnumViewModel<StatementKind>().GetList().OrderBy(e => e.Value, new StatementKindComparer());
            }
        }

        public static IEnumerable<EnumViewModel<RegStatus>> RegStatuses
        {
            get
            {
                return new EnumViewModel<RegStatus>().GetList();
            }
        }

        public static IEnumerable<EnumViewModel<FileСlarification>> FileСlarifications
        {
            get
            {
                return new EnumViewModel<FileСlarification>().GetList();
            }
        }
    }
}
