﻿using System;
using System.Data.Entity;

namespace Smerg.Agent.BL.EF.SqlCe
{
    public class PersonDataRepo : Smerg.Agent.BL.EF.PersonDataRepo
    {
        public PersonDataRepo(MyDbContext db) 
            : base(db)
        {
            //need to create new sdf file when database is empty yet
            Database.SetInitializer(new DropCreateDatabaseAlways<MyDbContext>());
            //roll migrations scripts
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<MyDbContext, SqlCompactSandbox.Migrations.Configuration>());
        }
    }
}
