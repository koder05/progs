﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.IO;
using System.Windows.Navigation;
using System.Windows.Threading;
using ZipCompression;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

namespace Smerg.Launcher
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Model m = new Model();

        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = m;
        }

        public override void OnApplyTemplate()
        {
            m.status = "загрузка...";

            base.OnApplyTemplate();

            string assemblyVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString();
            m.assemblyVer = string.Format("Версия сборки {0}", assemblyVersion);
            string fileVersion = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion;
            m.prodVer = string.Format("Версия файла {0}", fileVersion);

            try
            {
                var SmergFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Smerg");

                if (!Directory.Exists(SmergFolder))
                {
                    Directory.CreateDirectory(SmergFolder);
                }

                var workFolder = string.Format("Agent-{0}-{1}", fileVersion, assemblyVersion);
                var workFullPath = Path.Combine(SmergFolder, workFolder);
                var exeFile = Path.Combine(workFullPath, "RF.WinApp.exe");

                if (!File.Exists(exeFile))
                {
                    m.status = "загрузка обновлений...";

                    var zipPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "package.zip");
                    var zipUrl = string.Format("https://s-npf1-app01:8095/fossvc/agentpackage-{0}-{1}.zip", fileVersion, assemblyVersion);

                    using (var webClient = new WebClient())
                    {
                        ServicePointManager.ServerCertificateValidationCallback += (object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) => true;
                        try
                        {
                            webClient.DownloadFile(zipUrl, zipPath);
                        }
                        catch(WebException e)
                        { }
                    }

                    ZipFile zip = ZipFile.Read(zipPath);
                    zip.ExtractAll(workFullPath, true);
                    File.Delete(zipPath);
                }

                if (!File.Exists(exeFile))
                {
                    throw new Exception("невозможно загрузить и развернуть исполняемый пакет.");
                }

                Dispatcher.UnhandledException += (sender, e) => { e.Handled = true; ShowError(e.Exception); };
                Dispatcher.BeginInvoke(new Action(() => { Launcher.Launch(exeFile); }), DispatcherPriority.Background);
            }
            catch (Exception e)
            {
                ShowError(e);
            }
        }

        private void ShowError(Exception e)
        {
            m.status = "ОШИБКА: " + e.Message;
            this.WindowStyle = WindowStyle.ToolWindow;
        }
    }
}
