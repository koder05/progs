﻿using System;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Security.Permissions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Smerg.Launcher
{
    static class Launcher
    {
        [LoaderOptimization(LoaderOptimization.MultiDomainHost)]
        [STAThread]
        public static void Launch(string exeFilePath)
        {
            string exeFileDirectory = Path.GetDirectoryName(exeFilePath);
            string exeFile = Path.GetFileName(exeFilePath);

            PermissionSet permissionSet = new PermissionSet(PermissionState.Unrestricted);
            AppDomainSetup setup = new AppDomainSetup();
            setup.ApplicationBase = exeFileDirectory;
            setup.ApplicationName = exeFile;
            setup.ConfigurationFile = exeFilePath + ".config";

            //setup.ShadowCopyFiles = "true";
            //setup.CachePath = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "lib_cache");
            //setup.ShadowCopyDirectories = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "lib_test");
            //setup.DisallowBindingRedirects = true;
            //setup.DisallowCodeDownload = true;

            AppDomain domain = AppDomain.CreateDomain(setup.ApplicationName, null/*AppDomain.CurrentDomain.Evidence*/, setup, permissionSet);
            domain.SetData("DataDirectory", Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
            domain.ExecuteAssembly(exeFilePath);
            AppDomain.Unload(domain);
            Process.GetCurrentProcess().Kill();
        }
    }
}
