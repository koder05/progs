﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Runtime.InteropServices;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.OCR;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using Emgu.Util;

namespace SqlCompactSandbox
{
    class EmguTest
    {
        public void Test()
        {
            var img = new Image<Gray, Byte>(@"C:\Temp\exmpl.tif");
            var img2 = new Mat(img.Height, img.Width, img.Mat.Depth, img.Mat.NumberOfChannels);
            int kernelSizeH = 3;
            int kernelSizeW = 33;
            try
            {
                var mat = new Mat(kernelSizeH, kernelSizeW, DepthType.Cv32F, 1);
                mat.SetTo(new MCvScalar(1 / (float)(kernelSizeH * kernelSizeW)));
                //for (var row = 0; row < mat.Height; row++)
                //{
                //    for (var col = 0; col < mat.Width; col++)
                //    {
                //        SetValue(mat, row, col, 1 / (float)(kernelSizeH * kernelSizeW));
                //    }
                //}
                CvInvoke.Filter2D(img, img2, mat, new Point(-1, -1));
            }
            catch (Exception e)
            {
                Console.Write(e);
            }

            img2.Save(@"C:\Temp\emgu.tif");
        }

        public void Test2()
        {
            var img = new Image<Gray, Byte>(@"C:\Disk_D\Distr\ScanCopy\таня_паспорт_2-3стр_400x400.tif");
            var plate = new UMat();
            UMat thresh = new UMat();
            CvInvoke.Threshold(img, plate, 125, 255, ThresholdType.Binary);
            CvInvoke.Threshold(img, thresh, 180, 255, ThresholdType.BinaryInv);
            //thresh.Save(@"C:\Temp\emgu.tif");            return;

            Size plateSize = plate.Size;
            using (var _ocr = new Emgu.CV.OCR.Tesseract(@"C:\Projects\SqlCompactSandbox\SqlCompactSandbox\bin\Debug\tessdata", "rus", OcrEngineMode.Default))
            using (Mat plateMask = new Mat(plateSize.Height, plateSize.Width, DepthType.Cv8U, 1))
            using (Mat plateCanny = new Mat())
            using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
            {
                //_ocr.SetVariable("tessedit_char_whitelist", "ЁЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮёйцукенгшщзхъфывапролджэячсмитьбю .-1234567890");

                //plateMask.SetTo(new MCvScalar(255.0));
                //CvInvoke.Canny(thresh, plateCanny, 100, 50);
                CvInvoke.FindContours(thresh, contours, null, RetrType.External, ChainApproxMethod.ChainApproxSimple);
                //int[,] hierachy = CvInvoke.FindContourTree(thresh, contours, ChainApproxMethod.ChainApproxSimple);

                int count = contours.Size;
                for (int i = 1; i < count; i++)
                {
                    using (VectorOfPoint contour = contours[i])
                    {
                        RotatedRect box = CvInvoke.MinAreaRect(contour);

                        if (box.Angle < -45.0)
                        {
                            float tmp = box.Size.Width;
                            box.Size.Width = box.Size.Height;
                            box.Size.Height = tmp;
                            box.Angle += 90.0f;
                        }
                        else if (box.Angle > 45.0)
                        {
                            float tmp = box.Size.Width;
                            box.Size.Width = box.Size.Height;
                            box.Size.Height = tmp;
                            box.Angle -= 90.0f;
                        }


                        double whRatio = (double)box.Size.Width / box.Size.Height;
                        if (1.2 < whRatio)
                            continue;

                        //Rectangle rect = box.MinAreaRect();
                        Rectangle rect = CvInvoke.BoundingRectangle(contour);
                        if (rect.Height > 10
                            //&& ((box.Angle > 45 && box.Angle <= 90) || (box.Angle < -45 && box.Angle >= -90))
                            )
                        {
                            rect.X -= 1; rect.Y -= 1; rect.Width += 2; rect.Height += 2;


                            PointF[] srcCorners = box.GetVertices();
                            PointF[] destCorners = new PointF[] {
                                    new PointF(0, box.Size.Height - 1),
                                    new PointF(0, 0),
                                    new PointF(box.Size.Width - 1, 0),
                                    new PointF(box.Size.Width - 1, box.Size.Height - 1)};

                            using (Mat rot = CvInvoke.GetAffineTransform(srcCorners, destCorners))
                            {
                                CvInvoke.WarpAffine(plate, plateCanny, rot, Size.Round(box.Size));
                            }

                            Size approxSize = new Size(240, 180);
                            double scale = Math.Min(approxSize.Width / box.Size.Width, approxSize.Height / box.Size.Height);
                            Size newSize = new Size((int)Math.Round(box.Size.Width * scale), (int)Math.Round(box.Size.Height * scale));

                            using (var tmp2 = new UMat())
                            {
                                CvInvoke.Resize(plateCanny, tmp2, newSize, 0, 0, Inter.Cubic);
                                tmp2.Save(string.Format(@"C:\Temp\emgu\charImg\emgu{0}.tif", i));
                                //int edgePixelSize = 2;
                                //Rectangle newRoi = new Rectangle(new Point(edgePixelSize, edgePixelSize), tmp2.Size - new Size(2 * edgePixelSize, 2 * edgePixelSize));

                                try

                                {

                                    //using (UMat charImg = new UMat(tmp2, newRoi))
                                    //{
                                    //    charImg.Save(string.Format(@"C:\Temp\emgu\charImg\emgu{0}.tif", i));

                                    Emgu.CV.OCR.Tesseract.Character[] words;
                                    using (UMat tmp = tmp2.Clone())
                                    {
                                        _ocr.SetImage(tmp);
                                        _ocr.Recognize();
                                        words = _ocr.GetCharacters();

                                        if (words.Length == 0) continue; else Console.WriteLine(string.Format(@"C:\Temp\emgu\charImg\emgu{0}.tif", i));

                                        for (int k = 0; k < words.Length; k++)
                                        {
                                            //    strBuilder.Append(words[k].Text);
                                            Console.Write(words[k].Text);
                                        }

                                        Console.ReadLine();
                                        //Console.WriteLine();
                                    }

                                    //}
                                }
                                catch (Exception e)
                                {
                                    System.Diagnostics.Debug.WriteLine(e);

                                }
                            }

                            //Rectangle roi = new Rectangle(Point.Empty, plate.Size);
                            //rect.Intersect(roi);
                            //CvInvoke.Rectangle(plate, rect, new MCvScalar(), 1);

                            //var rect_points = box.GetVertices();
                            //for (int j = 0; j < 4; j++) CvInvoke.Line(plate, new Point(rect_points[j].X, rect_points[j].Y), rect_points[(j + 1) % 4], new MCvScalar(), 1);

                        }
                    }
                }

                //plateMask.Save(@"C:\Temp\emgu.tif");

                //thresh.SetTo(new MCvScalar(), plateMask);
            }

            //CvInvoke.Erode(thresh, thresh, null, new Point(-1, -1), 1, BorderType.Constant, CvInvoke.MorphologyDefaultBorderValue);
            //CvInvoke.Dilate(thresh, thresh, null, new Point(-1, -1), 1, BorderType.Constant, CvInvoke.MorphologyDefaultBorderValue);
            //thresh.Save(@"C:\Temp\emgu.tif");
            plate.Save(@"C:\Temp\emgu.tif");
        }

        public void Test3()
        {
            try
            {
                //var model1 = new Mat(@"C:\TEMP\Emgu\model1.tif");
                //var model2 = new Mat(@"C:\TEMP\Emgu\model2.tif");
                //var modeln = new Mat(@"C:\TEMP\Emgu\model_num.tif");
                var model = new Mat(@"C:\TEMP\Emgu\model.tif");

                //var sample = new Mat(@"C:\TEMP\Emgu\женя_паспорт_2-3стр.tif", ImreadModes.Grayscale);
                //CvInvoke.Threshold(sample, sample, 160, 255, ThresholdType.Binary);
                //sample.Save(@"C:\TEMP\Emgu\женя_паспорт_2-3стр_threshold.tif");
                //return;

                //var sample = new Mat(@"C:\TEMP\Emgu\таня_паспорт_2-3стр.tif");
                var sample = new Mat(@"C:\TEMP\Emgu\таня_паспорт_2-3стр_400x400.tif");
                //sample._EqualizeHist();
                //sample.Save(@"C:\TEMP\Emgu\sample.tif");
                long ticks;

                //EmguSURF.Draw(model1, sample, out i).Save(@"C:\TEMP\Emgu\surf1.tif");
                //EmguSURF.Draw(model2, sample, out i).Save(@"C:\TEMP\Emgu\surf2.tif");
                //EmguSURF.Draw(modeln, sample, out i).Save(@"C:\TEMP\Emgu\surfn.tif");
                var src = EmguSURF.Draw(model, sample, out ticks);
                var srcimg = src.ToImage<Gray, Byte>();
                //srcimg._EqualizeHist();
                srcimg.Save(@"C:\TEMP\Emgu\surf.tif");

                return;

                using (var mask = new Mat(@"C:\TEMP\Emgu\mask1.bmp", ImreadModes.Grayscale))
                //using (var mask1 = mask.Reshape(1))
                using (Mat result = new Mat(mask.Height, mask.Width, DepthType.Cv8U, 1))
                {
                    using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
                    {
                        CvInvoke.FindContours(mask, contours, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);
                        int count = contours.Size;
                        if (count > 1)
                        {
                            using (VectorOfPoint contour = contours[0])
                            {
                                Rectangle rect = CvInvoke.BoundingRectangle(contour);
                                //CvInvoke.Rectangle(result, rect, new MCvScalar(255, 0, 0, 255), 1);

                                var issuerArea1 = new Rectangle(340, 230, 1434, 110);
                                var issuerArea2 = new Rectangle(120, 330, 1658, 110);
                                var issuerArea3 = new Rectangle(120, 430, 1658, 110);

                                using (UMat charImg = new UMat(srcimg.Mat.GetUMat(AccessType.Read), rect))
                                using (var _ocr = new Emgu.CV.OCR.Tesseract(@"C:\Projects\SqlCompactSandbox\SqlCompactSandbox\bin\Debug\tessdata", "rus", OcrEngineMode.Default))
                                {
                                    CvInvoke.Threshold(charImg, charImg, 150, 255, ThresholdType.Binary);
                                    charImg.Save(@"C:\TEMP\Emgu\result1.jpg");
                                    Emgu.CV.OCR.Tesseract.Character[] words;
                                    using (UMat tmp = charImg.Clone())
                                    {
                                        _ocr.SetImage(tmp);
                                        _ocr.Recognize();
                                        words = _ocr.GetCharacters();
                                        for (int k = 0; k < words.Length; k++)
                                        {
                                            Console.Write(words[k].Text);
                                        }
                                        Console.WriteLine();
                                    }
                                }
                            }
                        }
                    }

                    //result.Save(@"C:\TEMP\Emgu\result1.jpg");
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e);
            }

        }

        public void TestCert()
        {
            try
            {
                var area = new Rectangle(723 - 50, 1024 + 18 - 50, 1165 - 723 + 100, 1110 - 1024 - 18 + 100);
                var model = new Mat(@"C:\TEMP\Emgu\Cert\CertModel.png");
                //var sample = new Mat(@"C:\TEMP\Emgu\Cert\CertSampleSign.png");
                //var sample = new Mat(@"C:\TEMP\Emgu\Cert\IMG_0935.JPG");
                var sample = new Image<Gray, Byte>(@"C:\TEMP\Emgu\Cert\IMG_0284.jpg");
                CvInvoke.Threshold(sample, sample, 110, 255, ThresholdType.Binary);
                long ticks;
                var src = EmguSURF.Draw(model, sample.Mat, out ticks);
                //src.Save(@"C:\TEMP\Emgu\Cert\surf.tif");

                CvInvoke.GaussianBlur(src, src, new Size(13, 13), 1.5, 1);

                CvInvoke.Canny(src, src, 75, 200);
                //CvInvoke.BitwiseNot(sample, sample);
                src.Save(@"C:\TEMP\Emgu\Cert\src.tif");
                //return;





                //LineSegment2D[] lines = CvInvoke.HoughLinesP(src,
                //    1, //Distance resolution in pixel-related units
                //    Math.PI / 45.0, //Angle resolution measured in radians.
                //    20, //threshold
                //    30, //min Line width
                //    10); //gap between lines

                //List<RotatedRect> boxList = new List<RotatedRect>(); //a box is a rotated rectangle
                //using (Mat result = new Mat(sample.Height, sample.Width, DepthType.Cv8U, 1))
                //{
                //    using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
                //    {
                //        CvInvoke.FindContours(sample, contours, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);
                //        int count = contours.Size;
                //        for (int i = 0; i < count; i++)
                //        {
                //            using (VectorOfPoint contour = contours[i])
                //            {
                //                //Rectangle rect = CvInvoke.BoundingRectangle(contour);
                //                //CvInvoke.Rectangle(result, rect, new MCvScalar(255, 0, 0, 255), 1);
                //                using (VectorOfPoint approxContour = new VectorOfPoint())
                //                {
                //                    CvInvoke.ApproxPolyDP(contour, approxContour, CvInvoke.ArcLength(contour, true) * 0.05, true);
                //                    if (CvInvoke.ContourArea(approxContour, false) > 50) //only consider contours with area greater than 250
                //                    {
                //                        if (approxContour.Size == 4) //The contour has 4 vertices.
                //                        {
                //                            #region determine if all the angles in the contour are within [80, 100] degree
                //                            bool isRectangle = true;
                //                            Point[] pts = approxContour.ToArray();
                //                            LineSegment2D[] edges = PointCollection.PolyLine(pts, true);
                //                            for (int j = 0; j < edges.Length; j++)
                //                            {
                //                                double angle = Math.Abs(edges[(j + 1) % edges.Length].GetExteriorAngleDegree(edges[j]));
                //                                if (angle < 80 || angle > 100)
                //                                {
                //                                    isRectangle = false;
                //                                    break;
                //                                }
                //                            }
                //                            #endregion

                //                            if (isRectangle) boxList.Add(CvInvoke.MinAreaRect(approxContour));
                //                        }
                //                    }
                //                }
                //            }
                //        }
                //    }

                //    //    foreach (var l in lines)
                //    //    {
                //    //        CvInvoke.Line(result
                //    //            , l.P1
                //    //            , l.P2
                //    //            , new MCvScalar(255, 0, 0, 255)
                //    //            , 1);
                //    //    }

                //    //foreach (var r in boxList)
                //    //{
                //    //    var rect_points = r.GetVertices();
                //    //    for (int j = 0; j < 4; j++)
                //    //        CvInvoke.Line(result
                //    //            , new Point((int)rect_points[j].X, (int)rect_points[j].Y)
                //    //            , new Point((int)rect_points[(j + 1) % 4].X, (int)rect_points[(j + 1) % 4].Y)
                //    //            , new MCvScalar(255, 255, 255, 255)
                //    //            , 1);
                //    //}

                //    result.Save(@"C:\TEMP\Emgu\Cert\contours.tif");
                //}


                

                using (UMat areaImg = new UMat(src.GetUMat(AccessType.Read), area))
                {
                    areaImg.Save(@"C:\TEMP\Emgu\Cert\area.tif");

                    using (Mat result = new Mat(areaImg.Bitmap.Height, areaImg.Bitmap.Width, DepthType.Cv8U, 1))
                    {
                        var res = new Bitmap(areaImg.Bitmap.Width, areaImg.Bitmap.Height);
                        res.SetResolution(areaImg.Bitmap.HorizontalResolution, areaImg.Bitmap.VerticalResolution);
                        //CvInvoke.BitwiseNot(result, result);
                        //using (Graphics gg = Graphics.FromImage(result.ToImage<Bgr, Byte>().Bitmap))
                        using (Graphics gg = Graphics.FromImage(res))
                        {
                            using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
                            {
                                CvInvoke.FindContours(areaImg, contours, null, RetrType.List, ChainApproxMethod.LinkRuns);
                                int count = contours.Size;
                                var list = new List<Rectangle>();
                                for (int i = 0; i < count; i++)
                                {
                                    using (VectorOfPoint contour = contours[i])
                                    {
                                        Rectangle rect = CvInvoke.BoundingRectangle(contour);

                                        var aspect = rect.Width > rect.Height ? rect.Width / rect.Height : rect.Height / rect.Width;
                                        if (aspect > 2 && (rect.Width < 10 || rect.Height < 10 || (rect.Width >= res.Width - 5 && rect.Height >= res.Height - 5)))
                                        {
                                            //gg.DrawRectangle(new Pen(Color.Black, 1), rect);
                                        }
                                        else
                                        {
                                            list.Add(rect);
                                        }
                                        gg.DrawRectangle(new Pen(Color.Black, 1), rect);
                                    }
                                }

                                foreach(var rr in list.OrderByDescending(r => r.Width * r.Height).Take(1))
                                {
                                    using (UMat a = new UMat(areaImg, rr))
                                    {
                                        //gg.DrawImage(a.Bitmap, rr.Left, rr.Top);
                                        //gg.DrawRectangle(new Pen(Color.Yellow, 1), rr);

                                        if (rr.Width > 300)
                                        {
                                            //gg.DrawRectangle(new Pen(Color.Black, 1), rect);
                                        }
                                        else
                                        {
                                            //gg.DrawImage(a.Bitmap, rect.Left, rect.Top);
                                            //gg.DrawRectangle(new Pen(Color.Black, 1), rect);
                                        }
                                    }

                                }
                            }
                        }


                        res.Save(@"C:\TEMP\Emgu\Cert\res.tif");

                        //using (Graphics g = Graphics.FromImage(model.Bitmap))
                        //{
                        //g.DrawImage(res, 723, 1024 + 18);
                        //model.Save(@"C:\TEMP\Emgu\Cert\res.tif");
                        //}

                    }
                }

            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e);
            }

        }

        public void Test4()
        {
            try
            {
                //var sample = new Image<Gray, Byte>(@"C:\TEMP\Emgu\Cert\IMG_0936_rot.JPG");
                var sample = new Image<Gray, Byte>(@"C:\TEMP\Emgu\Cert\CertSampleSign.png");
                CvInvoke.Threshold(sample, sample, 110, 255, ThresholdType.Binary);
                var hpxpermm = sample.Height / 297;
                var wpxpermm = sample.Width / 210;
                //CvInvoke.BitwiseNot(sample, sample);
                sample.Save(@"C:\TEMP\Emgu\Cert\src.tif");
                using (Mat result = DrowContours(sample.Mat, wpxpermm, hpxpermm))
                {
                    using (var r = DrowContours(result, wpxpermm, hpxpermm))
                        r.Save(@"C:\TEMP\Emgu\Cert\res.tif");
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e);
            }
        }

        public Mat DrowContours(Mat src, int wpxpermm, int hpxpermm)
        {
            try
            {
                Mat result = new Mat(src.Height, src.Width, DepthType.Cv8U, 1);
                CvInvoke.BitwiseNot(result, result);
                using (Mat r = new Mat(src.Height, src.Width, DepthType.Cv8U, 1))
                {
                    CvInvoke.BitwiseNot(r, r);
                    using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
                    {
                        CvInvoke.FindContours(src, contours, null, RetrType.Ccomp, ChainApproxMethod.ChainApproxSimple);
                        int count = contours.Size;
                        for (int i = 0; i < count; i++)
                        {
                            using (VectorOfPoint contour = contours[i])
                            {
                                Rectangle rect = CvInvoke.BoundingRectangle(contour);

                                if (Pix2Mm(rect.Top, hpxpermm) > 160)
                                {
                                    CvInvoke.Rectangle(result, rect, new MCvScalar(), 1);
                                    if (Pix2Mm(rect.Width, wpxpermm) > 60 && Pix2Mm(rect.Height, hpxpermm) > 9 && Pix2Mm(rect.Height, hpxpermm) < 20 && Pix2Mm(rect.Width, wpxpermm) < 90)
                                    {
                                        CvInvoke.Rectangle(r, rect, new MCvScalar(), 1);
                                    }
                                }
                            }
                        }
                    }
                    r.Save(@"C:\TEMP\Emgu\Cert\res2.tif");
                }
                result.Save(@"C:\TEMP\Emgu\Cert\res.tif");
                return result;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e);
                return null;
            }
        }

        private static int Pix2Mm(int pix,int pxpermm)
        {
            return (int)Math.Round((double)pix / pxpermm);
        }

        private static void SetValue(Mat mat, int row, int col, dynamic value)
        {
            var target = CreateElement(mat.Depth, value);
            Marshal.Copy(target, 0, mat.DataPointer + (row * mat.Cols + col) * mat.ElementSize, 1);
        }

        private static dynamic CreateElement(DepthType depthType, dynamic value)
        {
            return new float[1] { value };
        }
    }
}
