﻿using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace PgProxy
{
    public class AsyncService
    {
        private IPAddress ipAddress;
        private int port;
        public AsyncService(int port)
        {
            this.port = port;
            string hostName = Dns.GetHostName();
            IPHostEntry ipHostInfo = Dns.GetHostEntry(hostName);
            //IPHostEntry ipHostInfo = Dns.GetHostEntry("localhost");
            this.ipAddress = null;
            for (int i = 0; i < ipHostInfo.AddressList.Length; ++i)
            {
                if (ipHostInfo.AddressList[i].AddressFamily == AddressFamily.InterNetwork)
                {
                    this.ipAddress = ipHostInfo.AddressList[i];
                    break;
                }
            }
            if (this.ipAddress == null)
                throw new Exception("No IPv4 address for server");
        }

        public async void Run()
        {
            TcpListener listener = new TcpListener(this.ipAddress, this.port);
            listener.Start();
            Console.WriteLine(string.Format("Service on {0}:{1} is running at {2:yyyy-MM-dd HH:mm:ss}", this.ipAddress, this.port, DateTime.Now));
            Console.WriteLine("Hit <enter> to stop service\n");
            while (true)
            {
                try
                {
                    TcpClient tcpClient = await listener.AcceptTcpClientAsync().ConfigureAwait(false);
                    Process(tcpClient);
                    //ThreadPool.QueueUserWorkItem(Process, tcpClient);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Run: " + ex.Message);
                }
            }
        }

        private static async void Process(object par)
        {
            var tcpClient = (TcpClient)par;
            try
            {
                using (NetworkStream networkStream = tcpClient.GetStream())
                {
                    await new PgProto(networkStream).Talk();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Process: " + ex.Message);
            }
            finally
            {
                if (tcpClient.Connected)
                    tcpClient.Close();
            }
        }
    }
}
