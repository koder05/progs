﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy
{
    public interface IStoreProc
    {
        IEnumerable<object> Execute(PgParams connectionParams);

        void AddParam(object val);

        Type ReturnType { get; }

        bool LongTaskSupport { get; }
    }
}
