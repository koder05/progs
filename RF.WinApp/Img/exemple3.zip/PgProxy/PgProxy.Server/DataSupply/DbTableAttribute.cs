using System;

namespace PgProxy
{
	[AttributeUsage(AttributeTargets.Class)]
	public class DbTableAttribute : Attribute
	{
		private string m_TableName = "";
		private string m_IdColumnName = "";
		private string m_KeyColumnName = "";
		private string m_ViewName = "";
		private string m_SelectFullObject = "";

		public DbTableAttribute(string tableName, string idColumn)
		{
			this.m_TableName = tableName;
			this.m_IdColumnName = idColumn;
		}

		public string TableName
		{
			get { return this.m_TableName; }
		}

		public string IdColumnName
		{
			get { return this.m_IdColumnName; }
		}

		public string KeyColumnName
		{
			get { return this.m_KeyColumnName; }
			set { this.m_KeyColumnName = value; }
		}

		public string ViewName
		{
			get { return this.m_ViewName; }
			set { this.m_ViewName = value; }
		}

		public string SelectFullObject
		{
			get { return this.m_SelectFullObject; }
			set { this.m_SelectFullObject = value; }
		}
	}
}