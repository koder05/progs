﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy
{
    public interface ITable
    {
        Type RowType { get; }
        IEnumerable<object> Data();
        string Name { get; }
    }
}
