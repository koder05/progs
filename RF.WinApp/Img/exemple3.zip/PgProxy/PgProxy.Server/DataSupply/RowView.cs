﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using PgProxy.Data;

namespace PgProxy
{
    internal class RowView : DataCollector
    {
        public RowView()
        {
            var dp = DataProperty.Register(PgProxy.SysDb.PgTypeTable.ItemPointerInfo.typname, PgProxy.SysDb.PgTypeTable.ItemPointerInfo.nettype);
            var randomValue = Guid.NewGuid().ToByteArray();
            //SetValue(dp, string.Format("({0},{1})", randomValue[0], randomValue[1]));
            SetValue(dp, new PgProxy.SysDb.TidType() { Row = randomValue[0], Page = randomValue[1] });
        }

        public RowView(object row, string tablePrefix = null) : this()
        {
            var rowType = row.GetType();
            this.RowTypeDescription = rowType.Name;
            foreach (var prop in rowType.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly))
            {
                var propName = tablePrefix == null ? prop.Name : string.Format("{0}.{1}", tablePrefix, prop.Name);
                var dp = DataProperty.Register(propName, prop.PropertyType);
                SetValue(dp, prop.GetValue(row));
            }
        }

        public string RowTypeDescription { get; private set; }

        public object this[string name]
        {
            get
            {
                var isCompositeName = name.Contains('.');
                foreach (var dp in GetCollection)
                {
                    var dpName = isCompositeName == false && dp.Name.Contains('.') ? dp.Name.Split('.')[1] : dp.Name;
                    if (dpName.Equals(name, StringComparison.InvariantCultureIgnoreCase))
                    {
                        return GetValue(dp);
                    }
                }

                return null;
            }
        }

        public RowView Join(RowView r)
        {
            var ret = new RowView();

            foreach (var dp in this.GetCollection)
            {
                ret.SetValue(dp, this.GetValue(dp));
            }

            foreach (var dp in r.GetCollection)
            {
                ret.SetValue(dp, r.GetValue(dp));
            }

            ret.RowTypeDescription = string.Format("{0}+{1}", this.RowTypeDescription, r.RowTypeDescription);
            return ret;
        }
    }
}
