﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

using PgProxy.SysDb;
using RF.Common.DI;
using RF.Common.Logging;
using Ms.Unity._2;

namespace PgProxy
{
    public static class DataService
    {
        public static IDataDescriptor External { get; set; }

        public static ITable FindTable(string name)
        {
            var tabtypes = from x in Assembly.GetAssembly(typeof(ITable)).GetTypes()
                         where !x.IsAbstract && !x.IsInterface && typeof(ITable).IsAssignableFrom(x)
                         select x;

            var tabtype = tabtypes.FirstOrDefault(t =>
                t.CustomAttributes.Any(a => a.AttributeType == typeof(DbTableAttribute) && a.ConstructorArguments[0].Value.ToString().Equals(name, StringComparison.InvariantCultureIgnoreCase)));

            if (tabtype == null)
            {
                if (External != null)
                    return External.FindTable(name);

                throw new PgException("42P01", string.Format("Table was not found '{0}'", name));
            }

            var ds = (ITable)Activator.CreateInstance(tabtype);

            if (ds == null)
                throw new InvalidOperationException(string.Format("Table was not initialized '{0}'", name));

            return ds;
        }

        public static IStoreProc FindProc(string name)
        {
            switch (name)
            {
                case "pg_client_encoding":
                    return new PgClientEncoding();
                case "session_id":
                    return new SessionId();
                case "progress_lookup":
                    return new ProgressLookup();
                case "longtask_cancel":
                    return new LongTaskCancel();
            }

            if (External != null)
                return External.FindProc(name);

            throw new PgException("42P01", string.Format("Store procedure was not found '{0}'", name));
        }

        public static IEnumerable<PgClass> Tables()
        {
            var ret = PgClassTable.Rows;
            if (External != null)
                ret = ret.Union(External.Tables());
            return ret;
        }

        public static IEnumerable<PgAttribute> Columns()
        {
            var ret = PgAttributeTable.Rows;
            if (External != null)
                ret = ret.Union(External.Columns());
            return ret;
        }

        public static void Init()
        {
            IContainerWrapper ioc = new UnityContainerWrapper();
            IoC.InitializeWith(ioc);
            DataService.External = IoC.Resolve<IDataDescriptor>();
            Logs.Service = IoC.Resolve<LogService>();

            AppDomain.CurrentDomain.UnhandledException += (s, e) => {
                
                Console.WriteLine(string.Format("UnhandledException {1:yyyy-MM-ddTHH:mm:ss} {0}", e.ExceptionObject));
            }; 

            TaskScheduler.UnobservedTaskException += (object sender, UnobservedTaskExceptionEventArgs e) =>
            {
                e.SetObserved();
                Console.WriteLine(string.Format("UnobservedTaskException {1:yyyy-MM-ddTHH:mm:ss} {0}", e.Exception.InnerException));
                //throw e.Exception;

            };
        }
    }
}
