﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PgProxy.SysDb;

namespace PgProxy
{
    public interface IDataDescriptor
    {
        ITable FindTable(string name);

        IStoreProc FindProc(string name);

        IEnumerable<PgClass> Tables();

        IEnumerable<PgAttribute> Columns();
    }
}
