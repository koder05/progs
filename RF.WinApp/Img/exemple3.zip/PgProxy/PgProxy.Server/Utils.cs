﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace PgProxy
{
    public static class Utils
    {
        public static void ClearBuff(byte[] data)
        {
            for (var i = 0; i < data.Length; i++)
                data[i] = 0;
        }

        public static int Int32FromBytes(byte[] data, int startIndex)
        {
            int value = data[startIndex];

            for (int i = 1; i < 4; i++)
            {
                value <<= 8;
                value |= data[i + startIndex];
            }

            return value;
        }

        public static short Int16FromBytes(byte[] data, int startIndex)
        {
            int value = data[startIndex];
            value <<= 8;
            value |= data[1 + startIndex];
            return (short)value;
        }

        public static string UTF8FromBytes(byte[] data, int startIndex, int len = 0)
        {
            bool endSimbolIsFound = false;
            int i = startIndex;
            int end = len > 0 ? startIndex + len : data.Length;
            while (i < end)
            {
                if (data[i] == 0)
                {
                    endSimbolIsFound = true;
                    break;
                }
                i++;
            }

            if (endSimbolIsFound)
                return Encoding.UTF8.GetString(data, startIndex, i - startIndex + 1).TrimEnd('\0');

            throw new InvalidCastException("UTF8FromBytes not found string");
        }

        /// <summary>
        /// Int32 to bytes array (rightbegin)
        /// </summary>
        /// <param name="value">value int32</param>
        /// <param name="buffer">byte array</param>
        /// <param name="startIndex">start position</param>
        public static int Int32ToBytes(int value, byte[] buffer, int startIndex)
        {
            buffer[startIndex + 3] = (byte)value;
            buffer[startIndex + 2] = (byte)(value >> 8);
            buffer[startIndex + 1] = (byte)(value >> 0x10);
            buffer[startIndex + 0] = (byte)(value >> 0x18);
            return 4;
        }

        public static int Int16ToBytes(int value, byte[] buffer, int startIndex)
        {
            buffer[startIndex + 1] = (byte)value;
            buffer[startIndex + 0] = (byte)(value >> 8);
            return 2;
        }

        public static int UTF8ToBytes(string value, byte[] buffer, int startIndex)
        {
            var s = Encoding.UTF8.GetBytes(value);
            for (var i = 0; i < s.Length; i++)
            {
                buffer[startIndex + i] = s[i];
            }
            return s.Length;
        }

        public static int UTF8WithLenToBytes(string value, byte[] buffer, int startIndex)
        {
            var slen = Utils.UTF8ToBytes(value, buffer, startIndex + 4);
            return Utils.Int32ToBytes(slen, buffer, startIndex) + slen;
        }

        private static object TryParse(string input)
        {
            if (input.Equals("NULL", StringComparison.InvariantCultureIgnoreCase))
                return DBNull.Value;
            if (input.Equals("f", StringComparison.InvariantCultureIgnoreCase))
                return false;
            if (input.Equals("t", StringComparison.InvariantCultureIgnoreCase))
                return true;

            var expectedTypes = new List<Type> { typeof(DateTime), typeof(double), typeof(decimal), typeof(int), typeof(bool) };
            foreach (var type in expectedTypes)
            {
                TypeConverter converter = TypeDescriptor.GetConverter(type);
                if (converter.CanConvertFrom(typeof(string)))
                {
                    try
                    {
                        object newValue = converter.ConvertFromInvariantString(input);
                        if (newValue != null)
                        {
                            return newValue;
                        }
                    }
                    catch
                    {
                        continue;
                    }
                }
            }

            return input;
        }

        public static object TryParse(string input, Type targetType)
        {
            try
            {
                if (targetType == null)
                    return TryParse(input);
                return TypeDescriptor.GetConverter(targetType).ConvertFromString(input);
            }
            catch
            {
                return null;
            }
        }

        public static void DebugTest(string sql)
        {
            var queryHandler = new Query(new PgParams());
            queryHandler.Parse(sql);
        }
    }
}
