﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Runtime.Remoting.Messaging;
using RF.Common.Logging;
using PgProxy.SysDb;

namespace PgProxy
{
    public class ProgressLog : ILogLauncher
    {
        private ILogger l = new ProgressLogger();

        public ILogger GetLogApp()
        {
            return l;
        }

        public ILogger GetLogDb()
        {
            throw new NotImplementedException();
        }

        public ILogger GetLogErr()
        {
            throw new NotImplementedException();
        }

        public ILogger GetLogUser()
        {
            throw new NotImplementedException();
        }
    }

    public class ProgressLogger : ILogger
    {
        public void Log(object o, string message, string eventType)
        {
            string sessionId = CallContext.LogicalGetData(PgParams.PgSessionTlsKey) as string;
            if (string.IsNullOrEmpty(sessionId) == false)
            {
                LongTask task = LongTaskTable.Get(sessionId);
                if (task != null)
                    task.progress = message;
            }

            //Console.Write(string.Format("ProgressLogger : sessionId={0} message={1} who={2}", sessionId, message, eventType));
        }
    }
}
