﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy
{
    public class PgException : Exception
    {
        public string PgSqlStateCode { get; private set; }

        public PgException(string pgSqlStateCode, string message) : base(message)
        {
            this.PgSqlStateCode = pgSqlStateCode;
        }
    }
}
