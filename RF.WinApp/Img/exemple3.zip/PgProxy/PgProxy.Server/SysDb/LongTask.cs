﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;

namespace PgProxy.SysDb
{
    public class LongTask
    {
        public string taskid { get; set; }
        public string progress { get; set; }
        internal DateTime starttime { get; set; }
        internal CancellationTokenSource canceltoken { get; set; }

        public int elapsedtime
        {
            get
            {
                return (int)(DateTime.Now - starttime).TotalSeconds;
            }

        }
    }

    [DbTable(TableName, "taskid")]
    public class LongTaskTable : ITable
    {
        public const string TableName = "longtask";

        public string Name { get { return TableName; } }

        public Type RowType
        {
            get { return typeof(LongTask); }
        }

        public IEnumerable<object> Data()
        {
            return Store.Values; 
        }

        private static ConcurrentDictionary<string, LongTask> Store = new ConcurrentDictionary<string, LongTask>();

        public static LongTask Get(string taskId)
        {
            LongTask ret = null;
            if(string.IsNullOrEmpty(taskId) == false)
                Store.TryGetValue(taskId, out ret);
            return ret;
        }

        public static void Add(LongTask task)
        {
            Store.TryAdd(task.taskid, task); 
        }

        public static void Remove(string taskId)
        {
            LongTask task;
            Store.TryRemove(taskId, out task); 
        }
    }

    public class LongTaskCancel : IStoreProc
    {
        public Type ReturnType
        {
            get
            {
                return null;
            }
        }

        public bool LongTaskSupport
        {
            get
            {
                return false;
            }
        }

        private string taskId;
        public void AddParam(object val)
        {
            if (val != null)
            {
                taskId = val.ToString();
            }
        }

        public IEnumerable<object> Execute(PgParams connectionParams)
        {
            var task = LongTaskTable.Get(taskId);
            if (task != null)
            {
                Console.WriteLine(string.Format("Try stop long task: {0} on {1}", taskId, connectionParams?.SessionId));
                task.canceltoken.Cancel();
            }
            else
            {
                Console.WriteLine(string.Format("Try stop long task: {0} on {1}. Task not found.", taskId, connectionParams?.SessionId));
            }

            return null;
        }
    }
}