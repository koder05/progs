﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.SysDb
{
    public class SessionId : IStoreProc
    {
        public Type ReturnType
        {
            get
            {
                return typeof(string);
            }
        }

        public void AddParam(object val)
        {
        }

        public IEnumerable<object> Execute(PgParams connectionParams)
        {
            return new string[] { connectionParams.SessionId };
        }

        public bool LongTaskSupport
        {
            get
            {
                return false;
            }
        }
    }
}
