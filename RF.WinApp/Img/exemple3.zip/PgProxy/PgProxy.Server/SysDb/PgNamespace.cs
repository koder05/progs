﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.SysDb
{
    public class PgNamespace
    {
        public int oid { get; set; }
        public string nspname { get; set; }
        public int nspowner { get; set; }
    }

    [DbTable(PgNamespaceTable.TableName, "oid")]
    public class PgNamespaceTable : ITable
    {
        public const string TableName = "pg_namespace";

        public string Name { get { return PgNamespaceTable.TableName; } }

        public Type RowType
        {
            get { return typeof(PgNamespace); }
        }

        public IEnumerable<object> Data()
        {
            return new PgNamespace[]
            {
                new PgNamespace {oid = 11, nspname="pg_catalog", nspowner=10 },
                new PgNamespace {oid = 2200, nspname="public", nspowner=10 }
            };
        }
    }
}