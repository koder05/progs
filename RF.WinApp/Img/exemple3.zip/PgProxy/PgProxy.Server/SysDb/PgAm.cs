﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.SysDb
{
    public class PgAm
    {
        public int oid { get; set; }
        public string amname { get; set; }
    }

    [DbTable(PgAmTable.TableName, "oid")]
    public class PgAmTable : ITable
    {
        public const string TableName = "pg_am";

        public string Name { get { return PgAmTable.TableName; } }

        public Type RowType
        {
            get { return typeof(PgAm); }
        }

        public IEnumerable<object> Data()
        {
            return new PgAm[]
            {
            };
        }
    }
}
