﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.SysDb
{
    public class PgUser
    {
        public string usename { get; set; }
        public int usesysid { get; set; }
    }

    [DbTable(PgUserTable.TableName, "oid")]
    public class PgUserTable : ITable
    {
        public const string TableName = "pg_user";

        public string Name { get { return PgUserTable.TableName; } }

        public Type RowType
        {
            get { return typeof(PgUser); }
        }

        public IEnumerable<object> Data()
        {
            return new PgUser[]
            {
                new PgUser() {usename="postgres", usesysid=10},
                new PgUser() {usename="sa", usesysid=0}
            };
        }
    }
}
