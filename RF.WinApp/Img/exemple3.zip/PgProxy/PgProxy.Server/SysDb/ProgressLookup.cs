﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace PgProxy.SysDb
{
    public class ProgressLookup : IStoreProc
    {
        public Type ReturnType
        {
            get
            {
                return typeof(LongTask);
            }
        }

        public bool LongTaskSupport
        {
            get
            {
                return false;
            }
        }

        private string sessionId;
        private bool sessionIdLoaded;
        private string prevProgress;
        private bool prevProgressLoaded;
        public void AddParam(object val)
        {
            if (val != null)
            {
                if (!sessionIdLoaded)
                {
                    sessionId = val.ToString();
                    sessionIdLoaded = true;
                }
                else
                {
                    if (!prevProgressLoaded)
                    {
                        prevProgress = val.ToString();
                        prevProgressLoaded = true;
                    }
                }
            }
        }

        public IEnumerable<object> Execute(PgParams connectionParams)
        {
            int counter = 0;
            var task = LongTaskTable.Get(sessionId);
            while ((task == null || task.progress == this.prevProgress) && counter < 10)
            {
                Thread.Sleep(500);
                task = LongTaskTable.Get(sessionId);
                counter++;
            }

            if(task != null)
            {
                Console.WriteLine(string.Format("Try get ProgressLookup: {0} on {1}", task.taskid, connectionParams?.SessionId));
                return new object[] { task };
            }
            else
            {
                Console.WriteLine(string.Format("Try stop long task: counter={0} on {1}", counter, connectionParams?.SessionId));
            }

            return null;
        }
    }
}
