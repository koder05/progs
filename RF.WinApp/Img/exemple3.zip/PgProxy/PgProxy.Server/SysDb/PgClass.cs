﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.SysDb
{
    public class PgClass
    {
        public int oid { get; set; }
        public string relname { get; set; }
        public char relkind { get; set; }
        public int relowner { get; set; }
        public bool relhasrules { get; set; }
        public bool relhasoids { get; set; }
        public int relam { get; set; }
        public int relnamespace { get; set; }
    }

    [DbTable(PgClassTable.TableName, "oid")]
    public class PgClassTable : ITable
    {
        public const string TableName = "pg_class";

        public static IEnumerable<PgClass> Rows = new PgClass[]
            {
                new PgClass() {oid=1247, relname=PgTypeTable.TableName, relkind='r', relowner=0, relhasoids=true, relnamespace = 11 },
                new PgClass() {oid=1259, relname=PgClassTable.TableName, relkind='r', relowner=0, relhasoids=true, relnamespace = 11},
                new PgClass() {oid=11063, relname=PgUserTable.TableName, relkind='v', relowner=0, relnamespace = 11},
                new PgClass() {oid=1249, relname=PgAttributeTable.TableName, relkind='r', relowner=0, relnamespace = 11},
                new PgClass() {oid=2601, relname=PgAmTable.TableName, relkind='r', relowner=0, relhasoids=true, relnamespace = 11},
                new PgClass() {oid=2610, relname=PgIndexTable.TableName, relkind='r', relowner=0, relnamespace = 11},
                new PgClass() {oid=1, relname=LongTaskTable.TableName, relkind='r', relowner=0, relnamespace = 11},
                new PgClass() {oid=2615, relname=PgNamespaceTable.TableName, relkind='r', relowner=0, relhasoids=true, relnamespace = 11}
            };

        public string Name { get { return PgClassTable.TableName; } }

        public Type RowType
        {
            get { return typeof(PgClass); }
        }

        public IEnumerable<object> Data()
        {
            return DataService.Tables();
        }
    }
}
