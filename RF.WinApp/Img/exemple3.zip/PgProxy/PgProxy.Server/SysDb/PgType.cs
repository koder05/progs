﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Collections;

namespace PgProxy.SysDb
{
    public class TidType
    {
        public int Row { get; set; }

        public short Page { get; set; }

        public override string ToString()
        {
            return string.Format("({0},{1})", Page, Row);
        }
    }

    public class PgType
    {
        public int oid { get; set; }
        public int typbasetype { get; set; }
        public string typname { get; set; }
        public int typlen { get; set; }
        public Type nettype { get; set; }
    }

    [DbTable(PgTypeTable.TableName, "oid")]
    public class PgTypeTable : ITable
    {
        public const string TableName = "pg_type";
        public static PgType ItemPointerInfo = new PgType() { oid = 27, typbasetype = 0, typname = "ctid", typlen = 6, nettype = typeof(TidType) };

        public string Name { get { return PgTypeTable.TableName; } }

        public Type RowType
        {
            get { return typeof(PgType); }
        }

        public IEnumerable<object> Data()
        {
            return Rows;
        }

        public static IEnumerable<PgType> Rows = new PgType[]
        {
                new PgType() {oid=26, typbasetype=0, typname="oid", typlen=4, nettype=typeof(int)}
                , new PgType() {oid=23, typbasetype=0, typname="int4", typlen=4, nettype=typeof(int)}
                , new PgType() {oid=21, typbasetype=0, typname="int2", typlen=2, nettype=typeof(Int16)}
                , new PgType() {oid=19, typbasetype=0, typname="name", typlen=-1, nettype=typeof(string)}
                , new PgType() {oid=16, typbasetype=0, typname="bool", typlen=1, nettype=typeof(bool)}
                , new PgType() {oid=18, typbasetype=0, typname="char", typlen=1, nettype=typeof(char)}
                , ItemPointerInfo
                , new PgType() {oid=22, typbasetype=0, typname="int2vector", typlen=-1, nettype=typeof(Int16[])}
                , new PgType() {oid=1043, typbasetype=0, typname="varchar", typlen=-1, nettype=typeof(string)}
                , new PgType() {oid=1114, typbasetype=0, typname="timestamp", typlen=8, nettype=typeof(DateTime)}
        };

    }
}
