﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.SysDb
{
    public class PgAttribute
    {
        public int attrelid { get; set; }
        public string attname { get; set; }
        public int atttypid { get; set; }
        public int attlen { get; set; }
        public int attnum { get; set; }
        public int atttypmod { get; set; }
        public bool attnotnull { get; set; }
    }

    [DbTable(PgAttributeTable.TableName, "attrelid")]
    public class PgAttributeTable : ITable
    {
        public const string TableName = "pg_attribute";

        public string Name { get { return PgAttributeTable.TableName; } }

        public Type RowType
        {
            get { return typeof(PgAttribute); }
        }

        public IEnumerable<object> Data()
        {
            return DataService.Columns();
        }

        public static IEnumerable<PgAttribute> Rows = new PgAttribute[]
            {
                //pg_am
                new PgAttribute() {attrelid=2601, attname="oid", atttypid=26, attlen=4, attnum=-2, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=2601, attname="amname", atttypid=19, attlen=64, attnum=1, atttypmod=-1, attnotnull=true},
                
                //pg_type
                new PgAttribute() {attrelid=1247, attname="oid", atttypid=26, attlen=4, attnum=-2, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1247, attname="typbasetype", atttypid=26, attlen=4, attnum=24, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1247, attname="typname", atttypid=19, attlen=64, attnum=1, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1247, attname="typlen", atttypid=21, attlen=2, attnum=4, atttypmod=-1, attnotnull=true},
                //pg_class
                new PgAttribute() {attrelid=1259, attname="oid", atttypid=26, attlen=4, attnum=-2, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1259, attname="relnamespace", atttypid=26, attlen=4, attnum=2, atttypmod=-1, attnotnull=false},
                new PgAttribute() {attrelid=1259, attname="relname", atttypid=19, attlen=64, attnum=1, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1259, attname="relkind", atttypid=18, attlen=1, attnum=17, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1259, attname="relowner", atttypid=26, attlen=4, attnum=5, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1259, attname="relhasrules", atttypid=16, attlen=1, attnum=22, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1259, attname="relhasoids", atttypid=16, attlen=1, attnum=23, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1259, attname="relam", atttypid=26, attlen=4, attnum=24, atttypmod=-1, attnotnull=false},
                
                //pg_user
                new PgAttribute() {attrelid=11063, attname="usesysid", atttypid=26, attlen=4, attnum=2, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=11063, attname="usename", atttypid=19, attlen=64, attnum=1, atttypmod=-1, attnotnull=true},
                //pg_attribute
                new PgAttribute() {attrelid=1249, attname="attrelid", atttypid=26, attlen=4, attnum=1, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1249, attname="attname", atttypid=19, attlen=64, attnum=2, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1249, attname="atttypid", atttypid=26, attlen=4, attnum=3, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1249, attname="attlen", atttypid=21, attlen=2, attnum=5, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1249, attname="attnum", atttypid=21, attlen=2, attnum=6, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1249, attname="atttypmod", atttypid=23, attlen=4, attnum=9, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1249, attname="attnotnull", atttypid=16, attlen=1, attnum=13, atttypmod=-1, attnotnull=true},

                //pg_index
                new PgAttribute() {attrelid=2610, attname="indexrelid", atttypid=26, attlen=4, attnum=1, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=2610, attname="indrelid", atttypid=26, attlen=4, attnum=2, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=2610, attname="indisunique", atttypid=16, attlen=1, attnum=4, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=2610, attname="indisprimary", atttypid=16, attlen=1, attnum=5, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=2610, attname="indisclustered", atttypid=16, attlen=1, attnum=8, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=2610, attname="indkey", atttypid=22, attlen=-1, attnum=13, atttypmod=-1, attnotnull=true},

                new PgAttribute() {attrelid=1, attname="taskid", atttypid=19, attlen=64, attnum=1, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1, attname="progress", atttypid=19, attlen=64, attnum=2, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1, attname="elapsedtime", atttypid=23, attlen=4, attnum=3, atttypmod=-1, attnotnull=true},

                //pg_namespace
                new PgAttribute() {attrelid=2615, attname="oid", atttypid=26, attlen=4, attnum=-2, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=2615, attname="nspname", atttypid=19, attlen=64, attnum=1, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=2615, attname="nspowner", atttypid=26, attlen=4, attnum=5, atttypmod=-1, attnotnull=true}
            };
    }
}
