﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.SysDb
{
    public class PgIndex
    {
        public int indexrelid { get; set; }
        public int indrelid { get; set; }
        public bool indisunique { get; set; }
        public bool indisprimary { get; set; }
        public bool indisclustered { get; set; }
        public Int16[] indkey { get; set; }
    }

    [DbTable(PgIndexTable.TableName, "indexrelid")]
    public class PgIndexTable : ITable
    {
        public const string TableName = "pg_index";

        public string Name { get { return PgIndexTable.TableName; } }

        public Type RowType
        {
            get { return typeof(PgIndex); }
        }

        public IEnumerable<object> Data()
        {
            return new PgIndex[]
            {

            };
        }
    }
}
