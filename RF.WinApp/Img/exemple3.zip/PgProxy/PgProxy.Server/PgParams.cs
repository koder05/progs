﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy
{
    public class PgParams
    {
        public const string PgSessionTlsKey = "PgSessionTlsKey";
        public string User { get; set;  }
        public string DataBase { get; set; }

        public string SessionId { get; set; }

        public static PgParams ParseConnectionParams(string connStartup)
        {
            var ret = new PgParams();
            string[] pg_params = connStartup.Split('\0');
            for(var i=0; i<pg_params.Count(); i+=2)
            {
                if (pg_params[i] == "user")
                    ret.User = pg_params[i + 1];
                if (pg_params[i] == "database")
                    ret.DataBase = pg_params[i + 1];
            }

            ret.SessionId = Guid.NewGuid().ToString();

            return ret; 
        }
    }
}
