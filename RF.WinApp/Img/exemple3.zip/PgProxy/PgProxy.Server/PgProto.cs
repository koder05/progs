﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Net.Sockets;
using PgProxy.SysDb;

namespace PgProxy
{
    public class PgProto
    {
        private const string NamelessOperatorId = "Nameless_operator";
        private NetworkStream s;
        private byte[] inbuff = new byte[1024];
        private byte[] outbuff = new byte[1024];
        private PgParams pg_params;
        private Dictionary<string, Query> namedQueries = new Dictionary<string, Query>();
        private CancellationTokenSource talkCancellation = new CancellationTokenSource();

        public PgProto(NetworkStream networkStream)
        {
            s = networkStream;
        }

        public async Task Talk()
        {
            await StartupMessage();
            Console.WriteLine(string.Format("Start Talk: {0} on {1}", this.pg_params?.SessionId, DateTime.Now));
            await AuthenticationCleartextPassword();
            var msg = await PasswordMessage();
            if (msg == "Temp123")
            {
                await AuthenticationOK();
                await BackendKeyData();
                await ReadyForQuery();

                using (talkCancellation = new CancellationTokenSource())
                {
                    //using (talkCancellation.Token.Register(() => s.Close()))
                    //{
                    while (!talkCancellation.IsCancellationRequested)
                    {
                        Utils.ClearBuff(inbuff);
                        var len = await s.ReadAsync(inbuff, 0, inbuff.Length, talkCancellation.Token);
                        if (len > 0)
                            await Response(inbuff.Take(len).ToArray());
                    }
                    //}
                }
            }
            else
            {
                await ErrorResponse(new PgException("28000", "invalid_authorization_specification"));
            }
            Console.WriteLine(string.Format("Close Talk: {0} on {1}", this.pg_params?.SessionId, DateTime.Now));
            s.Close();
        }

        private async Task Response(byte[] request)
        {
            var pos = 0;
            var len = request.Length;
            while (pos < len && len > 0)
            {
                try
                {
                    var qcode = Encoding.ASCII.GetString(request, pos, 1);
                    System.Diagnostics.Debug.Print(string.Format("Income command = {0} ({1})", qcode, this.pg_params));
                    pos++;

                    switch (qcode)
                    {
                        case "Q": pos = await Query(pos, request); break;
                        case "P": pos = await Parse(pos, request); break;
                        case "B": pos = await Bind(pos, request); break;
                        case "D": pos = await Describe(pos, request); break;
                        case "E": pos = await Execute(pos, request); break;
                        case "S": pos = await Sync(pos, request); break;
                        case "C": pos = await Close(pos, request); break;
                        case "X":
                            talkCancellation.Cancel(); break;
                        default:
                            pos = len;
                            break;
                    }
                }
                catch (PgException pgex)
                {
                    await ErrorResponse(pgex);
                }
                catch (Exception e)
                {
                    await ErrorResponse(new PgException("58000", (e.InnerException ?? e).Message));
                }
            }
        }

        private async Task StartupMessage()
        {
            var len = await s.ReadAsync(inbuff, 0, inbuff.Length);
            var i = Utils.Int32FromBytes(inbuff, 0);
            var msg = Encoding.UTF8.GetString(inbuff, 8, i - 8);
            pg_params = PgParams.ParseConnectionParams(msg);
        }

        private async Task AuthenticationCleartextPassword()
        {
            outbuff[0] = Encoding.ASCII.GetBytes("R")[0];
            Utils.Int32ToBytes(8, outbuff, 1);
            Utils.Int32ToBytes(3, outbuff, 5);
            await s.WriteAsync(outbuff, 0, 9);
        }

        private async Task<string> PasswordMessage()
        {
            var len = await s.ReadAsync(inbuff, 0, inbuff.Length);
            var msg = Encoding.ASCII.GetString(inbuff, 0, 1);
            var i = Utils.Int32FromBytes(inbuff, 1);
            msg = Utils.UTF8FromBytes(inbuff, 5, i - 4);
            return msg;
        }

        private async Task AuthenticationOK()
        {
            outbuff[0] = Encoding.ASCII.GetBytes("R")[0];
            Utils.Int32ToBytes(8, outbuff, 1);
            Utils.Int32ToBytes(0, outbuff, 5);
            await s.WriteAsync(outbuff, 0, 9);
        }

        private async Task BackendKeyData()
        {
            outbuff[0] = Encoding.ASCII.GetBytes("K")[0];
            Utils.Int32ToBytes(12, outbuff, 1);
            Utils.Int32ToBytes(0, outbuff, 5);
            Utils.Int32ToBytes(0, outbuff, 9);
            await s.WriteAsync(outbuff, 0, 13);
        }

        private async Task ReadyForQuery()
        {
            outbuff[0] = Encoding.ASCII.GetBytes("Z")[0];
            Utils.Int32ToBytes(5, outbuff, 1);
            outbuff[5] = Encoding.ASCII.GetBytes("I")[0];
            await s.WriteAsync(outbuff, 0, 6);
        }

        private async Task<int> Query(int pos, byte[] request)
        {
            var len = Utils.Int32FromBytes(request, pos);
            var msg = Utils.UTF8FromBytes(request, pos + 4, len - 4);
            //Console.WriteLine(msg);
            var queryHandler = new Query(pg_params);
            if (queryHandler.Parse(msg))
            {
                queryHandler.Bind();
                queryHandler.Execute(0);
                await RowDescription(queryHandler);
                msg = await DataRow(queryHandler);
            }
            else if (queryHandler.FirstInstruction == "DEALLOCATE")
            {
                msg = "DEALLOCATE";
            }
            else if (queryHandler.FirstInstruction == "SET")
            {
                msg = "SET";
            }
            await CommandComplete(msg);
            await ReadyForQuery();
            return pos + len;
        }

        private async Task<int> Parse(int pos, byte[] request)
        {
            var len = Utils.Int32FromBytes(request, pos);
            pos += 4;
            var opName = Utils.UTF8FromBytes(request, pos, len - 4);
            pos += opName.Length + 1;
            //Console.WriteLine(string.Format("Parse: Operator name = {0}", opName));
            var sql = Utils.UTF8FromBytes(request, pos, len - (4 + opName.Length + 1));
            pos += sql.Length + 1;

            var paramsTypesCount = Utils.Int16FromBytes(request, pos);
            pos += 2;
            int[] paramsTypesArray = new int[paramsTypesCount];
            for (var i = 0; i < paramsTypesCount; i++)
            {
                paramsTypesArray[i] = Utils.Int32FromBytes(request, pos);
                pos += 4;
            }

            var queryHandler = new Query(pg_params);
            queryHandler.Parse(sql);

            queryHandler.BindParamTypes(paramsTypesArray);

            if (string.IsNullOrEmpty(opName))
                opName = NamelessOperatorId;

            if (namedQueries.ContainsKey(opName) == false)
                namedQueries.Add(opName, null);

            namedQueries[opName] = queryHandler;

            //ParseComplete
            outbuff[0] = Encoding.UTF8.GetBytes("1")[0];
            Utils.Int32ToBytes(4, outbuff, 1);
            await s.WriteAsync(outbuff, 0, 5);

            return pos;
        }

        private async Task<int> Bind(int pos, byte[] request)
        {
            var len = Utils.Int32FromBytes(request, pos);
            var ret = pos + len;
            pos += 4;
            var portalName = Utils.UTF8FromBytes(request, pos, len - 4);
            pos += portalName.Length + 1;
            //Console.WriteLine(string.Format("Bind: Portal name = {0}", portalName));
            var opName = Utils.UTF8FromBytes(request, pos, len - (4 + portalName.Length + 1));
            pos += opName.Length + 1;
            //Console.WriteLine(string.Format("Bind: Parsed operatror name = {0}", opName));

            if (string.IsNullOrEmpty(opName))
                opName = NamelessOperatorId;

            if (namedQueries.ContainsKey(opName) == false)
                throw new PgException("42P14", string.Format("Portal '{0}' not exists", opName));

            var query = namedQueries[opName];

            var paramsFormatCodesCount = Utils.Int16FromBytes(request, pos);
            pos += 2;
            short[] paramsFormatCodesArray = new short[paramsFormatCodesCount];
            for (var i = 0; i < paramsFormatCodesCount; i++)
            {
                paramsFormatCodesArray[i] = Utils.Int16FromBytes(request, pos);
                pos += 2;
            }
            query.BindParamFormats(paramsFormatCodesArray);

            var paramsValuesCount = Utils.Int16FromBytes(request, pos);
            pos += 2;
            for (var i = 0; i < paramsValuesCount; i++)
            {
                var valLen = Math.Max(0, Utils.Int32FromBytes(request, pos));
                pos += 4;
                query.BindParamBytes(request.Skip(pos).Take(valLen).ToArray());
                pos += Math.Max(0, valLen);
            }

            var rowsFormatCodesCount = Utils.Int16FromBytes(request, pos);
            pos += 2;
            short[] rowsFormatCodesArray = new short[rowsFormatCodesCount];
            for (var i = 0; i < rowsFormatCodesCount; i++)
            {
                rowsFormatCodesArray[i] = Utils.Int16FromBytes(request, pos);
                pos += 2;
            }
            query.SelectPart.BindRowFormats(rowsFormatCodesArray);
            query.Bind();

            //BindComplete
            outbuff[0] = Encoding.ASCII.GetBytes("2")[0];
            Utils.Int32ToBytes(4, outbuff, 1);
            await s.WriteAsync(outbuff, 0, 5);
            return ret;
        }

        private async Task<int> Describe(int pos, byte[] request)
        {
            var len = Utils.Int32FromBytes(request, pos);
            pos += 4;
            var code = Encoding.UTF8.GetString(request, pos, 1);
            pos++;
            var name = Utils.UTF8FromBytes(request, pos, len - 5);
            pos += name.Length + 1;

            if (string.IsNullOrEmpty(name))
                name = NamelessOperatorId;

            var query = namedQueries[name];

            if (code == "S")
            {
                //ParameterDescription
                outbuff[0] = Encoding.ASCII.GetBytes("t")[0];
                len = 5;
                len += Utils.Int16ToBytes(query.ParamsCount, outbuff, len);
                for (var i = 0; i < query.ParamsCount; i++)
                    len += Utils.Int32ToBytes(26, outbuff, len);
                Utils.Int32ToBytes(len - 1, outbuff, 1);
                await s.WriteAsync(outbuff, 0, len);
            }

            //RowDescription
            await RowDescription(query);

            return pos;
        }

        private async Task<int> Execute(int pos, byte[] request)
        {
            var len = Utils.Int32FromBytes(request, pos);
            var ret = pos + len;
            pos += 4;
            var name = Utils.UTF8FromBytes(request, pos, len - 4);
            pos += name.Length + 1;

            if (string.IsNullOrEmpty(name))
                name = NamelessOperatorId;

            if (namedQueries.ContainsKey(name))
            {
                var query = namedQueries[name];
                int take = Utils.Int32FromBytes(request, pos);
                pos += 4;

                var queryRes = query.Execute(take);
                var msg = await DataRow(query);

                if (queryRes)
                {
                    //CommandComplete
                    await CommandComplete(msg);
                }
                else
                {
                    //PortalSuspended
                    outbuff[0] = Encoding.ASCII.GetBytes("s")[0];
                    Utils.Int32ToBytes(4, outbuff, 1);
                    await s.WriteAsync(outbuff, 0, 5);
                }
            }
            return ret;
        }

        private async Task<int> Sync(int pos, byte[] request)
        {
            var len = Utils.Int32FromBytes(request, pos);
            await ReadyForQuery();
            return request.Length;
        }

        private async Task NoData()
        {
            outbuff[0] = Encoding.UTF8.GetBytes("n")[0];
            Utils.Int32ToBytes(4, outbuff, 1);
            await s.WriteAsync(outbuff, 0, 5);
        }

        private async Task<int> PrintMessage(int pos, byte[] request)
        {
            var code = Utils.UTF8FromBytes(request, pos);
            Console.WriteLine(string.Format("Unknown message: {0}", code));
            await Task.Delay(1);
            return pos + code.Length + 1;
        }

        private async Task<int> Close(int pos, byte[] request)
        {
            var len = Utils.Int32FromBytes(request, pos);
            pos += 4;
            var code = Encoding.UTF8.GetString(request, pos, 1);
            pos++;
            var name = Utils.UTF8FromBytes(request, pos, len - 5);
            pos += name.Length + 1;

            if (namedQueries.ContainsKey(name))
            {
                if (code == "S")
                {
                    //Close operator
                    namedQueries.Remove(name);
                }

                if (code == "P")
                {
                    //close portal
                    namedQueries[name].Unbind();
                }

                //CloseComplete
                outbuff[0] = Encoding.ASCII.GetBytes("3")[0];
                Utils.Int32ToBytes(4, outbuff, 1);
                await s.WriteAsync(outbuff, 0, 5);
            }

            return pos;
        }

        private async Task CommandComplete(string completeMsg)
        {
            outbuff[0] = Encoding.ASCII.GetBytes("C")[0];
            var len = completeMsg.Length + 5;
            Utils.Int32ToBytes(len, outbuff, 1);
            Utils.UTF8ToBytes(completeMsg + "\0", outbuff, 5);
            await s.WriteAsync(outbuff, 0, 1 + len);
        }

        private async Task RowDescription(Query queryHandler)
        {
            if (queryHandler.SelectPart.SelectList == null || queryHandler.SelectPart.SelectList.Count() == 0)
            {
                await NoData();
            }
            else
            {
                var pgClass = DataService.Tables().ToList();
                var pgAtt = DataService.Columns().ToList();
                var pgTyp = PgTypeTable.Rows.ToList();
                outbuff[0] = Encoding.ASCII.GetBytes("T")[0];
                var len = 5;
                len += Utils.Int16ToBytes(queryHandler.SelectPart.SelectList.Count(), outbuff, len);
                foreach (var sel in queryHandler.SelectPart.SelectList)
                {
                    //имя столбца
                    len += Utils.UTF8ToBytes((string.IsNullOrEmpty(sel.AsName) ? sel.SelfName : sel.AsName) + "\0", outbuff, len);

                    //Console.WriteLine(string.Format("Column {0}", (string.IsNullOrEmpty(sel.AsName) ? sel.SelfName : sel.AsName)));

                    //id таблицы
                    var t = pgClass.FirstOrDefault(r => r.relname.Equals(
                        (sel as PgProxy.QueryParser.QueryField)?.Table?.TableName
                        , StringComparison.InvariantCultureIgnoreCase));
                    len += Utils.Int32ToBytes(t?.oid ?? 0, outbuff, len);

                    //id столбца
                    var c = pgAtt.FirstOrDefault(r => r.attrelid == (t?.oid ?? 0) && r.attname == sel.SelfName);
                    len += Utils.Int16ToBytes(c?.attnum ?? 0, outbuff, len);

                    //тип данных
                    var dt = pgTyp.FirstOrDefault(r => r.oid == (c?.atttypid ?? 0));
                    if (dt == null && sel.ValueType != null)
                        dt = pgTyp.FirstOrDefault(r => r.nettype == sel.ValueType);
                    if (dt == null && sel.SelfName == PgTypeTable.ItemPointerInfo.typname)
                        dt = PgTypeTable.ItemPointerInfo;

                    len += Utils.Int32ToBytes(dt?.oid ?? 23, outbuff, len);
                    len += Utils.Int16ToBytes(dt?.typlen ?? 4, outbuff, len);
                    len += Utils.Int32ToBytes(c?.atttypmod ?? -1, outbuff, len);

                    //код формата
                    len += Utils.Int16ToBytes(queryHandler.SelectPart.FormatCode, outbuff, len);
                }
                Utils.Int32ToBytes(len - 1, outbuff, 1);
                await s.WriteAsync(outbuff, 0, len);
            }
        }

        private async Task<string> DataRow(Query queryHandler)
        {
            foreach (var data in queryHandler.Data)
            {
                var len = 5;
                outbuff[0] = Encoding.ASCII.GetBytes("D")[0];

                len += Utils.Int16ToBytes(queryHandler.SelectPart.SelectList.Count(), outbuff, len);

                foreach (var sel in queryHandler.SelectPart.SelectList)
                {
                    //длина и значение столбца
                    var o = sel.Eval(data);
                    if (o == null || o == DBNull.Value)
                    {
                        len += Utils.Int32ToBytes(-1, outbuff, len);
                        //Console.WriteLine(string.Format("{0} = NULL", sel.QueryName));
                    }
                    else
                    {
                        string oval = o.GetType() == typeof(bool) ? ((bool)o ? "t" : "f") : o.ToString();
                        if (queryHandler.SelectPart.FormatCode == 0)
                        {
                            len += Utils.UTF8WithLenToBytes(oval, outbuff, len);
                        }
                        else
                        {
                            if (sel.ValueType == typeof(TidType))
                            {
                                len += Utils.Int32ToBytes(6, outbuff, len);
                                len += Utils.Int16ToBytes(((TidType)o).Page, outbuff, len);
                                len += Utils.Int32ToBytes(((TidType)o).Row, outbuff, len);
                            }
                            else if (sel.ValueType == typeof(int))
                            {
                                len += Utils.Int32ToBytes(4, outbuff, len);
                                len += Utils.Int32ToBytes((int)o, outbuff, len);
                            }
                            else
                            {
                                len += Utils.UTF8WithLenToBytes(oval, outbuff, len);
                            }
                        }
                        //Console.WriteLine(string.Format("{0} = {1}", sel.SelfName, oval));
                    }
                }
                Utils.Int32ToBytes(len - 1, outbuff, 1);
                await s.WriteAsync(outbuff, 0, len);
            }

            return string.Format("SELECT {0}", queryHandler.Data.Count());
        }

        private async Task ErrorResponse(PgException ex)
        {
            outbuff[0] = Encoding.ASCII.GetBytes("E")[0];
            var len = 5;
            outbuff[len++] = Encoding.ASCII.GetBytes("S")[0];
            len += Utils.UTF8ToBytes("ERROR", outbuff, len);
            outbuff[len++] = Encoding.ASCII.GetBytes("C")[0];
            len += Utils.UTF8ToBytes(ex.PgSqlStateCode, outbuff, len);
            outbuff[len++] = Encoding.ASCII.GetBytes("M")[0];
            len += Utils.UTF8ToBytes(ex.Message, outbuff, len);
            len += Utils.Int32ToBytes(0, outbuff, len);
            Utils.Int32ToBytes(len - 1, outbuff, 1);
            await s.WriteAsync(outbuff, 0, len);
            talkCancellation.Cancel(true);
        }
    }
}
