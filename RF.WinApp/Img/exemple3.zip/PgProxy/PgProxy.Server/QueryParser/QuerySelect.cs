﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.QueryParser
{
    internal class QuerySelect : QueryPart
    {
        public List<QueryOperand> SelectList { get; private set; }

        public short FormatCode
        {
            get
            {
                if (rowFormats.Length > 0)
                    return rowFormats[0];
                return 0;
            }
        }

        public QuerySelect()
        {
            SelectList = new List<QueryOperand>();
        }


        private short[] rowFormats;
        public void BindRowFormats(short[] array)
        {
            rowFormats = array;
        }

        protected override IEnumerable<RowView> BuildPart(IEnumerable<RowView> queryResult)
        {
            if(queryResult == null && SelectList.Any(qs => qs is QueryValue))
                return new RowView[] { new RowView() };
            return queryResult;
        }

        protected override void SetOwner()
        {
            base.SetOwner();
            foreach (var par in SelectList)
            {
                par.Owner = this;
            }
        }
    }
}
