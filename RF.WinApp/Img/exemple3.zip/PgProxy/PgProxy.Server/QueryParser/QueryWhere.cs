﻿using System;
using System.Collections.Generic;
using PgProxy.SysDb;
using System.Linq.Expressions;
using RF.LinqExt;

namespace PgProxy.QueryParser
{
    internal class QueryWhere : QueryPart
    {
        public IEnumerable<QueryConditionExpr> Condition { get; private set; }

        public QueryWhere(IEnumerable<QueryConditionExpr> cond)
        {
            Condition = cond;
        }

        protected override void SetOwner()
        {
            base.SetOwner();
            foreach(var cond in Condition)
            {
                cond.Left.Owner = this;
                cond.Right.Owner = this;
            }
        }

        protected override IEnumerable<RowView> BuildPart(IEnumerable<RowView> queryResult)
        {
            FilterParameterCollection fc = new FilterParameterCollection();
            foreach(var c in this.Condition)
            {
                var operand = c.Left as QueryField ?? c.Right as QueryField;
                var val = c.Left as QueryValue ?? c.Right as QueryValue;
                if (operand != null && val != null)
                {
                    var n = operand.FullName;
                    fc.Add(n, val.Value, c.Op, c.IsOr ? "OrGroup1" : string.Empty);
                }
            }

            return queryResult.Filtering<RowView>(fc, new RowViewPropResolver(), new RowViewOperatorResolver());
        }
    }

    internal class RowViewPropResolver : IFilterSortPropResolver
    {
        public IEnumerable<LambdaExpression> FindResolution(Type sourceType, Type destType, ListControlActionType actionType, string memberName)
        {
            var ret = new List<Expression<Func<RowView, object>>>();
            ret.Add(o => o[memberName]);

            //var ret = new List<LambdaExpression>();
            //ret.Add(GetResolution(memberName));
            return ret;
        }

        public LambdaExpression GetResolution(string memberName)
        {
            ParameterExpression mainObject = Expression.Parameter(typeof(RowView), "obj");
            //Expression<Func<RowView, ConstantExpression>> expr = o => o.GetResolution(memberName);
            Expression<Func<RowView, object>> expr2 = o => o[memberName];
            
            var expr3 = Expression.Invoke(expr2, mainObject);
            //new ConstantModifier().Visit(expr2);
            //return Expression.Lambda(Expression.Convert(expr3, t));
            return Expression.Lambda(expr3);
        }
    }
    
    public class RowViewOperatorResolver : DefaultFilterOperatorResolver
    {
        public override Expression FindResolution(OperatorType op, Expression prop, Expression val)
        {
            var expr = Expression.Convert(prop, val.Type);
            return base.FindResolution(op, expr, val);
        }
    }
}

