﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SqlServer.Management.SqlParser.Parser;

namespace PgProxy.QueryParser
{
    internal class ParserFrom
    {
        private FirstApproxTree fromTree = null;

        public List<QueryDS> Tables { get; private set; }
        public List<ParserCondition> JoinConditions { get; private set; }

        public ParserFrom(FirstApproxTree from)
        {
            this.fromTree = from;
            Tables = new List<QueryDS>();
            JoinConditions = new List<ParserCondition>();
        }

        public void Parse()
        {
            ExtractDS();
            foreach (var p in JoinConditions)
            {
                //p.Parse(this.Tables);
            }
        }

        private void ExtractDS()
        {
            QueryDS ds = null;
            var canMove = !fromTree.BOF && !fromTree.EOF;
            var haveJoin = false;
            while (canMove && fromTree.CurrentToken.Token == Tokens.TOKEN_ID)
            {
                ds = new QueryDS(fromTree.CurrentToken.Sql);
                canMove = fromTree.Next();
                if (canMove)
                {
                    if (fromTree.CurrentToken.Token == Tokens.TOKEN_ID)
                    {
                        ds.Acronym = fromTree.CurrentToken.Sql;
                        canMove = fromTree.Next();
                    }
                    else if (fromTree.CurrentToken.Token == Tokens.TOKEN_AS)
                    {
                        canMove = fromTree.Next();
                        if (canMove && fromTree.CurrentToken.Token == Tokens.TOKEN_ID)
                        {
                            ds.Acronym = fromTree.CurrentToken.Sql;
                            canMove = fromTree.Next();
                        }
                    }
                }
                this.Tables.Add(ds);

                if (canMove && (int)fromTree.CurrentToken.Token == 44/*","*/)
                {
                    canMove = fromTree.Next();
                    continue;
                }

                if (canMove && haveJoin && fromTree.CurrentToken.Token == Tokens.TOKEN_ON)
                {
                    //to do parse ON
                    canMove = fromTree.Next();
                    if (canMove)
                    {
                        var pos = Math.Min(fromTree.FindTokenPos(Tokens.TOKEN_INNER, fromTree.CurrentPos), fromTree.FindTokenPos(Tokens.TOKEN_JOIN, fromTree.CurrentPos));
                        var onTree = fromTree.Extract(fromTree.CurrentPos, pos - 1);
                        var onCondition = new ParserCondition(onTree);
                        onCondition.Parse(this.Tables);
                        JoinConditions.Add(onCondition);
                        canMove = fromTree.MoveTo(fromTree.CurrentPos + onTree.CurrentPos);
                        //canMove = !fromTree.BOF && !fromTree.EOF;
                        haveJoin = false;
                    }
                }

                if (canMove && fromTree.CurrentToken.Token == Tokens.TOKEN_INNER)
                {
                    canMove = fromTree.Next();
                }

                if (canMove && fromTree.CurrentToken.Token == Tokens.TOKEN_JOIN)
                {
                    canMove = fromTree.Next();
                    haveJoin = true;
                }
            } //while
        }
    }
}
