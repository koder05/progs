﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.QueryParser
{
    internal abstract class QueryOperand
    {
        public bool IsParsedSuccess { get; protected set; }

        /// <summary>
        /// Operand name in select list after "AS" token
        /// </summary>
        public string AsName { get; set; }

        /// <summary>
        /// Operand name in query without "."
        /// </summary>
        public string SelfName { get; set; }

        /// <summary>
        /// Type of operand value
        /// </summary>
        public Type ValueType { get; set; }

        /// <summary>
        /// Parsed query part who contains operand
        /// </summary>
        public QueryPart Owner { get; set; }

        public abstract object Eval(RowView data);

        protected abstract bool DoParse(FirstApproxTree tree);

        protected void Parse(FirstApproxTree tree)
        {
            var beginPos = tree.CurrentPos;
            IsParsedSuccess = DoParse(tree);
            if (!IsParsedSuccess)
                tree.MoveTo(beginPos);
        }

        public static QueryOperand Parse(FirstApproxTree tree, List<QueryDS> foundDs)
        {
            QueryOperand ret = new QueryParam();
            ret.Parse(tree);
            if (ret.IsParsedSuccess)
                return ret;

            ret = new QueryValue();
            ret.Parse(tree);
            if (ret.IsParsedSuccess)
                return ret;

            ret = new QueryFoo();
            ret.Parse(tree);
            if (ret.IsParsedSuccess)
                return ret;

            ret = new QueryField(foundDs);
            ret.Parse(tree);
            if (ret.IsParsedSuccess)
                return ret;

            return null; 
        }
    }
}
