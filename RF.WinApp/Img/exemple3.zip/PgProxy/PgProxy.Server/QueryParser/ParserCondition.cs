﻿using System;
using System.Collections.Generic;
using System.Linq;
using RF.LinqExt;
using Microsoft.SqlServer.Management.SqlParser.Parser;

namespace PgProxy.QueryParser
{
    internal class ParserCondition
    {
        private FirstApproxTree tree = null;
        public List<QueryConditionExpr> Conditions = new List<QueryConditionExpr>();

        public ParserCondition(FirstApproxTree cond)
        {
            this.tree = cond;
            if (!tree.BOF && !tree.EOF && tree.CurrentToken.Token == Tokens.TOKEN_WHERE)
                tree.Next();
        }

        public void Parse(List<QueryDS> tList)
        {
            var canMove = !tree.BOF && !tree.EOF;
            var scopes = 0;
            var isOr = false;
            while (canMove)
            {
                while (canMove && (int)tree.CurrentToken.Token == 40 /*'('*/)
                {
                    scopes++;
                    canMove = tree.Next();
                }

                var c = new QueryConditionExpr();
                c.Left = QueryOperand.Parse(tree, tList);

                canMove = !tree.BOF && !tree.EOF;

                if (canMove && OperatorTokens.ContainsKey((int)tree.CurrentToken.Token))
                {
                    c.Op = OperatorTokens[(int)tree.CurrentToken.Token];
                    c.IsOr = isOr;
                    canMove = tree.Next();

                    c.Right = QueryOperand.Parse(tree, tList);
                    canMove = !tree.BOF && !tree.EOF;
                    Conditions.Add(c);
                    while (canMove && (int)tree.CurrentToken.Token == 41 /*')'*/)
                    {
                        scopes--;
                        canMove = tree.Next();
                    }
                    canMove = !tree.BOF && !tree.EOF && (tree.CurrentToken.Token == Tokens.TOKEN_AND || tree.CurrentToken.Token == Tokens.TOKEN_OR);
                    if (canMove)
                    {
                        isOr = tree.CurrentToken.Token == Tokens.TOKEN_OR;
                        canMove = tree.Next();
                    }
                }
            } //while
            if (scopes != 0)
                throw new InvalidOperationException("scopes != 0");
        }

        private static Dictionary<int, OperatorType> OperatorTokens = new Dictionary<int, OperatorType>();
        static ParserCondition()
        {
            OperatorTokens.Add((int)Tokens.TOKEN_IN, OperatorType.In);
            OperatorTokens.Add((int)Tokens.TOKEN_LIKE, OperatorType.Like);
            OperatorTokens.Add(62/*'>'*/, OperatorType.MoreThan);
            OperatorTokens.Add(61/*'='*/, OperatorType.Equals);
        }
    }
}
