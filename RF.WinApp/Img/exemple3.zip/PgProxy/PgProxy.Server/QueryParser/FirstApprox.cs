﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.SqlServer.Management.SqlParser.Parser;

using PgProxy.SysDb;

namespace PgProxy.QueryParser
{
    internal class TokenInfo
    {
        public int Start { get; set; }
        public int End { get; set; }
        public bool IsPairMatch { get; set; }
        public bool IsExecAutoParamHelp { get; set; }
        public string Sql { get; set; }
        public Tokens Token { get; set; }
    }

    internal class FirstApproxTree
    {
        private List<TokenInfo> _list = new List<TokenInfo>();
        private int _currentPos = 0;
        private void CheckEnds()
        {
            EOF = _currentPos >= this.Count || this.Count == 0;
            BOF = _currentPos < 0;
        }

        private TokenInfo this[int index]
        {
            get
            {
                return this._list[index];
            }
        }

        public FirstApproxTree()
        {
            EOF = true;
            BOF = true;
        }

        public int CurrentPos
        {
            get
            {
                return _currentPos;
            }
            private set
            {
                _currentPos = value;
                CheckEnds();
            }
        }

        public bool EOF { get; private set; }
        public bool BOF { get; private set; }

        public int Count
        {
            get { return this._list.Count; }
        }

        public TokenInfo CurrentToken
        {
            get
            {
                return EOF || BOF ? null : this[_currentPos];
            }
        }

        public bool Next()
        {
            CurrentPos++;
            return !EOF && !BOF;
        }

        public bool Prev()
        {
            CurrentPos--;
            return !EOF && !BOF;
        }

        public bool MoveTo(int pos)
        {
            CurrentPos = pos;
            return !EOF && !BOF;
        }

        public void Add(TokenInfo ti)
        {
            this._list.Add(ti);
            CheckEnds();
        }

        public void Remove(TokenInfo ti)
        {
            int remIndex = this._list.IndexOf(ti);
            this._list.Remove(ti);
            if (remIndex <= _currentPos)
                _currentPos--;
            CheckEnds();
        }

        public void Insert(int pos, TokenInfo ti)
        {
            this._list.Insert(pos, ti);
            if (pos <= _currentPos)
                _currentPos++;
            CheckEnds();
        }

        public FirstApproxTree Extract(int beginPos, int endPos = -1)
        {
            endPos = endPos < 0 ? this.Count - 1 : Math.Min(this.Count - 1, endPos);
            var tree = new FirstApproxTree();
            if (beginPos > -1 && beginPos <= endPos)
            {
                for (var i = beginPos; i <= endPos; i++)
                {
                    tree.Add(this[i]);
                }
            }
            return tree;
        }

        public int FindTokenPos(Tokens needType, int posBegin = 0)
        {
            return FindTokenPos((int)needType, posBegin);
        }

        public int FindTokenPos(int needType, int posBegin = 0)
        {
            int pos = 0;
            bool isFound = false;
            for (pos = posBegin; pos < this.Count; pos++)
            {
                if ((int)this[pos].Token == needType)
                {
                    isFound = true;
                    break;
                }
            }

            return isFound ? pos : -1;
        }

        public static FirstApproxTree Parse(string sql)
        {
            ParseOptions parseOptions = new ParseOptions();
            Scanner scanner = new Scanner(parseOptions);
            var tree = new FirstApproxTree();

            int state = 0,
                start,
                end,
                lastTokenEnd = -1,
                token;

            bool isPairMatch, isExecAutoParamHelp;

            TokenInfo prevToken = null;

            scanner.SetSource(sql, 0);
            while ((token = scanner.GetNext(ref state, out start, out end, out isPairMatch, out isExecAutoParamHelp)) != (int)Tokens.EOF)
            {
                TokenInfo tokenInfo =
                    new TokenInfo()
                    {
                        Start = start,
                        End = end,
                        IsPairMatch = isPairMatch,
                        IsExecAutoParamHelp = isExecAutoParamHelp,
                        Sql = sql.Substring(start, end - start + 1),
                        Token = (Tokens)token,
                    };

                if (tokenInfo.Token == Tokens.TOKEN_ID)
                {
                    tokenInfo.Sql = tokenInfo.Sql.Trim('"', '[', ']');
                }

                if ((int)tokenInfo.Token == 45 /*'-'*/ || tokenInfo.Token == Tokens.LEX_WHITE)
                {
                    prevToken = tokenInfo;
                }
                else
                {
                    if (tokenInfo.Token == Tokens.TOKEN_INTEGER && prevToken != null)
                    {
                        tokenInfo.Sql = string.Concat(prevToken.Sql, tokenInfo.Sql);
                    }

                    prevToken = null;
                    tree.Add(tokenInfo);
                }

                lastTokenEnd = end;
            }

            return tree;
        }
    }
}
