﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PgProxy.SysDb;

namespace PgProxy.QueryParser
{
    internal class QueryJoin : QueryPart
    {
        public QueryDS RightDs { get; private set; }
        public IEnumerable<QueryConditionExpr> JoinCondition { get; private set; }
        public QueryJoin(QueryDS rightDs, IEnumerable<QueryConditionExpr> cond)
        {
            this.RightDs = rightDs;
            JoinCondition = cond;
        }

        protected override void SetOwner()
        {
            base.SetOwner();
            foreach (var cond in JoinCondition)
            {
                cond.Left.Owner = this;
                cond.Right.Owner = this;
            }
        }

        protected override IEnumerable<RowView> BuildPart(IEnumerable<RowView> queryResult)
        {
            //return queryResult.Join(this.RightDs.View, o => o[PkField], o => o[FkField], (o1, o2) => o1.Join(o2));
            return queryResult.Join(this.RightDs.View
                , o => new JoinMapper(o, this.JoinCondition)
                , o => new JoinMapper(o, this.JoinCondition)
                , (o1, o2) => o1.Join(o2));
        }
    }

    internal class JoinMapper
    {
        public IEnumerable<QueryConditionExpr> JoinCondition { get; private set; }
        public RowView View { get; private set; }

        public JoinMapper(RowView v, IEnumerable<QueryConditionExpr> cond)
        {
            this.JoinCondition = cond;
            this.View = v;
        }

        public override int GetHashCode()
        {
            int ret = 0;
            foreach (var c in this.JoinCondition)
            {
                var o = c.Left.Eval(this.View) ?? c.Right.Eval(this.View);
                if (o != null)
                    ret ^= o.GetHashCode();
            }
            return ret;
        }

        public override bool Equals(object obj)
        {
            var o = obj as JoinMapper;
            bool ret = true;
            foreach (var c in this.JoinCondition)
            {
                var lo = c.Left.Eval(this.View) ?? c.Right.Eval(this.View);
                var ro = c.Left.Eval(o.View) ?? c.Right.Eval(o.View);
                ret &= lo != null && ro != null && lo.Equals(ro);
            }
            return ret;
        }
    }
}
