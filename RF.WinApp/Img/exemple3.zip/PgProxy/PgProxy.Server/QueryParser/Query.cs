﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.SqlServer.Management.SqlParser.Parser;
using System.Reflection;

using RF.LinqExt;
using PgProxy.SysDb;
using PgProxy.QueryParser;

namespace PgProxy
{
    public class QueryMeta
    {
        /// <summary>
        /// Имя DependencyProperty в набре данных RowView
        /// </summary>
        public string DataName { get; set; }

        /// <summary>
        /// Имя так, как оно запрашивается в Query
        /// </summary>
        public string QueryName { get; set; }

        /// <summary>
        /// Имя проперти в типизированном объекте данных (POCO)
        /// </summary>
        public string FieldName { get; set; }

        /// <summary>
        /// Имя таблицы по аттрибуту DbTableAttribute у объекта-списка POCO
        /// </summary>
        public string TableName { get; set; }

        /// <summary>
        /// Значение константы
        /// </summary>
        public object ConstValue { get; set; }

        public int FormatCode { get; set; }

        public Type FieldType { get; set; }
    }

    internal class Query
    {
        public PgParams SessionParams { get; private set; }

        //public IEnumerable<QueryMeta> SelectList { get; private set; }

        public QuerySelect SelectPart { get; private set; }

        public IEnumerable<RowView> Data { get; private set; }

        public int ParamsCount { get { return queryParams.GroupBy(p => p.ParamName).Count(); } }

        private QueryPart EntryPart = null;
        private List<QueryParam> queryParams = new List<QueryParam>();
        private int expectedRowsCount = -1;
        private int rowsTaken = 0;
        private int[] paramTypes;
        private short[] paramFormats;
        private List<byte[]> paramBytes = new List<byte[]>();

        /* debug fields */
        public string OriginalSql;
        public string FirstInstruction;


        public Query(PgParams par)
        {
            SessionParams = par;
            SelectPart = new QuerySelect();
            EntryPart = SelectPart;
        }

        public bool Parse(string sql)
        {
            var ret = false;
            FirstApproxTree approx1Tree = FirstApproxTree.Parse(sql);

            OriginalSql = sql;
            FirstInstruction = approx1Tree.Count > 0 ? approx1Tree.CurrentToken.Sql : string.Empty;

            var pos = approx1Tree.FindTokenPos(Tokens.TOKEN_SELECT);
            if (pos > -1)
            {
                QueryPart curPart = null;
                var posFrom = approx1Tree.FindTokenPos(Tokens.TOKEN_FROM);
                var posWhere = approx1Tree.FindTokenPos(Tokens.TOKEN_WHERE);
                var posOrder = approx1Tree.FindTokenPos(Tokens.TOKEN_ORDER);
                var from = new ParserFrom(approx1Tree.Extract(posFrom + 1, Math.Min(posWhere, posOrder) - 1));
                var where = new ParserCondition(approx1Tree.Extract(posWhere, posOrder - 1));

                from.Parse();
                if (from.Tables.Count > 0)
                {
                    where.Parse(from.Tables);
                    EntryPart = from.Tables[0];
                    curPart = EntryPart;
                    for (var i = 1; i < from.Tables.Count; i++)
                    {
                        curPart.NextPart = new QueryJoin(from.Tables[i]
                        , from.JoinConditions.SelectMany(cp => cp.Conditions).Concat(where.Conditions)
                            .Where(e =>
                            {
                                var l = e.Left as QueryField;
                                var r = e.Right as QueryField;
                                return e.IsParsedSuccess && l != null && r != null && e.Op == OperatorType.Equals
                                    && ((l.Table == from.Tables[i - 1] && r.Table == from.Tables[i]) || (l.Table == from.Tables[i] && r.Table == from.Tables[i - 1]));
                            }
                            )
                            .ToList()
                            );
                        curPart = curPart.NextPart;
                    }

                    curPart.NextPart = new QueryWhere(where.Conditions.Where(e =>
                        e.IsParsedSuccess && ((e.Left is QueryField && e.Right is QueryValue) || (e.Right is QueryField && e.Left is QueryValue))
                        )
                        .ToList());
                    curPart = curPart.NextPart;
                }

                var sel = new ParserSelect(approx1Tree.Extract(pos + 1, posFrom - 1));
                sel.Parse(from.Tables);
                this.SelectPart.SelectList.AddRange(sel.SelectList);

                if (curPart != null)
                    curPart.NextPart = this.SelectPart;

                ret = true;
            }

            pos = approx1Tree.FindTokenPos(Tokens.TOKEN_SET);
            if (pos > -1)
            {
                return false;
            }

            pos = approx1Tree.FindTokenPos(Tokens.TOKEN_EXECUTE);
            if (pos > -1)
            {
                var exec = new ParserExec(approx1Tree.Extract(pos + 1, -1));
                exec.Parse();
                this.EntryPart = exec.Proc;
                this.SelectPart = exec.Proc.InnerSelect;
                this.EntryPart.NextPart = this.SelectPart;
                ret = true;
            }

            EnsureParametrization();
            this.EntryPart.Owner = this;

            return ret;
        }

        private bool EnsureParametrization()
        {
            queryParams.Clear();
            if (SelectPart != null)
                queryParams.AddRange(SelectPart.SelectList.Where(v => v.GetType() == typeof(QueryParam)).Cast<QueryParam>());

            if (EntryPart != null)
            {
                var qProc = EntryPart as QueryProc;
                if (qProc != null)
                {
                    queryParams.AddRange(qProc.Params.Where(c => c.GetType() == typeof(QueryParam)).Select(c => c as QueryParam));
                }

                var qp = EntryPart.NextPart;
                while (qp != null)
                {
                    var qJoin = qp as QueryJoin;
                    if (qJoin != null)
                    {
                        queryParams.AddRange(qJoin.JoinCondition
                            .Where(c => c.Left.GetType() == typeof(QueryParam) || c.Right.GetType() == typeof(QueryParam))
                            .Select(c => c.Left as QueryParam ?? c.Right as QueryParam)
                            );
                    }

                    var qWhere = qp as QueryWhere;
                    if (qWhere != null)
                    {
                        queryParams.AddRange(qWhere.Condition
                            .Where(c => c.Left.GetType() == typeof(QueryParam) || c.Right.GetType() == typeof(QueryParam))
                            .Select(c => c.Left as QueryParam ?? c.Right as QueryParam)
                            );
                    }

                    qp = qp.NextPart;
                }
            }

            return queryParams.Count > 0;
        }

        public void Bind()
        {
            BindParams();
        }

        public void Unbind()
        {
            paramBytes.Clear();
        }

        public bool Execute(int takeRows)
        {
            IEnumerable<RowView> queryExpr;
            if (EntryPart == null)
            {
                queryExpr = new RowView[] { new RowView() };
            }
            else
            {
                queryExpr = EntryPart.BuildQuery(null);
            }

            if (queryExpr == null)
                queryExpr = new RowView[0];

            if (expectedRowsCount < 0)
                expectedRowsCount = queryExpr.Count();

            if (expectedRowsCount <= takeRows || takeRows == 0)
            {
                Data = queryExpr.ToList();
                //return AsCursor = false;
                return true;
            }

            Data = queryExpr.Skip(rowsTaken).Take(takeRows).ToList();
            rowsTaken += Data.Count();
            return rowsTaken >= expectedRowsCount;
        }

        private void BindParams()
        {
            short paramFormat = 0; /*0 - string, 1 - binary*/
            var i = 0;
            foreach (byte[] paramRawValue in paramBytes)
            {
                object val = null;
                if (i < paramFormats.Length)
                    paramFormat = paramFormats[i];
                var paramTypeCode = 0;
                if (i < paramTypes.Length)
                    paramTypeCode = paramTypes[i];

                foreach (var par in queryParams.Where(p => p.ParamName == string.Format("${0}", i + 1)))
                {
                    if (paramRawValue.Length == 0)
                    {
                        val = DBNull.Value;
                    }
                    else
                    {
                        Type paramType = PgTypeTable.Rows.FirstOrDefault(r => r.oid == paramTypeCode)?.nettype ?? par.ValueType;
                        if (paramFormat == 0)
                        {
                            var sval = Encoding.UTF8.GetString(paramRawValue);
                            val = Utils.TryParse(sval, paramType);
                        }
                        else
                        {
                            if (paramType == typeof(string))
                                val = Encoding.UTF8.GetString(paramRawValue);
                            else if (paramRawValue.Length == 1)
                                val = paramRawValue[0];
                            else if (paramRawValue.Length == 2)
                                val = Utils.Int16FromBytes(paramRawValue, 0);
                            else
                                val = Utils.Int32FromBytes(paramRawValue, 0);
                        }
                    }

                    par.SetValue(val);
                }

                i++;
            }
        }

        public void BindParamTypes(int[] array)
        {
            paramTypes = array;
        }

        public void BindParamFormats(short[] array)
        {
            paramFormats = array;
        }

        public void BindParamBytes(byte[] array)
        {
            paramBytes.Add(array);
        }
    }
}
