﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;

using PgProxy.SysDb;

namespace PgProxy.QueryParser
{
    internal class QueryProc : QueryPart
    {
        public IStoreProc Proc { get; private set; }

        public List<QueryOperand> Params { get; private set; }

        private QuerySelect select;
        public QuerySelect InnerSelect
        {
            get
            {
                return select;
            }
            private set
            {
                select = value;
                if (select != null && Proc != null && Proc.ReturnType != null)
                {
                    foreach (var prop in Proc.ReturnType.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly))
                    {
                        var o = new QueryField(null);
                        o.SelfName = prop.Name;
                        o.ValueType = prop.PropertyType;
                        select.SelectList.Add(o);
                    }
                }
            }
        }

        public QueryProc(string name)
        {
            this.Proc = DataService.FindProc(name);
            this.Params = new List<QueryOperand>();
            this.InnerSelect = new QuerySelect();
        }

        protected override void SetOwner()
        {
            base.SetOwner();
            foreach (var par in Params)
            {
                par.Owner = this;
            }
        }

        protected override IEnumerable<RowView> BuildPart(IEnumerable<RowView> queryResult)
        {
            IEnumerable<object> ret = null;
            if (Proc != null)
            {
                foreach (var par in Params.Cast<QueryValue>())
                {
                    Proc.AddParam(par.Value);
                }

                if (Proc.LongTaskSupport)
                {
                    ret = LongTaskExecute();
                }
                else
                {
                    ret = Proc.Execute(this.Owner?.SessionParams);
                }

                if (ret != null)
                    return ret.Select(o => new RowView(o, ""));
            }
            return null;
        }

        private IEnumerable<object> LongTaskExecute()
        {
            var sess = this.Owner?.SessionParams;
            if (sess == null)
                throw new ArgumentNullException("StoreProc SessionParams");

            System.Runtime.Remoting.Messaging.CallContext.LogicalSetData(PgParams.PgSessionTlsKey, sess.SessionId);
            CancellationTokenSource cts = new CancellationTokenSource();
            CancellationToken ct = cts.Token;
            LongTaskTable.Add(new LongTask()
            {
                taskid = sess.SessionId,
                progress = "Start",
                starttime = DateTime.Now,
                canceltoken = cts
            });

            IEnumerable<object> ret = null;
            Exception innerErr = null;
            var execThread = new Thread(() => {
                try
                {
                    ret = Proc.Execute(sess);
                }
                catch(Exception e)
                {
                    innerErr = e;
                    cts.Cancel();
                }
            });

            execThread.Start();
            while (execThread.IsAlive)
            {
                if(ct.IsCancellationRequested)
                    execThread.Abort();
                if (innerErr != null)
                    throw innerErr;
            }

            LongTaskTable.Remove(sess.SessionId);
            return ret;
        }


    }
}

