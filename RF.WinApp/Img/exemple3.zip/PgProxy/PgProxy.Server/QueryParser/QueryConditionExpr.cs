﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RF.LinqExt;

namespace PgProxy.QueryParser
{
    internal class QueryConditionExpr
    {
        private QueryOperand _l = null;
        public QueryOperand Left
        {
            get
            {
                return _l;
            }
            set
            {
                _l = value;
                EnsureTypes();
            }
        }

        private QueryOperand _r = null;
        public QueryOperand Right
        {
            get
            {
                return _r;
            }
            set
            {
                _r = value;
                EnsureTypes();
            }
        }
        public OperatorType Op { get; set; }
        public bool IsOr { get; set; }

        public bool IsParsedSuccess
        {
            get
            {
                return Left != null && Left.IsParsedSuccess && Op != OperatorType.None && Right != null && Right.IsParsedSuccess;
            }
        }

        private void EnsureTypes()
        {
            if(_l != null && _r != null)
            {
                if(_l is QueryParam)
                {
                    _l.ValueType = _r.ValueType;
                }

                if (_r is QueryParam)
                {
                    _r.ValueType = _l.ValueType;
                }
            }
        }
    }
}
