﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SqlServer.Management.SqlParser.Parser;

namespace PgProxy.QueryParser
{
    internal class QueryValue : QueryOperand
    {
        public const string DefaultName = "?column?";

        private object _val;
        public object Value
        {
            get
            {
                return GetValue();
            }

            protected set
            {
                _val = value;
            }
        }

        protected virtual object GetValue()
        {
            return _val;
        }

        public override object Eval(RowView data)
        {
            return Value;
        }

        private static Dictionary<int, Type> ValueTokens = new Dictionary<int, Type>();

        static QueryValue()
        {
            ValueTokens.Add((int)Tokens.TOKEN_NUMERIC, typeof(double));
            ValueTokens.Add((int)Tokens.TOKEN_STRING, typeof(string));
            ValueTokens.Add((int)Tokens.TOKEN_INTEGER, typeof(int));
            ValueTokens.Add((int)Tokens.TOKEN_NULL, typeof(DBNull));
        }

        protected override bool DoParse(FirstApproxTree tree)
        {
            var canMove = !tree.BOF && !tree.EOF;
            if (canMove && TokenIn(tree.CurrentToken.Token))
            {
                var valueName = tree.CurrentToken.Sql;
                ValueType = ValueTokens[(int)tree.CurrentToken.Token];
                if (tree.CurrentToken.Token == Tokens.TOKEN_STRING)
                {
                    Value = valueName.Trim('\'');
                }
                else if (tree.CurrentToken.Token == Tokens.TOKEN_NULL)
                {
                    Value = DBNull.Value;
                }
                else
                {
                    Value = Utils.TryParse(valueName, ValueType);
                }
                tree.Next();
                SelfName = DefaultName;
                return true;
            }

            if (canMove && (int)tree.CurrentToken.Token == 40 /*'('*/)
            {
                canMove = tree.Next();
                var valList = new List<object>();
                while (canMove)
                {
                    var val = new QueryValue();
                    val.Parse(tree);
                    if (val.IsParsedSuccess)
                    {
                        valList.Add(val.Value);
                        //ValueType = val.ValueType;
                        if (canMove && (int)tree.CurrentToken.Token == 41 /*')'*/)
                        {
                            tree.Next();
                            Value = valList.ToArray();
                            return true;
                        }
                        if (canMove && (int)tree.CurrentToken.Token == 44 /*','*/)
                        {
                            canMove = tree.Next();
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }

            return false;
        }

        private bool TokenIn(Tokens t)
        {
            return ValueTokens.ContainsKey((int)t);
        }
    }
}
