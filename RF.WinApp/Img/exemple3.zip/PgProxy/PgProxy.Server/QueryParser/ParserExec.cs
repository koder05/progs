﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SqlServer.Management.SqlParser.Parser;

namespace PgProxy.QueryParser
{
    internal class ParserExec
    {
        private FirstApproxTree tree = null;
        public QueryProc Proc { get; private set; }
        public ParserExec(FirstApproxTree exec)
        {
            this.tree = exec;
        }

        public void Parse()
        {
            var canMove = !tree.BOF && !tree.EOF;
            if (canMove && tree.CurrentToken.Token == Tokens.TOKEN_ID)
            {
                Proc = new QueryProc(tree.CurrentToken.Sql);
                canMove = tree.Next();
                while (canMove)
                {
                    var par = QueryOperand.Parse(tree, null);
                    if (par != null)
                        Proc.Params.Add(par);
                    canMove = par != null && !tree.BOF && !tree.EOF && (int)tree.CurrentToken.Token == 44 /*,*/ && tree.Next();
                }
            }
        }
    }
}

