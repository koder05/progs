﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SqlServer.Management.SqlParser.Parser;

namespace PgProxy.QueryParser
{
    internal class QueryParam : QueryValue
    {
        public string ParamName { get; private set; }

        protected override bool DoParse(FirstApproxTree tree)
        {
            var canMove = !tree.BOF && !tree.EOF;
            if (canMove && tree.CurrentToken.Token == Tokens.TOKEN_MONEY)
            {
                ParamName = tree.CurrentToken.Sql;
                SelfName = DefaultName;
                tree.Next();
                return true;
            }

            return false;
        }

        public void SetValue(object v)
        {
            this.Value = v;
        }
    }
}
