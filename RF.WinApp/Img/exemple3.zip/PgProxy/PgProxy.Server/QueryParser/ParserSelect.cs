﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Microsoft.SqlServer.Management.SqlParser.Parser;

namespace PgProxy.QueryParser
{
    internal class ParserSelect
    {
        private FirstApproxTree selectTree = null;

        public List<QueryOperand> SelectList { get; private set; }

        public ParserSelect(FirstApproxTree tree)
        {
            this.selectTree = tree;
            SelectList = new List<QueryOperand>();
        }

        public void Parse(List<QueryDS> tList)
        {
            var canMove = !selectTree.BOF && !selectTree.EOF;

            //need replace "*" by full field list
            while (canMove)
            {
                if ((int)selectTree.CurrentToken.Token == 42/*'*'*/)
                {
                    var acronym = string.Empty;
                    var pos = selectTree.CurrentPos;
                    //try find acronym
                    if (this.selectTree.Prev() && (int)selectTree.CurrentToken.Token == 46/*'.'*/
                            && this.selectTree.Prev() && selectTree.CurrentToken.Token == Tokens.TOKEN_ID)
                    {
                        acronym = selectTree.CurrentToken.Sql;
                        //remove prefix
                        selectTree.Remove(selectTree.CurrentToken);
                        selectTree.Next();
                        //remove "."
                        selectTree.Remove(selectTree.CurrentToken);
                        selectTree.Next();
                        pos -= 2;
                    }

                    selectTree.MoveTo(pos);
                    //remove "*"
                    selectTree.Remove(selectTree.CurrentToken);
                    pos = selectTree.CurrentPos;
                    TokenInfo t = null;
                    foreach (var ds in tList.Where(tbl => tbl.Acronym.Equals(acronym, StringComparison.InvariantCultureIgnoreCase) || string.IsNullOrEmpty(acronym)))
                    {
                        if (string.IsNullOrEmpty(acronym))
                            acronym = ds.Acronym;
                        foreach (var prop in ds.DS.RowType.GetProperties(BindingFlags.Public | BindingFlags.Instance))
                        {
                            t = new TokenInfo() { Sql = acronym, Token = Tokens.TOKEN_ID };
                            selectTree.Insert(++pos, t);
                            t = new TokenInfo() { Sql = ".", Token = (Tokens)46 };
                            selectTree.Insert(++pos, t);
                            t = new TokenInfo() { Sql = prop.Name, Token = Tokens.TOKEN_ID };
                            selectTree.Insert(++pos, t);
                            t = new TokenInfo() { Sql = ",", Token = (Tokens)44 };
                            selectTree.Insert(++pos, t);
                        }
                    }

                    selectTree.MoveTo(pos);

                    //remove last ","
                    if (t != null)
                        selectTree.Remove(t);
                }

                canMove = selectTree.Next();
            }

            canMove = selectTree.MoveTo(0);

            while (canMove)
            {
                var p = QueryOperand.Parse(selectTree, tList);
                canMove = !selectTree.BOF && !selectTree.EOF;
                if (p != null)
                {
                    if (canMove && selectTree.CurrentToken.Token == Tokens.TOKEN_AS)
                    {
                        canMove = selectTree.Next();
                    }

                    if (canMove && selectTree.CurrentToken.Token == Tokens.TOKEN_ID)
                    {
                        p.AsName = selectTree.CurrentToken.Sql;
                        canMove = selectTree.Next();
                    }

                    SelectList.Add(p);
                }

                canMove = canMove && (int)selectTree.CurrentToken.Token == 44 && selectTree.Next();
            } //while
        }
    }
}
