﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

using PgProxy.SysDb;

namespace PgProxy.QueryParser
{
    internal class QueryDS : QueryPart
    {
        public ITable DS { get; private set; }

        public string Acronym { get; set; }

        public string TableName
        {
            get
            {
                return DS?.Name;
            }
        }

        public QueryDS(string name)
        {
            this.Acronym = name;
            //var tables = from x in Assembly.GetAssembly(typeof(ITable<>)).GetTypes()
            //             from y in x.GetInterfaces()
            //             where !x.IsAbstract && !x.IsInterface &&
            //             y != null && y.IsGenericType &&
            //             y.GetGenericTypeDefinition() == typeof(ITable<>)
            //             select x;
            this.DS = DataService.FindTable(name);
        }

        public IEnumerable<RowView> View
        {
            get
            {
                return this.DS.Data().Select(r => new RowView(r, this.Acronym));
            }
        }

        protected override IEnumerable<RowView> BuildPart(IEnumerable<RowView> queryResult)
        {
            return View;
        }
    }
}
