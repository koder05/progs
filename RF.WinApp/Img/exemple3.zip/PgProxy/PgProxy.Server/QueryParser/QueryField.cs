﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Microsoft.SqlServer.Management.SqlParser.Parser;

namespace PgProxy.QueryParser
{
    internal class QueryField : QueryOperand
    {
        public QueryDS Table { get; private set; }

        public string TablePrefix { get { return Table?.Acronym; } }

        public string FullName
        {
            get
            {
                if (string.IsNullOrEmpty(TablePrefix))
                    return SelfName;
                return string.Format("{0}.{1}", TablePrefix, SelfName);
            }
        }

        private List<QueryDS> tList;

        public QueryField(List<QueryDS> t)
        {
            tList = t;
        }

        public override object Eval(RowView data)
        {
            if (data != null)
                return data[FullName];
            return null;
        }

        protected override bool DoParse(FirstApproxTree tree)
        {
            var tPrefix = string.Empty;
            var canMove = !tree.BOF && !tree.EOF;
            if (canMove && tree.CurrentToken.Token == Tokens.TOKEN_ID)
            {
                SelfName = tree.CurrentToken.Sql;
                canMove = tree.Next();
                if (canMove)
                {
                    if ((int)tree.CurrentToken.Token == 46/*'.'*/)
                    {
                        canMove = tree.Next();
                        if (canMove && tree.CurrentToken.Token == Tokens.TOKEN_ID)
                        {
                            tPrefix = SelfName;
                            SelfName = tree.CurrentToken.Sql;
                            canMove = tree.Next();
                        }
                    }
                }

                if (SelfName.Equals(PgProxy.SysDb.PgTypeTable.ItemPointerInfo.typname, StringComparison.InvariantCultureIgnoreCase))
                {
                    SelfName = PgProxy.SysDb.PgTypeTable.ItemPointerInfo.typname;
                    ValueType = PgProxy.SysDb.PgTypeTable.ItemPointerInfo.nettype;
                    return true;
                }

                foreach (var ds in tList.Where(t => t.Acronym.Equals(tPrefix, StringComparison.InvariantCultureIgnoreCase) || string.IsNullOrEmpty(tPrefix)))
                {
                    foreach (var prop in ds.DS.RowType.GetProperties(BindingFlags.Public | BindingFlags.Instance))
                    {
                        if (prop.Name.Equals(SelfName, StringComparison.InvariantCultureIgnoreCase))
                        {
                            Table = ds;
                            ValueType = prop.PropertyType;
                            return true;
                        }
                    }
                }

                throw new PgException("42P01", string.Format("Field was not found '{0}'", SelfName));
            }

            return false;
        }
    }
}
