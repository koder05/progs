﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PgProxy.SysDb;

namespace PgProxy.QueryParser
{
    internal abstract class QueryPart
    {
        public QueryPart NextPart { get; set; }

        private Query _owner;
        public Query Owner
        {
            get
            {
                return _owner;
            }

            set
            {
                _owner = value;
                SetOwner();
            }
        }

        protected virtual void SetOwner()
        {
            if (this.NextPart != null)
            {
                this.NextPart.Owner = _owner;
            }
        }

        protected abstract IEnumerable<RowView> BuildPart(IEnumerable<RowView> queryResult);

        public IEnumerable<RowView> BuildQuery(IEnumerable<RowView> queryResult)
        {
            if (this.NextPart != null)
                return this.NextPart.BuildQuery(this.BuildPart(queryResult));

            return this.BuildPart(queryResult);
        }
    }
}
