﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SqlServer.Management.SqlParser.Parser;
using PgProxy.SysDb;

namespace PgProxy.QueryParser
{
    internal class QueryFoo : QueryValue
    {
        public IStoreProc Proc { get; private set; }

        protected override bool DoParse(FirstApproxTree tree)
        {
            var canMove = !tree.BOF && !tree.EOF;
            if (canMove && tree.CurrentToken.Token == Tokens.TOKEN_ID)
            {
                SelfName = tree.CurrentToken.Sql;
                var ret = tree.Next() && (int)tree.CurrentToken.Token == 40/*'('*/ && tree.Next() && (int)tree.CurrentToken.Token == 41/*')'*/;
                if (ret)
                {
                    this.Proc = DataService.FindProc(SelfName);
                    ValueType = this.Proc.ReturnType;
                    return ret;
                }
            }

            return false;
        }

        protected override object GetValue()
        {
            if(this.Proc != null)
            {
                var o = this.Proc.Execute(this.Owner.Owner.SessionParams);
                if (o != null && o.Count() > 0)
                    return o.ElementAt(0);
            }

            return null;
        }
    }
}
