﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.Data
{
    internal class DataCollector
    {
        private ConcurrentDictionary<DataProperty, object> _collection = new ConcurrentDictionary<DataProperty, object>();

        public void SetValue(DataProperty dp, object value)
        {
            _collection.AddOrUpdate(dp, value, (p, o) => value);
        }

        public object GetValue(DataProperty dp)
        {
            object ret;


            if (_collection.ContainsKey(dp) && _collection.TryGetValue(dp, out ret))
                return ret;

            return null;
        }

        public IEnumerable<DataProperty> GetCollection
        {
            get
            {
                return _collection.Keys;
            }
        }
    }
}
