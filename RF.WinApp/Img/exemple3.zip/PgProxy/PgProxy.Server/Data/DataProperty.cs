﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy.Data
{
    internal class DataProperty
    {
        public string Name { get; set; }
        public Type DataType { get; set; }

        public DataProperty(string name, Type type)
        {
            Name = name;
            DataType = type;
        }

        public override bool Equals(object obj)
        {
            var dp = obj as DataProperty;
            if (dp == null)
                return false;

            return this.Name.Equals(dp.Name, StringComparison.InvariantCultureIgnoreCase) && this.DataType == dp.DataType;
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode() ^ DataType.GetHashCode();
        }

        private static List<DataProperty> _pool = new List<DataProperty>();

        public static DataProperty Register(string name, Type type)
        {
            lock (_pool)
            {
                var dp = new DataProperty(name, type);
                if (_pool.Any(p => p == dp) == false )
                {
                    _pool.Add(dp);
                }
                return dp;
            }
        }
    }
}

