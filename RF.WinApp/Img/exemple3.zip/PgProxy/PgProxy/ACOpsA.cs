﻿using System;
using System.Collections.Generic;
using Actuary.Algorithms.OpsA;

namespace PgProxy
{
    public class ACOpsA : IStoreProc
    {
        private int calcId = 0;
        private string csName = "";

        public IEnumerable<object> Execute(PgParams connectionParams)
        {
            string cs = string.Empty;
            if (string.IsNullOrEmpty(csName) == false)
            {
                var cso = System.Configuration.ConfigurationManager.ConnectionStrings[csName];
                if (cso != null)
                    cs = cso.ConnectionString;
            }

            if (calcId == 0 || string.IsNullOrEmpty(cs))
            {
                throw new ArgumentNullException("wrong input data");
            }

            new Calculation(calcId, cs);
            return null;
        }


        private int curLoadedPar = 0;
        public void AddParam(object val)
        {
            if (curLoadedPar == 0)
            {
                calcId = Convert.ToInt32(val);
                //calcId = (int)val;
                curLoadedPar = 1;
            }
            else if (curLoadedPar == 1)
            {
                csName = val.ToString();
                curLoadedPar = 0;
            }
        }

        public Type ReturnType { get { return null; } }

        public bool LongTaskSupport
        {
            get
            {
                return true;
            }
        }
    }
}
