﻿using System;
using System.Collections.Generic;
using System.Linq;
using PgProxy.SysDb;
using RF.Common.Logging;

namespace PgProxy
{
    public class TestProc : IStoreProc
    {
        private List<object> parameters = new List<object>();

        public  IEnumerable<object> Execute(PgParams connectionParams)
        {
            for (var i = 0; i < 60; i++)
            {
                System.Threading.Thread.Sleep(1000);
                Logs.LogApp.Log(null, string.Format("done {0}/60", i), "TestProc");
            }

            return null;
        }

        public void AddParam(object val)
        {
            parameters.Add(val);
        }

        public Type ReturnType { get { return null; } }

        public bool LongTaskSupport
        {
            get
            {
                return true;
            }
        }
    }
}
