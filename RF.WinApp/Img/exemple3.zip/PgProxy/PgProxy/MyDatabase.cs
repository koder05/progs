﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PgProxy.SysDb;

namespace PgProxy
{
    public class MyDatabase : IDataDescriptor
    {
        public IEnumerable<PgAttribute> Columns()
        {
            return new PgAttribute[]
            {
                new PgAttribute() {attrelid=1, attname="id", atttypid=23, attlen=4, attnum=1, atttypmod=-1, attnotnull=true},
                new PgAttribute() {attrelid=1, attname="name", atttypid=19, attlen=64, attnum=2, atttypmod=-1, attnotnull=true}
            };
        }

        public ITable FindTable(string name)
        {
            if (name == "usertable")
                return new UserTable();

            throw new PgException("42P01", string.Format("Table was not found '{0}'", name));
        }

        public IStoreProc FindProc(string name)
        {
            if (name == "TestProc")
                return new TestProc();
            switch (name)
            {
                case "TestProc":
                    return new TestProc();
                case "acOpsA":
                    return new ACOpsA();
                case "acOpsGar":
                    return new ACOpsGar();
            }

            throw new PgException("42P01", string.Format("Store procedure was not found '{0}'", name));
        }

        public IEnumerable<PgClass> Tables()
        {
            return new PgClass[]
            {
                new PgClass() {oid=1, relname="usertable", relkind='r', relowner=10, relnamespace = 2200},
                new PgClass() {oid=2, relname="any_table", relkind='r', relowner=10, relnamespace = 2200}
            };
        }
    }
}
