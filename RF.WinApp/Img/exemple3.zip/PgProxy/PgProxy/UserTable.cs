﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PgProxy
{
    public class MyTable
    {
        public int id { get; set; }
        public string name { get; set; }
    }

    public class UserTable : ITable
    {
        public const string TableName = "usertable";

        public static IEnumerable<MyTable> Rows = new MyTable[]
            {
                new MyTable() {id=1247, name="pg_type"},
                new MyTable() {id=1259, name="pg_class"},
                new MyTable() {id=11063, name="pg_user"},
                new MyTable() {id=1249, name="pg_attribute"},
                new MyTable() {id=2601, name="pg_am"},
                new MyTable() {id=2610, name="pg_index"},
                new MyTable() {id=12470, name="pg_type2"},
                new MyTable() {id=12590, name="pg_class2"},
                new MyTable() {id=110630, name="pg_user2"},
                new MyTable() {id=12490, name="pg_attribute2"},
                new MyTable() {id=26010, name="pg_am2"},
                new MyTable() {id=26100, name="pg_index2"},
                new MyTable() {id=12471, name="pg_type3"},
                new MyTable() {id=12591, name="pg_class3"},
                new MyTable() {id=110631, name="pg_user3"},
                new MyTable() {id=12491, name="pg_attribute3"},
                new MyTable() {id=26011, name="pg_am3"},
                new MyTable() {id=26101, name="pg_index3"},

                new MyTable() {id=31247, name="pg_type"},
                new MyTable() {id=31259, name="pg_class"},
                new MyTable() {id=311063, name="pg_user"},
                new MyTable() {id=31249, name="pg_attribute"},
                new MyTable() {id=32601, name="pg_am"},
                new MyTable() {id=32610, name="pg_index"},
                new MyTable() {id=312470, name="pg_type2"},
                new MyTable() {id=312590, name="pg_class2"},
                new MyTable() {id=3110630, name="pg_user2"},
                new MyTable() {id=312490, name="pg_attribute2"},
                new MyTable() {id=326010, name="pg_am2"},
                new MyTable() {id=326100, name="pg_index2"},
                new MyTable() {id=312471, name="pg_type3"},
                new MyTable() {id=312591, name="pg_class3"},
                new MyTable() {id=3110631, name="pg_user3"},
                new MyTable() {id=312491, name="pg_attribute3"},
                new MyTable() {id=326011, name="pg_am3"},
                new MyTable() {id=326101, name="pg_index3"},

                                new MyTable() {id=1247, name="pg_type"},
                new MyTable() {id=1259, name="pg_class"},
                new MyTable() {id=11063, name="pg_user"},
                new MyTable() {id=1249, name="pg_attribute"},
                new MyTable() {id=2601, name="pg_am"},
                new MyTable() {id=2610, name="pg_index"},
                new MyTable() {id=12470, name="pg_type2"},
                new MyTable() {id=12590, name="pg_class2"},
                new MyTable() {id=110630, name="pg_user2"},
                new MyTable() {id=12490, name="pg_attribute2"},
                new MyTable() {id=26010, name="pg_am2"},
                new MyTable() {id=26100, name="pg_index2"},
                new MyTable() {id=12471, name="pg_type3"},
                new MyTable() {id=12591, name="pg_class3"},
                new MyTable() {id=110631, name="pg_user3"},
                new MyTable() {id=12491, name="pg_attribute3"},
                new MyTable() {id=26011, name="pg_am3"},
                new MyTable() {id=26101, name="pg_index3"},

                new MyTable() {id=31247, name="pg_type"},
                new MyTable() {id=31259, name="pg_class"},
                new MyTable() {id=311063, name="pg_user"},
                new MyTable() {id=31249, name="pg_attribute"},
                new MyTable() {id=32601, name="pg_am"},
                new MyTable() {id=32610, name="pg_index"},
                new MyTable() {id=312470, name="pg_type2"},
                new MyTable() {id=312590, name="pg_class2"},
                new MyTable() {id=3110630, name="pg_user2"},
                new MyTable() {id=312490, name="pg_attribute2"},
                new MyTable() {id=326010, name="pg_am2"},
                new MyTable() {id=326100, name="pg_index2"},
                new MyTable() {id=312471, name="pg_type3"},
                new MyTable() {id=312591, name="pg_class3"},
                new MyTable() {id=3110631, name="pg_user3"},
                new MyTable() {id=312491, name="pg_attribute3"},
                new MyTable() {id=326011, name="pg_am3"},
                new MyTable() {id=326101, name="pg_index3"}
            };

        public string Name { get { return TableName; } }

        public Type RowType
        {
            get { return typeof(MyTable); }
        }


        private List<MyTable> _data = null;
        public IEnumerable<object> Data()
        {
            return Rows;
            //if (_data == null)
            //{
            //    _data = new List<MyTable>();
            //    for (var i = 0; i < 1000; i++)
            //    {
            //        _data.Add(new MyTable() { id = i, name = Guid.NewGuid().ToString() });
            //        //yield return new MyTable() { id = i, name = new Guid().ToString() };
            //    }
            //}

            //return _data;
        }
    }
}
