﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PgProxy.QueryParser;
using System.Configuration;

namespace PgProxy
{
    class Program
    {
        static void Main(string[] args)
        {
            DataService.Init();
            //var parser = new SecondApprox("select relname, usename, relkind from pg_class c, pg_user u where c.relkind in ('r', 'v') and usesysid = relowner order by relname"); 
            //Utils.DebugTest("select ctid, * from usertable");
            //Utils.DebugTest("select u.usename, c.relname, a.attname, a.atttypid, t.typname, a.attnum, a.attlen, a.atttypmod, a.attnotnull, c.relhasrules, c.relkind, c.oid, NULL, 0, -1 from  pg_user u, pg_class c, pg_attribute a, pg_type t where  u.usesysid = c.relowner and c.oid= a.attrelid  and a.atttypid = t.oid and (a.attnum > 0) and c.relname like 'ttest' order by c.relname, attnum");

            //Utils.DebugTest("SELECT \"id\",\"name\"  FROM \"usertable\"  WHERE \"id\" = $1 OR \"id\" = $2 OR \"id\" = $3 OR \"id\" = $4 OR \"id\" = $5 OR \"id\" = $6 OR \"id\" = $7 OR \"id\" = $8 OR \"id\" = $9 OR \"id\" = $10");
            //Utils.DebugTest("DEALLOCATE \"_P0000\"");

            try
            {
                var conf = ConfigurationManager.AppSettings["PgPort"];
                int port = 9876;
                if (string.IsNullOrEmpty(conf) == false)
                {
                    int.TryParse(conf, out port);
                }
                
                AsyncService service = new AsyncService(port); service.Run(); Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
    }
}
